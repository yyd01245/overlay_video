#!/bin/bash

#cp file
local_dir_lib=./ffmpeg_lib
local_dir_bin=./ffmpeg_bin
local_dir_include=./ffmpeg_include


mkdir $local_dir_lib
mkdir $local_dir_bin
mkdir $local_dir_include

sudo cp -d /usr/local/lib/libavcodec* $local_dir_lib
sudo cp -d /usr/local/lib/libavdevice* $local_dir_lib
sudo cp -d /usr/local/lib/libavfilter* $local_dir_lib
sudo cp -d /usr/local/lib/libavformat* $local_dir_lib
sudo cp -d /usr/local/lib/libavutil* $local_dir_lib
sudo cp -d /usr/local/lib/libswresample* $local_dir_lib
sudo cp -d /usr/local/lib/libswscale* $local_dir_lib


sudo cp -d /usr/local/bin/ffmpeg $local_dir_bin
sudo cp -d /usr/local/bin/ffprobe $local_dir_bin
sudo cp -d /usr/local/bin/ffserver $local_dir_bin


sudo cp -r /usr/local/include/libavcodec $local_dir_include
sudo cp -r /usr/local/include/libavdevice $local_dir_include
sudo cp -r /usr/local/include/libavfilter $local_dir_include
sudo cp -r /usr/local/include/libavformat $local_dir_include
sudo cp -r /usr/local/include/libavutil $local_dir_include
sudo cp -r /usr/local/include/libswresample $local_dir_include
sudo cp -r /usr/local/include/libswscale $local_dir_include

