#!/bin/bash

echo "start install ffmpeg bin lib include..."

chmod a+x ffmpeg_bin/*
cp -d ffmpeg_bin/* /usr/local/bin/

chmod a+x ffmpeg_lib/*
cp -d ffmpeg_lib/* /usr/local/lib/

cp -r ffmpeg_include/* /usr/local/include/

ldconfig
echo "success install ffmpeg bin lib include..."
