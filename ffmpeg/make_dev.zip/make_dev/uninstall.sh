#!/bin/bash

echo "start uninstall ffmpeg bin lib include..."

rm -rf /usr/local/bin/ffmpeg
rm -rf /usr/local/bin/ffprobe
rm -rf /usr/local/bin/ffserver

rm -rf /usr/local/include/libavcodec
rm -rf /usr/local/include/libavdevice
rm -rf /usr/local/include/libavfilter
rm -rf /usr/local/include/libavformat
rm -rf /usr/local/include/libavutil
rm -rf /usr/local/include/libswresample
rm -rf /usr/local/include/libswscale

rm -rf /usr/local/lib/libavcodec*
rm -rf /usr/local/lib/libavdevice*
rm -rf /usr/local/lib/libavfilter*
rm -rf /usr/local/lib/libavformat*
rm -rf /usr/local/lib/libavutil*
rm -rf /usr/local/lib/libswresample*
rm -rf /usr/local/lib/libswscale*

echo "success uninstall ffmpeg bin lib include..."


