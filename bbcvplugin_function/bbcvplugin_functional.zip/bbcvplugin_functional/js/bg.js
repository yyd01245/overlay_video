var _local = {};
var vncPort;
var vncKeyPort;
//rsmheart 地址
var rsmheartURL="http://127.0.0.1:9999";
//var rsmheartURL="http://114.215.131.128:80";
//是否启用rsmheart
var rsmheartFlag=true;
var rsmheart_started_flag=false;
var rsmheart_timer;
var rsmheart_time = 2 * 1000;

function _log(text){
    //console.log(new Date(), '  ', text)
}

function extend(obj, ext){
    var keys = Object.keys(ext);
    keys.forEach(function(ele){
        obj[ele] = ext[ele];
    })
}


chrome.webRequest.onBeforeSendHeaders.addListener(
    function(details) {
        if(details.type === "script"){
            if(details.url.indexOf("chrome-extension://") !== 0){
                details.requestHeaders.push({
                    "name": "Cache-Control",
                    "value": "no-cache"
                })
            }
        }
        return {requestHeaders: details.requestHeaders};
    },
    {urls: ["<all_urls>"], types: ["main_frame", "sub_frame", "xmlhttprequest", "other", "script"]},
    ["blocking", "requestHeaders"]
);


var messageHandler = {
    "getLocal": function(msg, cb){
        _log("frontEnd fetch UserInfo");
        cb(_local);
    },
    "setLocal": function(msg, cb){
        var local = msg.local;
        extend(_local, local);
        cb();
    },
    "rsmheart": function(msg){
		_log("receive rsmheart :vncPort="+msg.vncPort +",vncKeyPort="+msg.vncKeyPort);
        if(rsmheartFlag){
            vncPort = msg.vncPort;
            vncKeyPort = msg.vncKeyPort;
            rsmHeartTimer();
        }
    }
};

chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse) {
        messageHandler[request.cmd](request, sendResponse);
    }
);


function rsmHeart(){
	var xhr = new XMLHttpRequest();
   	xhr.open("GET", rsmheartURL+"?vncPort="+vncPort+"&vncKeyPort="+vncKeyPort, false);
	xhr.send();
    _log(rsmheartURL+"?vncPort="+vncPort+"&vncKeyPort="+vncKeyPort);
}

function rsmHeartTimer(){
    if (!rsmheart_started_flag) {
        //rsmheart_started_flag = true;
        clearInterval(rsmheart_timer);
        rsmheart_timer = setInterval(rsmHeart, rsmheart_time);
    }
}


