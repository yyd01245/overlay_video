var $_local;


String.prototype.QS = function(name){
    var result = this.match(new RegExp("[\?\&]" + name+ "=([^\&]+)","i"));
    if(result == null || result.length < 1){
        return "";
    }
    return result[1];
};

function connectToBg( obj, callback ){
    callback = callback ? callback : function(){};
    chrome.extension.sendMessage( obj, callback );
}


function rsmheart(vncPort,vncKeyPort){  
    //console.log("login-vncPort: ", vncPort, "  login-vncKeyPort: ", vncKeyPort);
    connectToBg({
        "cmd": "rsmheart",
        "vncPort": vncPort,
        "vncKeyPort": vncKeyPort
    });
}

function heartbeat() {
    var qs = {};
    var qstr = location.search;
    var vncport = qstr.QS("vncport");
    var vnckeyport = qstr.QS("vnckeyport");
    var param_from_url_flag = false;

    if(vncport && vnckeyport){
        localStorage.setItem("vncPort", vncport);
        localStorage.setItem("vncKeyPort", vnckeyport);

        param_from_url_flag = true;
    } else {
        vncport=localStorage.getItem("vncPort");
        vnckeyport=localStorage.getItem("vncKeyPort");   
    }
    
    if(vncport && vnckeyport){

        qs["vncPort"]=vncport;
        qs["vncKeyPort"]=vnckeyport;  
        connectToBg({
            "cmd": "setLocal",
            "local": qs
        }, function(local){
        });

        var where_from = " ---from cache";
        if (param_from_url_flag) {
            where_from = " ---from url";
        }
        console.log("vncport: " + vncport + " vnckeyport: " + vnckeyport+ where_from);
        rsmheart(vncport,vnckeyport);
    } else {
        console.log("thereis no vncport & vnckeyport");
    }    
}


//执行空白首页逻辑
$(document).ready(function(){
    //第一时间加载localStorage数据
    //console.log("fetch local UserInfo from Background");
    connectToBg({
        "cmd": "getLocal"
    }, function(local){
        if (local) {
            $_local = JSON.parse(JSON.stringify(local));
            console.log("fetch result:", $_local);
            var keys = Object.keys($_local);
            keys.forEach(function(ele){
                localStorage.setItem(ele, local[ele]);
            })
        } else {
            console.log("getLocal message error!");
        }
        heartbeat();
    });
})
			

 