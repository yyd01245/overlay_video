bbcvplugin功能插件for chrome
svn: http://192.168.60.60/svn/CODE/bbcvplugin_functional

版本：v1.0.0	日期：2015-07-06	修改人：姚建
1. 加入心跳汇报代码