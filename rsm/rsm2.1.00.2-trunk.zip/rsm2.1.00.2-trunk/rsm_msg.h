#ifndef _H_MSG_RSM_
#define _H_MSG_RSM_



#include"rsm_resource.h"
#include"cJSON/cJSON.h"


typedef enum{
    RSM_CMD_None=0,
    RSM_CMD_REG,
    RSM_CMD_LOGIN,
    RSM_CMD_LOGOUT,
    RSM_CMD_PAUSE,
    RSM_CMD_EXIST,
    RSM_CMD_CHECK,
    RSM_CMD_ALIVE,
    RSM_CMD_TIMEOUT,
    RSM_CMD_GETSERVERINFO,
    RSM_CMD_GETRESLIST,
    RSM_CMD_ALARMEVENT,
    RSM_CMD_SYNC,
    RSM_CMD_Last
}cmd_t;


const char*rsm_cmd_to_str(cmd_t cmd);
cmd_t rsm_str_to_cmd(const char*cmdstr);

cmd_t rsm_parse_json_cmd(char*msg,cJSON**retjson);
int rsm_make_json_cmd(const cJSON*json,char*buff,int bufsiz);


inline int cjson_get_value(const cJSON*node,const char* key,char**opstr);
cJSON* rsm_get_json_cmd(cmd_t type,...);
int rsm_json_fill(const cJSON*pjson,...);

const char* rsm_get_null_msg(void);//response to CRSM 



#endif
