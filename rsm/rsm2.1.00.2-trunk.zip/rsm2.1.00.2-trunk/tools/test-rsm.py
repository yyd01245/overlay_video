#!/usr/bin/python3

import sys
import socket
import json
import time
import random



class RSM:

    BUFSIZ=8192
    def __init__(self,ip,port):
        self.address=(ip,port)
        self.sss=random.randint(100,999)
        self.resids=[]
        self.cnt=0

    def _connect(self):
        self.sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM);
        self.sock.connect(self.address);
    
    def _close(self):
        self.sock.close();

    def send_msg(self,smsg):
        self._connect();
        ns=self.sock.send(smsg.encode());
        rmsg=self.sock.recv(self.BUFSIZ).decode();
        self._close();
        
        print("Recv: "+rmsg)
        xxee_off=rmsg.find("XXEE");
        if xxee_off<0:
            return -1,{},""
        
        retdict=json.loads(rmsg[:xxee_off]);
        
        return int(retdict['retcode']),retdict,rmsg



class RSMessage:

    def __init__(self,url):
        self.url=url;

    def login(self,destip,destport,resid):
        d={"cmd":"vnclogin",
                "resid":resid,
                "iip":destip,"iport":str(destport),
                "rate":"3000",
                "url":self.url,
                "serialno":"dsdsdsdsddsdsd"};

        jsonstr=json.dumps(d)+"XXEE";
        print("Login with: "+jsonstr)
        return jsonstr

    def logout(self,resid):
        d={"cmd":"vnclogout",
                "resid":str(resid),
                "serialno":"dsdsdsdsddsdsd"};

        jsonstr=json.dumps(d)+"XXEE";
        print("Logout with: "+jsonstr)
        return jsonstr

    def logout_idx(self,idx):
        d={"cmd":"vnclogout",
                "index":str(idx+62000),
                "serialno":"dsdsdsdsddsdsd"};

        jsonstr=json.dumps(d)+"XXEE";
        print("Logout with: "+jsonstr)
        return jsonstr

    def pause(self,resid):
        d={"cmd":"vncpause",
                "resid":str(resid),
                "serialno":"dsdsdsdsddsdsd"};

        jsonstr=json.dumps(d)+"XXEE";
        print("Pause with: "+jsonstr)
        return jsonstr

    def getreslist(self):
        d={"cmd":"getreslist",
                "serialno":"bsbsbsbbbsssbs"};
        jsonstr=json.dumps(d)+"XXEE";
        print("GetResList with: "+jsonstr)
        return jsonstr




class TestRSM:
    
    def __init__(self,r,m,logname="./test-rsm.log"):
        self.runningresids=[]
        self.pausedresids=[]
        self.resids=[]
        self.rsm=r
        self.mm=m

        self.sss=random.randint(100,999)
        self.cnt=0
        self.logf=open(logname,'a+')
        self.logf.write('\n\n')
        self.logf.write('=============================\n')
        pass


    def gen_resid(self):
        self.cnt+=1
        s="beafcafe00"+str(self.sss)+str(self.cnt)
        self.resids.append(s)
        return s


    def log(self,sstr,level='msg'):
        now=time.strftime("%y/%m/%d %H:%M:%S")
        nows=(str(time.clock_gettime(time.CLOCK_REALTIME)).split('.')[1]+'000')[0:3]
        head=tail=''
        if level=='error':
            head='\033[31m'
            tail='\033[0m'
        output=now+nows+"\033[32m ["+str(level)+"]\033[0m "+":"+head+str(sstr)+tail
        print(output,file=sys.stderr)
        self.logf.write(output+"\n")



    def run_test(self,inv=1):
        flag_clear_running=0;
        flag_clear_paused=0
        
        self.log("Run_Test") 
    
        while True:
        
            t=random.randint(0,10);
        
            random.shuffle(self.pausedresids);
        
            if flag_clear_running!=0:
                while len(self.runningresids)>0:
                    resid=self.runningresids.pop(0); 
                    mstr=self.mm.logout(resid);
                    ret,retdict,rmstr=self.rsm.send_msg(mstr);
                    self.log("+Logout :"+mstr)
                    self.log("-Logout :"+rmstr)
                    if ret!=0:
                        self.log("Logout Failed with code %s"%(retdict['retcode']))
                flag_clear_running=0
    
            if flag_clear_paused!=0:
                while len(self.pausedresids)>0:
                    resid=self.pausedresids.pop(0); 
                    mstr=self.mm.logout(resid);
                    ret,retdict,rmstr=self.rsm.send_msg(mstr);
                    self.log("+Logout :"+mstr)
                    self.log("-Logout :"+rmstr)
                    if ret!=0:
                        self.log("Logout Failed with code %s"%(retdict['retcode']))
                flag_clear_paused=0
    
    
    
            if t<5:
                if t%2==0 and len(self.pausedresids)!=0:
                    resid=self.pausedresids.pop(0);
                else:
                    resid=self.gen_resid();
        
                mstr=self.mm.login('127.0.0.1',61000,resid);
        
                ret,retdict,rmstr=self.rsm.send_msg(mstr);
                self.log("+Login  :"+mstr)
                self.log("-Login  :"+rmstr)
                if ret<0:
                    self.log("Login Failed with code %s"%(retdict['retcode']))
                    continue;
                self.runningresids.append(resid);
        
            elif t>=5 and t<8:
                if 0==len(self.runningresids):
                    continue;
    #            print(self.runningresids)
                resid=self.runningresids[0];
                mstr=self.mm.logout(resid);
                ret,retdict,rmstr=self.rsm.send_msg(mstr);
                self.log("+Logout :"+mstr)
                self.log("-Logout :"+rmstr)
                if ret<0:
                    self.log("Logout Failed with code %s"%(retdict['retcode']))
                    if len(self.runningresids)==0:
                        flag_clear_paused=1
                    else:
                        flag_clear_running=1
                    continue;
                self.runningresids.pop(0);
        
            else:
                if 0==len(self.runningresids):
                    continue;
    #            print(self.runningresids)
                resid=self.runningresids[0];
                mstr=self.mm.pause(resid);
                ret,retdict,rmstr=self.rsm.send_msg(mstr);
                self.log("+Pause  :"+mstr)
                self.log("-Pause  :"+rmstr)
                if ret<0:
                    self.log("Pause Failed with code %s"%(retdict['retcode']))
                    continue;
                self.runningresids.pop(0);
                self.pausedresids.append(resid);
        
        
            time.sleep(inv)
            continue
    
    


    def clear_all(self):
        inresids=[]
        self.log("Clear_all") 
        mstr=self.mm.getreslist()
        ret,retdict,rmstr=self.rsm.send_msg(mstr);
        self.log("+GetReslist:"+mstr)
        self.log("-GetReslist:"+rmstr)
        if ret!=0:
            self.log("Get ResList Failed with code %d"%(ret))
        
#        print(retdict)
        if ret==0 and retdict['listnum']!='0':
            l=retdict['lists']
            for d in l:
                inresids.append(d['resid'])
    
        print(inresids)
    
        for res in inresids:
            mstr=self.mm.logout(res);
            ret,retdict,rmstr=self.rsm.send_msg(mstr);
            self.log("+Logout :"+mstr)
            self.log("-Logout :"+rmstr)
            if ret!=0:
                self.log("Logout Failed with code %d"%(ret))
 

       
    
    def logout_n(self,num):
        self.log("Logout_N") 
        idx=0
        while idx<num:
            if len(self.runningresids)>0:
                resid=self.runningresids.pop(0)
            elif len(self.pausedresids)>0:
                resid=self.pausedresids.pop(0)
            else:
                self.log("No Resource could be logout")
                break

            idx+=1
            mstr=self.mm.logout(resid)
            ret,retdict,retstr=self.rsm.send_msg(mstr);
            if ret!=0:
                self.log("Logout Failed with code %d"%(ret))
     
    
    def login_n(self,num):
        self.log("Login_N") 
        idx=0;
        while idx<num:
            resid=self.gen_resid();
            mstr=self.mm.login("127.0.0.1",61000+idx,resid);
            idx+=1;
            ret,retdict,retstr=self.rsm.send_msg(mstr);
            if ret!=0:
                self.log("LoginFailed with code %d"%(ret))
                break;
    




if __name__ == "__main__":
    r=RSM("192.168.200.202",25000);
#    r=RSM("192.168.200.126",25000);
#    r=RSM("21.254.236.253",25000);
    
    m=RSMessage('http://192.168.70.106/cisco_test1/tv2.0352.html');

#    m=RSMessage('http://vod.appaccess.wasu.cn/template_html/tv4/cstv4/index_recommend/index_recommend.html');
#    m=RSMessage('http://vod.appaccess.wasu.cn/index.jsp');
#    m=RSMessage('http://192.168.100.56:8181/html/gansu/homepage1/index.htm');
#    m=RSMessage('http://192.168.100.56:8189/gansu/DemoLinux/login.html');

    test=TestRSM(r,m)




    if len(sys.argv)==1:
        test.clear_all()
        test.run_test(3)

    elif len(sys.argv)==3 and sys.argv[1]=='-c':
        idx=1
        if sys.argv[2]=='all':
            test.clear_all()
        else:
            num=int(sys.argv[2])
            test.logout_n(num);

     
    elif sys.argv[1]=='-l':
        if len(sys.argv)==2:
            test.login_n(1)
        elif len(sys.argv)==3:
            test.login_n(int(sys.argv[2]))





