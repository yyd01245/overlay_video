#!/usr/bin/python3

import sys
import socket
import json
import time
import random



class RSM:

    BUFSIZ=2048
    def __init__(self,ip,port):
        self.address=(ip,port)

    def _connect(self):
        self.sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM);
        self.sock.connect(self.address);
    
    def _close(self):
        self.sock.close();

    def send_msg(self,smsg):
        self._connect();
        ns=self.sock.send(smsg.encode());
        rmsg=self.sock.recv(self.BUFSIZ).decode();
        self._close();
        
        print("Recv: "+rmsg)
        xxee_off=rmsg.find("XXEE");
        if xxee_off<0:
            return -1,{}
        
        retdict=json.loads(rmsg[:xxee_off]);
        
        return int(retdict['retcode']),retdict



class RSMessage:

    def __init__(self,url):
        self.cnt=0;
        self.url=url;
        self.sss=random.randint(100,999)
    def gen_resid(self):
        self.cnt+=1;
        return "deadbeef"+str(self.sss)+str(self.cnt);

    def login(self,destip,destport,resid):
        d={"cmd":"vnclogin",
                "resid":resid,
                "iip":destip,"iport":str(destport),
                "rate":"3000",
                "url":self.url,
                "serialno":"dsdsdsdsddsdsd"};

        jsonstr=json.dumps(d)+"XXEE";
        print("Login with: "+jsonstr)
        return jsonstr

    def logout(self,resid):
        d={"cmd":"vnclogout",
                "resid":str(resid),
                "serialno":"dsdsdsdsddsdsd"};

        jsonstr=json.dumps(d)+"XXEE";
        print("Logout with: "+jsonstr)
        return jsonstr

    def logout_idx(self,idx):
        d={"cmd":"vnclogout",
#                "indexbase":"62000",
                "index":str(idx+62000),
                "serialno":"dsdsdsdsddsdsd"};

        jsonstr=json.dumps(d)+"XXEE";
        print("Logout with: "+jsonstr)
        return jsonstr



    def pause(self,resid):
        d={"cmd":"vncpause",
                "resid":str(resid),
                "serialno":"dsdsdsdsddsdsd"};

        jsonstr=json.dumps(d)+"XXEE";
        print("Pause with: "+jsonstr)
        return jsonstr



def run_test(r,m,inv=1):
        while True:
    
            t=random.randint(0,10);
    
            random.shuffle(pausedresids);
            random.shuffle(freeresids);
    
            if t<5:
                if t%2==0 and len(pausedresids)!=0:
                    resid=pausedresids.pop(0);
                else:
                    resid=freeresids.pop(0);
    
                mstr=m.login('127.0.0.1',61000,resid);
    
                ret,retdict=r.send_msg(mstr);
                if ret<0:
                    print("Login Failed with code %s"%(retdict['retcode']))
                    continue;
                loginedresids.append(resid);
    
            elif t>=5 and t<8:
                if 0==len(loginedresids):
                    continue;
                print(loginedresids)
                resid=loginedresids[0];
    
                mstr=m.logout(resid);
                ret,retdict=r.send_msg(mstr);
                if ret<0:
                    print("Logout Failed with code %s"%(retdict['retcode']))
                    continue;
                loginedresids.pop(0);
                freeresids.append(resid);
    
            else:
                if 0==len(loginedresids):
                    continue;
                print(loginedresids)
                resid=loginedresids[0];
                mstr=m.pause(resid);
                ret,retdict=r.send_msg(mstr);
                if ret<0:
                    print("Pause Failed with code %s"%(retdict['retcode']))
                    continue;
                loginedresids.pop(0);
                pausedresids.append(resid);
    
    
            time.sleep(inv)
            continue



def clear_all(r,m,num=0):
    idx=1
    while idx<=num or num==0:
        
        resid=freeresids.pop(0); 
        mstr=m.logout_idx(idx);
        idx+=1;
        ret,retdict=r.send_msg(mstr);
        if ret!=0:
            print("Logout Failed with code %s"%(retdict['retcode']))
            if num==0:
                break;
    
def login_n(r,m,num):
    idx=0;
    while idx<num:
        
        resid=m.gen_resid();
        mstr=m.login("127.0.0.1",18000,resid);
        idx+=1;
        ret,retdict=r.send_msg(mstr);
        if ret!=0:
            print("Logout Failed with code %s"%(retdict['retcode']))
            break;
    




if __name__ == "__main__":
    r=RSM("192.168.200.182",25000);
#    r=RSM("192.168.200.126",25000);
#    r=RSM("21.254.236.253",25000);

    m=RSMessage('http://192.168.70.106/cisco_test1/tv2.0352.html');

#    m=RSMessage('http://vod.appaccess.wasu.cn/template_html/tv4/cstv4/index_recommend/index_recommend.html');
#    m=RSMessage('http://vod.appaccess.wasu.cn/index.jsp');
#    m=RSMessage('http://192.168.100.56:8181/html/gansu/homepage1/index.htm');
#    m=RSMessage('http://192.168.100.56:8189/gansu/DemoLinux/login.html');

    freeresids=[];
    loginedresids=[];
    pausedresids=[];


    for i in range(100):
        freeresids.append(m.gen_resid());

    num=1

    if len(sys.argv)>1:
        num=int(sys.argv[1])

    login_n(r,m,num)
    
     

