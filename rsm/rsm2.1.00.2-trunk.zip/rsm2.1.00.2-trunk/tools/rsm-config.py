#!/usr/bin/python3

from subprocess import *
import sys
import re
import os
import shutil


platform="<UNKNOWN>"



def print_config(name,ret,idx=[0]):
    idx[0]+=1
    i=idx[0]

    ndot=50-len(name)
    

    print("%2d. Config %s %s"%(i,name,ndot*"."),end=' ')
    if ret:
        print("\033[32mSuccess\033[0m")
    else:
        print("\033[31mFailed\033[0m")





def _get_gpu_core():
    gpuids=[]
    with Popen(['lspci'],stdout=PIPE)as proc:
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'([0-9a-z]+:[0-9a-z]+\.[0-9a-z]+)\ +VGA.+NVIDIA')
        for l in lines:
            m=r.search(l)
            if m:
                gpuids.append(m.groups()[0])
#        print("\n-->GPU.busids")
#        print(gpuids)
#        print("\n")
        return len(gpuids)            



def _get_bluelink_card():
    encids=[]
    with Popen(['lspci'],stdout=PIPE)as proc:
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'([0-9a-z]+:[0-9a-z]+\.[0-9a-z]+).+Texas')
        for l in lines:
            m=r.search(l)
            if m:
                encids.append(m.groups()[0])
#        print("\n-->Bluelink.busids")
#        print(encids)
#        print("\n")
        return len(encids)         


def config_pulse():

    if 0!=os.geteuid():
        print("\033[31m\t- Please run with root!! \033[0m")
        return False


    ok=True
    reorded=False
    with open('/etc/pulse/default.pa','r+') as f:
        sinknum={}
        nlines=[]
        lines=f.readlines()
        r=re.compile(r'load-module\ +module-null-sink\ +sink_name=(\d+)\ *$')
        nsink=0
        for l in lines:
            m=r.search(l);
            if m:
                nsink+=1;
                if nsink != int(m.groups()[0]):
                    reorded=True 
            else:
                nlines.append(l)

        if nsink!=32 or reorded:
            for i in range(1,33):
                line='load-module module-null-sink sink_name={}\n'.format(i)
                nlines.append(line)
    
            f.truncate(0)
            f.seek(0,0)
            f.writelines(nlines)


    return ok




def config_vgl():
    ok=True

    if 0!=os.geteuid():
        print("\033[31m\t- Please run with root!! \033[0m")
        return False

    with Popen(['which vglserver_config'],stdout=PIPE,shell=True)as proc:
        lines=proc.stdout.read().decode().splitlines()
        if len(lines)==0:
            print("\033[31m\t- vglserver_config not found..\033[0m")
            ok=False
        else:
            with Popen(['/opt/VirtualGL/bin/vglserver_config -config +s +f +t'],stdout=PIPE,shell=True)as subproc:
                pass

    return ok 










def config_bluelink():

    if 0!=os.geteuid():
        print("\033[31m\t- Please run with root!! \033[0m")
        return False
#start 
#/etc/init.d/dm816x start 63
    ok=True
    f_write=False
    f_add=True
    with open("/etc/init.d/rc.local","r+") as f:
        lines=f.readlines();
#        print(lines)
        r=re.compile(r'.+dm816x\ +start')
        #/etc/init.d/init-enc.sh
        rc=re.compile(r'init-enc\.sh')#for backward compatible    

        nlines=[]
        for l in lines:
            m=r.search(l)
            if m:
                f_add=False
                #OK
            m=rc.search(l)
            if m:
                f_write=True
                continue

            nlines.append(l) 
    
        if f_add:
            nlines.append("/etc/init.d/dm816x start 63\n")
    
    if f_add or f_write:
        f.truncate(0)
        f.seek(0,0)
        f.writelines(nlines)


    return ok    


def config_memory():

    if 0!=os.geteuid():
        print("\033[31m\t- Please run with root!! \033[0m")
        return False
    #1. to avoid memory leak of dbus-daemon 
    ok=True
    f_dbus=False

    with open('/etc/dbus-1/session.conf','r+') as f:
        lines=f.readlines();
        nlines=[] 
        r=re.compile(r'\<unfork/\>')
        for l in lines:
            m=r.search(l)
            if m:
                f_dbus=True
                break
            nlines.append(l)

        if not f_dbus:
            nlines.insert(18,"  <unfork/>\n")
            f.truncate(0)
            f.seek(0,0)
            f.writelines(nlines)


    f_sysctl=False   
    nlines=[]
    with open('/etc/sysctl.d/60-custom.conf','a+') as f:
        lines=f.readlines();
        r=re.compile(r'vm\.drop_caches=3')
        for l in lines:
            m=r.search(l)
            if m:
                f_sysctl=True
                break
            nlines.append(l)

        if not f_sysctl:
            f.writelines(nlines);
            f.write("\nvm.drop_caches=3\n")



    return ok






def config_xorg():

    if 0!=os.geteuid():
        print("\033[31m\t- Please run with root!! \033[0m")
        return False

    ok=True
    gpudict={};
    ngpu=0
    gpus=[];
    with Popen(["ls" ,"/proc/driver/nvidia/gpus"], stdout=PIPE,shell=False) as proc:
        gpus=proc.stdout.read().decode().splitlines()
#    print(gpus)
    ngpu=len(gpus)
    
    if 0==ngpu:
        print("\033[31m\t-No gpus found under /proc/driver/nvidia/gpus \033[0m")
        return ok


    r=re.compile(r'\d+:([a-z0-9A-Z]+):([a-z0-9A-Z]+)\.([a-z0-9A-Z]+)')
#0000:02:00.0
    i=0
    for bus in gpus:
        m=r.search(bus)
        busid_str=m.groups()
        busid_int=int(busid_str[0],16),int(busid_str[1],16),int(busid_str[2],16)
        busid_str=str(busid_int[0]),str(busid_int[1]),str(busid_int[2])
        gpudict[i]=":".join(busid_str)
        i+=1
#    print(gpudict)
 
#nvidia-xconfig --busid=PCI:$id:0:0 --use-display-device=None --force-generate --no-probe-all-gpus -o ${file}
    for k in gpudict.keys():
        cmd="nvidia-xconfig --busid=PCI:"+gpudict[k]+" --use-display-device=None --force-generate --no-probe-all-gpus -o /etc/X11/xorg.conf."+str(k)
#        print(cmd);
        with Popen([cmd],stdout=PIPE,shell=True) as proc:
            pass
	

#disable lightdm for launch X session
    f_mod=False
    with open('/etc/init/lightdm.conf','r+')as f:
        lines=f.readlines();
        nlines=[] 
    #    print(filecnt)
    #      and runlevel [!06]
    #stop on runlevel [016]
        r0=re.compile(r'and\ +runlevel\ +\[!(\d+)\]')
        r1=re.compile(r'stop\ +on\ +runlevel\ +\[(\d+)\]')
        for l in lines:
            m0=r0.search(l)
            if m0:
    #            print(m0.groups())
                if m0.groups()[0]!="026":
                    nlines.append("\t\tand runlevel [!026]\n")
                    f_mod=True
                    continue
    
            m1=r1.search(l)
            if m1:
                if m1.groups()[0]!="0126":
                    nlines.append("stop on runlevel [0126]\n")
                    f_mod=True
                    continue
    
            nlines.append(l)

        if f_mod:
            f.truncate(0)
            f.seek(0,0)
            f.writelines(nlines)
    
    
#write X to rc.local
#X -config /etc/X11/xorg.conf.0 :0 -sharevts
    with open("/etc/init.d/rc.local",'r+')as f:
        lines=f.readlines()
        nlines=[]
        r=re.compile(r'X\ +-config ')
        r0=re.compile(r'init-x\.sh')
        for l in lines:
            m0=r0.search(l)
            if m0:
                continue
            m=r.search(l)
            if m:
                continue

            nlines.append(l)
    
    
        for v in range(ngpu):
            l="X -config /etc/X11/xorg.conf.{} :{} -sharevts &\n".format(v,v)
            nlines.append(l)

        f.truncate(0)
        f.seek(0,0)
        f.writelines(nlines)
    
    return ok



def do_config():

    ret=config_xorg()
    print_config("Xorg",ret)

    ret=config_vgl()
    print_config("VGL",ret)

    is_bluelink=_get_bluelink_card()
    if is_bluelink>0:
        ret=config_bluelink()
        print_config("Bluelink",ret)


    ret=config_pulse()
    print_config("pulse",ret)


    ret=config_memory()
    print_config("Memory",ret)


    print("\n\033[32m ** Config Over!!\033[0m\n")


if __name__ == "__main__":

    
#    print("Usage: sudo "+sys.argv[0]+" -options...")
    sys.argv.pop(0);

        
    do_config();



