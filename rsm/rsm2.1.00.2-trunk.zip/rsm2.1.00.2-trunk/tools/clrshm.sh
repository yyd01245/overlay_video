#!/bin/bash


LIST=$(ipcs -m |awk '$6 ~ /0/{print $2"\n"}')


for i in ${LIST} ;do

    echo rm shmid ${i}
    sudo ipcrm -m ${i}

done


