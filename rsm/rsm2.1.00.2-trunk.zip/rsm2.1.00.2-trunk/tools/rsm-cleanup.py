#!/usr/bin/python3

from subprocess import *
import sys
import re
import os
import shutil



def cleanup_rsmlog():

    cwd=os.getcwd()
    if cwd.find('rsm-release')<0:
        print("CWD={},not in `rsm-release'".format(cwd))
        return False
    fl=os.listdir(cwd)
    if not 'log' in fl:
        print("Caution: directory `log' not found.")
        return False
    lf=os.listdir(cwd+'/log')
    for i in lf:
        if i.find('log')>0:
            os.remove(cwd+'/log/'+i)
    
    return True



def cleanup_tmp():

    #rm chrome files
    fl=os.listdir("/tmp")
#    print(fl)
    print("sizeof fl:"+str(len(fl)))
    r=re.compile(r'.com.google.Chrome.[a-zA-Z0-9]+');
    for l in fl:
        m=r.search(l)
        if m:
            print("/tmp/"+l)
            shutil.rmtree("/tmp/"+l)

    r=re.compile(r'chrome[0-9]+');
    for l in fl:
        m=r.search(l)
        if m:
            print("/tmp/"+l)
            shutil.rmtree("/tmp/"+l)

    r=re.compile(r'smooth.log.[0-9]+')
    for l in fl:
        m=r.search(l)
        if m:
            print("/tmp/"+l)
            os.remove("/tmp/"+l)
#
#avencoder.19
    r=re.compile(r'avencoder.[0-9]+')
    for l in fl:
        m=r.search(l)
        if m:
            print("/tmp/"+l)
            os.remove("/tmp/"+l)

#pulse-1yhc3uavuaOb
    r=re.compile(r'pulse-[0-9a-zA-Z]{6,}')
    for l in fl:
        m=r.search(l)
        if m:
            print("/tmp/"+l)
            shutil.rmtree("/tmp/"+l)
#remove Xvnc' lock
    return True





def cleanup_shm():
    
    ok=True
    with Popen(['ipcs -m'],stdout=PIPE,shell=True) as proc:
        nshm=0
        shmid=[]
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'([^ ]+)\ +(\d+)\ + ([^ ]+)\ +(\d+)\ +(\d+)\ +(\d+)')
        for l in lines:
            m=r.match(l)
            if m and int(m.groups()[5])==0:
                shmid.append(m.groups()[1])

    for shm in shmid:
        cmd='ipcrm -m '+shm
        with Popen([cmd],stderr=PIPE,shell=True) as proc:
            reply=proc.stderr.read().decode().splitlines()
            if len(reply)>0:
                ok=False

    if not ok:
        print("\033[31m\t- Please run with root..\033[0m")

    return ok




def print_cleanup(name,ret,idx=[0]):
    idx[0]+=1
    i=idx[0]

    ndot=50-len(name)
    

    print("%2d. Cleanup %s %s"%(i,name,ndot*"."),end=' ')
    if ret:
        print("\033[32mSuccess\033[0m")
    else:
        print("\033[31mFailed\033[0m")





def do_cleanup():
    print('''
++Do Cleanup
''')
    ret=cleanup_shm()
    print_cleanup("Shm",ret)

    ret=cleanup_tmp()
    print_cleanup("tmp directory",ret)

    ret=cleanup_rsmlog()
    print_cleanup("rsmlog",ret)

    print("\n\033[32m ** Cleanup Over!!\033[0m\n")
    #cleanup_other()





if __name__ == "__main__":

#    print("Usage: sudo "+sys.argv[0]+" -options...")
    sys.argv.pop(0);


    do_cleanup();


