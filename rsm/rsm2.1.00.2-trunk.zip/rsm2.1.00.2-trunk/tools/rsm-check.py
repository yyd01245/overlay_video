#!/usr/bin/python3

from subprocess import *
import sys
import re
import os
import shutil


#0 for bluelink
#1 for nvidia
platform=0

def _get_gpu_core():
    gpuids=[]
    with Popen(['lspci'],stdout=PIPE)as proc:
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'([0-9a-z]+:[0-9a-z]+\.[0-9a-z]+)\s+VGA.+NVIDIA')
        for l in lines:
            m=r.search(l)
            if m:
                gpuids.append(m.groups()[0])
#        print("\n-->GPU.busids")
#        print(gpuids)
#        print("\n")
        return len(gpuids)            

def _get_bluelink_card():
    encids=[]
    with Popen(['lspci'],stdout=PIPE)as proc:
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'([0-9a-z]+:[0-9a-z]+\.[0-9a-z]+).+Texas')
        for l in lines:
            m=r.search(l)
            if m:
                encids.append(m.groups()[0])
#        print("\n-->Bluelink.busids")
#        print(encids)
#        print("\n")
        return len(encids)         




def show_info():
#1.OS
#2.CPU
#3.MEM
#4.DISK
#5.PLATFORM
    osver="<UNKNOWN>"
    with open('/etc/issue') as f:
        r=re.compile(r'([^\\]+).*')
        lines=f.readlines()
        for l in lines:
            m=r.search(l)
            if m:
                osver=m.groups()[0]
                break;
    print("\033[32m + OS: "+osver+"  \033[0m")    

    cputype="<UNKNOWN>"
    maxn=0
    with open('/proc/cpuinfo') as f:
#model name      : Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz
        r=re.compile(r'model\s+name\s+:\s+(.*)$')
#        processor       : 31
        rn=re.compile(r'processor\s+:\s+(\d+)')
        lines=f.readlines()
        for l in lines:
            m=r.search(l)
            if m:
                cputype=m.groups()[0]
                continue
            m=rn.search(l)
            if m:
                maxn=int(m.groups()[0])
#                continue
        maxn+=1

    print("\033[32m + CPU("+str(maxn)+"): "+cputype+"  \033[0m")    

    memsize="<UNKNOWN>"
    with open('/proc/meminfo') as f:
        r=re.compile(r'MemTotal:\s+(\d+)')
        lines=f.readlines()
        for l in lines:
            m=r.search(l)
            if m:
                memsize=m.groups()[0]
                break;
    ms=int(memsize)//(1024*1024)
    print("\033[32m + Memory Size: "+str(ms)+"GB  \033[0m")    
    

    print("\033[32m + Disk Info:   \033[0m")    
    ndisk=0
    with Popen(['lsblk -o NAME,SIZE'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'(sd[a-z])\s+([.0-9]+[a-zA-Z])')
        for l in lines:
            m=r.search(l)
            if m:
                disk,size=m.groups()[0],m.groups()[1]
                print("\033[33m \t- disk: "+disk+" size:"+size+" \033[0m")    
    

    platform="<UNKNOWN>"


    ncard=_get_bluelink_card()
    ngpu=_get_gpu_core()

    if ncard>0 and ngpu==1:
        platform="BlueLink"
    elif ncard==0 and ngpu>1:
        platform="Nvidia"


    
    plat="UNKNOWN"

#    if platform=="BlueLink":
#        ret,ver=check_bluelink(ncard)
#        plat=platform+ " dm816x["+ver+"]"

    vnam="UNKNOWN"
    if platform=="Nvidia":
        ret,vnam=check_gpu()


    print("\033[32m + Platform: \033[0m")

    if platform=="BlueLink":
        print("\033[33m\t- Core Num:{}  \033[0m".format(ncard))
        ret,ver=check_bluelink(ncard)

    if platform=="Nvidia":
        print("\033[33m\t- GraphicCard:{}  \033[0m".format(vnam))
        print("\033[33m\t- Core Num:{}  \033[0m".format(ngpu))

    print("\n")



def check_bluelink(nenc):
#    nenc=_get_bluelink_card()
#    if nenc==0:
#        return False
#
    f_dm=False
    ver="unknown"
    r=re.compile(r'dm816x\s+([^\t ]+)\s+')
    with Popen(['dpkg-query --list'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines()
        for l in lines:
            m=r.search(l)
            if m:
                ver=m.groups()[0]
                f_dm=True
                break

    if not f_dm:
        print("\033[31m\t- dm816x package not install!! \033[0m")
        return False,ver



    if not os.path.exists('/etc/init.d/dm816x'):
        print("\033[31m\t- dm816x script not installed!! \033[0m")
        return False,ver

    with Popen(['lsmod |grep dm816x'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines()
        if len(lines)<2:
            print("\033[31m\t- dm816x modules not load!! \033[0m")
            return False,ver


    lines=[]
    uid=os.getuid()
    if not uid==0:
        print("\033[31m\t- Skip check /proc/netra (or run with root)\033[0m")
    else:
        with Popen(["cat  /proc/netra |sed '/banka_productname/d'"],stdout=PIPE,shell=True) as proc:
            lines=proc.stdout.read().decode().splitlines()
            r=re.compile(r'\[dev_status_\d+\]')
            nitem=0
            for l in lines:
                m=r.search(l)
                if m:
                    nitem+=1
            if nitem!=nenc:
                print("Error: /proc/netra file malformed..")

#chan_4_19_status=bad
    r=re.compile(r'chan_.+_status=([a-z]+)')
    nchan=0;
    nfree=0;
    nbad=0;
    for l in lines:
        m=r.search(l)
        if m:
            nchan+=1
            if m.groups()[0]=='free':
                nfree+=1
            if m.groups()[0]=='bad':
                nbad+=1
            
    print("\033[33m\t- Total Channels:{} free:{} & bad:{}\033[0m".format(nchan,nfree,nbad))
    if nbad!=0:
        return False,ver

    return True,ver


def check_pulse():

    ver="[unknown]"

    with Popen(['pulseaudio --version'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines();
        r=re.compile(r'[a-zA-Z]+\s+(.+)')
        if len(lines)>0:
            m=r.search(lines[0])
            ver=m.groups()[0]


    ok=False
    with open('/etc/pulse/default.pa') as f:
        lines=f.readlines()
        r=re.compile(r'load-module\s+module-null-sink\s+sink_name=(\d+)')
        nsink=0
        for l in lines:
            m=r.search(l);
            if m:
                nsink+=1;

    if nsink>=30:
        ok=True
    else:
        print("\033[31m\t- PulseAudio Null-Sinks:{} not set properly\033[0m".format(nsink))

    return ok,ver



def check_avencoder():
    f_avenc=False#avencoder
    ver='[unknown]'

    r=re.compile(r'avencode\s+([^\t ]+)\s+')

    with Popen(['dpkg-query -l'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines();

        for l in lines:
            m=r.search(l)
            if m:
                ver=m.groups()[0]
                f_avenc=True

    if not f_avenc:
        print("\033[31m\t- avencoder not install!!\033[0m")
        return False,ver

    nver=""
    with Popen(['which avencoder'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().splitlines();
        if len(lines)==0:
            print("\033[31m\t- avencoder not found!!\033[0m")
            f_avenc=False
        else:
            with Popen(['avencoder -?'],stdout=PIPE,shell=True) as sproc:
                lines=sproc.stdout.read().splitlines();
                #avencoder version 1.0.01.1
                r=re.compile(r'avencoder\s+version\s+([0-9.]+)')
                for l in lines:
                    m=r.search(l.decode())
                    if m:
                        nver=m.groups()[0]
                        f_avenc=True
#                        print("+ avencoder version :{}".format(m.groups()[0]))
                        break;
#    if ver!=nver:
#        print("\033[31m\t- avencoder conflict version [%s|%s]!!\033[0m"%(ver,nver))
#        f_avenc=False
#        ver='[conflict]'

    return f_avenc,nver


def check_bvbcs():
    ver="[unknown]"
    f_bvbcs=True#bvbcs

    with Popen(['which bvbcs'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().splitlines();
        if len(lines)==0:
            print("\033[31m\t- bvbcs not found!!\033[0m")
            f_bvbcs=False
        else:
            with Popen(['bvbcs -version'],stderr=PIPE,shell=True) as sproc:
                lines=sproc.stderr.read().decode().splitlines();
                r=re.compile(r'[a-zA-Z ]+([^(]+)\s+\(.*')
                if len(lines)>0:
                    m=r.search(lines[0])
                    ver=m.groups()[0]

    fl=os.listdir('/usr/share/X11')
    if not 'fonts' in fl:
        print('\033[31m\t-fonts(linkage) missing \033[0m')
        f_bvbcs=False

    if f_bvbcs:
        ftl=os.listdir('/usr/share/X11/fonts')
        if not 'misc' in ftl or not 'Type1' in ftl or not 'util' in ftl:
            print('\033[31m\t-X fonts missing (misc/Type1/util) \033[0m')
            f_bvbcs=False

    if not 'rgb.txt' in fl:
        print('\033[31m\t-rgb.txt(linkage) missing \033[0m')
        f_bvbcs=False

    return f_bvbcs,ver


def check_audio():
    ver="[unknown]"
    f_audio=True#bvbcs

    with Popen(['which AudioRecord'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().splitlines();
        if len(lines)==0:
#            print("\033[31m\t- AudioRecord not found!!\033[0m")
            f_audio=False

#    return f_audio,ver
#FIXME
    return f_audio,"1.0.00.1"
    

#        else:
#            with Popen(['AudioRecord  --version'],stdout=PIPE,shell=True) as sproc:
#                lines=sproc.stdout.read().decode().splitlines();
#                if len(lines)>0:
#                    print("+ {}\n".format(lines[0]))
#                else:
#                    print("- Unknown Google Chrome version")


def check_chrome():
    f_web=True
    ver="[unknown]"
    with Popen(['which google-chrome'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().splitlines();
        if len(lines)==0:
#            print("\033[31m\t- chrome not found!!\033[0m")
            f_web=False
        else:
            with Popen(['google-chrome --version'],stdout=PIPE,shell=True) as sproc:
                lines=sproc.stdout.read().decode().splitlines();
                if len(lines)>0:
                    ver=lines[0]
#                    print("+ {}".format(lines[0]))

    return f_web,ver

def check_vlc():
    f_vlc=False
    ver="[unknown]"

    r=re.compile(r'\s+vlc\s+([^\t ]+)\s+')

    with Popen(['dpkg-query -l|grep vlc'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines();
        for l in lines:
            m=r.search(l)
            if m:
                ver=m.groups()[0]
                f_vlc=True
                break
 

    return f_vlc,ver



def check_vlcplugin():
    f_vlc=True
    ver="[unknown]"
    r=re.compile(r'browser-plugin-vlc\s+([^\t ]+)\s+')

    with Popen(['dpkg-query -l|grep vlc'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines();
        if len(lines)==0:
            print("\033[31m\t- VLC not found!!\033[0m")
            f_vlc=False

        for l in lines:
            m=r.search(l)
            if m:
                ver=m.groups()[0]

    libs=os.listdir("/usr/lib/mozilla/plugins")
    if not 'libvlcplugin.so' in libs:
        print("\033[31m\t- libvlcplugin.so not found!!\033[0m");
        f_vlc=False
 

    return f_vlc,ver



def check_library(libs):

    ok=True 
    is_newavenc=False
#    libs=os.listdir('/usr/local/lib');
    if 'libvideoencoder_f.so' in libs:
        is_newavenc=True
    elif 'libvideoencoder.so' in libs:
        is_newavenc=False
    else:
        print("\033[31m **Missing libraries for RSM!!\033[0m\n")
        return ok

    if is_newavenc:
        if not 'libvideosource_f.so' in libs:
            print("\033[31m\t- 'libvideosource_f.so' not found!!\033[0m");
            ok=False 
#        else:
#            print("+ 'libvideosource_f.so' found!!");

        if not 'libvideoencoder_f.so' in libs:
            print("\033[31m\t- 'libvideoencoder_f.so' not found!!\033[0m");
            ok=False 
#        else:
#            print("+ 'libvideoencoder_f.so' found!!");

        if not 'libaudioencoder_f.so' in libs:
            print("\033[31m\t- 'libaudioencoder_f.so' not found!!\033[0m");
            ok=False 
#        else:
#            print("+ 'libaudioencoder_f.so' found!!");

        if not 'libaudiosource_f.so' in libs:
            print("\033[31m\t- 'libaudiosource_f.so' not found!!\033[0m");
            ok=False 
#        else:
#            print("+ 'libaudiosource_f.so' found!!");
 
        if not 'libtssmooth_f.so' in libs:
            print("\033[31m\t- 'libtssmooth_f.so' not found!!\033[0m");
            ok=False 
#        else:
#            print("+ 'libtssmooth_f.so' found!!");

        if not 'libavmuxer_f.so' in libs:
            print("\033[31m\t- 'libavmuxer_f.so' not found!!\033[0m");
            ok=False 
#        else:
#            print("+ 'libavmuxer_f.so' found!!");

    else:

        if not 'libvideosource.so' in libs:
            print("\033[31m\t- 'libvideosource.so' not found!!\033[0m");
            ok=False 
#        else:
#            print("+ 'libvideosource.so' found!!");

        if not 'libvideoencoder.so' in libs:
            print("\033[31m\t- 'libvideoencoder.so' not found!!\033[0m");
            ok=False 
#        else:
#            print("+ 'libvideoencoder.so' found!!");

        if not 'libaudioencoder.so' in libs:
            print("\033[31m\t- 'libaudioencoder.so' not found!!\033[0m");
            ok=False 
#        else:
#            print("+ 'libaudioencoder.so' found!!");

        if not 'libaudiosource.so' in libs:
            print("\033[31m\t- 'libaudiosource.so' not found!!\033[0m");
            ok=False 
#        else:
#            print("+ 'libaudiosource.so' found!!");
 
        if not 'libtssmooth.so' in libs:
            print("\033[31m\t- 'libtssmooth.so' not found!!\033[0m");
            ok=False 
#        else:
#            print("+ 'libtssmooth.so' found!!");

        if not 'libavmuxer.so' in libs:
            print("\033[31m\t- 'libavmuxer.so' not found!!\033[0m");
            ok=False 
#        else:
#            print("+ 'libavmuxer.so' found!!");
 

    return ok
    



def check_ffmpeg(libs):
 #check ffmpeg
    ok=True
   
    if 'libavcodec.so' in libs and 'libavformat.so' in libs and 'libavutil.so' in libs and 'libswscale.so' in libs and 'libswresample.so' in libs:
#        print("+ FFmpeg found!!");
        pass
    else:
        print("\033[31m\t- FFmpeg not found!!\033[0m");
        ok=False
    return ok




def check_ipp(libs):
    ok=True
    if 'libippccem64t.so' in libs and 'libippcoreem64t.so' in libs:
#        print("+ IPPCC found!!");
        pass
    else:
        ok=False
        print("\033[31m\t- IPP not found!!\033[0m");

    return ok



      


def check_fonts():
    ok=False
    fl=os.listdir('/usr/share/fonts/truetype')
    if 'msyhbd.ttf' in fl and 'msyh.ttf' in fl and 'SIMLI_0.TTF' in fl and 'SIMSUN.TTC' in fl and 'SIMYOU_0.TTF' in fl and 'STSONG_0.TTF' in fl and 'STXINGKA_0.TTF' in fl and '造字工房悦圆常规字YUEYUANZITI.OTF' in fl:
        ok=True
#        print("+ Fonts found..")
    else:
        print("\033[31m\t- Missing Fonts in[/usr/share/fonts/truetype]..\033[0m")
    
    return ok



def check_html():
    ok=True
    fl=os.listdir('/opt')
    if 'index.html' in fl and 'init.html' in fl:
#        print("+ Html for RSM found!!")
        pass
    else:
        ok=False
#        print("\033[31m\t- Html for RSM not found!!\033[0m")

    return ok




def check_vgl():

    ok=False
    vglver="unknown"

    with Popen(['dpkg-query --list'],stdout=PIPE,stderr=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'virtualgl\s+([-.0-9]+)')
        for l in lines:
            m=r.search(l)
            if m:
                ok=True
                vglver=m.groups()[0]
                break

    if not ok:
        print('\033[31m\t- virtualgl not installed.. \033[0m')
        return ok,vglver

 

    ok=True

    cmd="ls -l /dev/nvidia*"
    with Popen([cmd],stdout=PIPE,stderr=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'crw-rw-rw-')
        for l in lines:
            m=r.search(l)
            if not m:
                ok=False
                break
        

    cmd="ls -l /dev/dri/card*"
    with Popen([cmd],stdout=PIPE,stderr=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'crw-rw-rw-')
        for l in lines:
            m=r.search(l)
            if not m:
                ok=False
                break
 

    if not os.path.exists('/etc/modprobe.d/virtualgl.conf'):
        ok=False


    if not ok:
        print('\033[31m\t- vgl not configured,run [sudo vglserver_config -config +s +f +t] \033[0m')
        

    return ok,vglver





def check_gpudrv():
    ok=True
    with Popen(['which nvidia-smi'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines()
        if len(lines)==0:
            print("\033[31m\t- nvidia-smi not found,please install nvidia's proprietary driver!! \033[0m")
            ok=False
            return ok

    gpuver="<UNKNOWN>"
    ok=False
    with Popen(['nvidia-smi'],stdout=PIPE,shell=False) as proc:
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'Driver Version:\s*([0-9.]+)')
        for l in lines:
            m=r.search(l)
            if m:
                gpuver=m.groups()[0]
                ok=True
                break;

    gputype="XXXX"
    with Popen(['nvidia-smi -L'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines()
# GPU 0: GRID K1 (UUID: GPU-8e18deb7-96d0-1f47-d69b-71c2a6f6ec45)
        r=re.compile(r'GPU\s+(\d+):\s+([^(]+)')
        for l in lines:
            m=r.search(l)
            if m:
                gputype=m.groups()[1]
                break;



    return ok,gputype+'('+gpuver+')'




def check_gpu():

    ngpu=_get_gpu_core()
    ncore=0
    gputype="unknown"
    with Popen(['nvidia-smi -L'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines()
# GPU 0: GRID K1 (UUID: GPU-8e18deb7-96d0-1f47-d69b-71c2a6f6ec45)
        r=re.compile(r'GPU\s+(\d+):\s+([^(]+)')
        for l in lines:
            m=r.search(l)
            if m:
                ncore+=1
                gputype=m.groups()[1]


#    print("\033[33m\t- Total Cores:{} \033[0m".format(ngpu))

    return True,gputype


def check_xorg():
    ok=True
    with open('/etc/init/lightdm.conf','r')as f:
        lines=f.readlines();
#    print(filecnt)
#      and runlevel [!06]
#stop on runlevel [016]
    r0=re.compile(r'and\s+runlevel\s+\[!(\d+)\]')
    r1=re.compile(r'stop\s+on\s+runlevel\s+\[(\d+)\]')
    for l in lines:
        m0=r0.search(l)
        if m0: 
#            print(m0.groups())
            if m0.groups()[0]!="026":
                ok=False
#                print('\033[31m\t- lightdm not configure properly!!\033[0m')
                continue

        m1=r1.search(l)
        if m1: 
            if m1.groups()[0]!="0126":
                ok=False
#                print('\033[31m\t- lightdm not configure properly!!\033[0m')
                continue
    
    if not ok:
        print('\033[31m\t- lightdm not configure properly!!\033[0m')


    gpudict={};
    ngpu=0
    gpus=[];
    with Popen(["ls" ,"/proc/driver/nvidia/gpus"], stdout=PIPE,shell=False) as proc:
        gpus=proc.stdout.read().decode().splitlines()
#    print(gpus)
    ngpu=len(gpus)
    
    if 0==ngpu:
        ok=False
        print("\033[31m\t- Could not list /proc/driver/nvidia/gpus..\033[0m")
        return ok

    nlgpu=_get_gpu_core()

    if nlgpu!=ngpu:
        ok=False
        print("\033[31m\t- Should reinstall nvidia's proprietary driver\033[0m")
        return ok
        

    fl=os.listdir('/etc/X11/')
    for i in range(ngpu):
        it='xorg.conf.'+str(i)
        if not it in fl:
            ok=False
            print("\033[31m\t- missing {} ..\033[0m".format(it))



    with Popen(["lsmod |grep '\<nvidia\>'"],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines()
        if len(lines)<2:
            print("\n\033[31m\t- nvidia modules not load!! \033[0m")
            return False





    with Popen(["ps H -C Xorg -o pid,comm,cmd"], stdout=PIPE,shell=True) as proc:
        xlist=proc.stdout.read().decode().splitlines()
        nx=0
        r=re.compile(r'[Xx]org')
        for l in xlist:
            m=r.search(l)
            if m:
                nx+=1

        if nx !=ngpu:
            ok=False
            print("\033[31m\t- Not all Xorg are running (ps aux|grep X11) ..\033[0m")



    return ok



def check_memory():

#DBus configure,to avoid memory leak
    f_dbus=False
    f_sysctl=False

    with open('/etc/dbus-1/session.conf') as f:
        r=re.compile(r'\<unfork/\>')
        for l in f.readlines():
            m=r.search(l)
            if m:
                f_dbus=True
                break;
        else:
            print("\033[31m\t- DBus not configured..\033[0m")

    with Popen(['sysctl -a'],stdout=PIPE,stderr=PIPE,shell=True) as p:
        lines=p.stdout.read().decode().splitlines();
        r=re.compile(r'vm\.drop_caches\s*=\s*3')
        for l in lines:
            m=r.search(l)
            if m:
                f_sysctl=True
                break;
        else:
            print("\033[31m\t- sysctl not configured..\033[0m")



    return f_dbus and f_sysctl




def check_glx(ndisplay):
#    print('''
#    >>Check GLX extension of X11,required by VirtualGL
#''')
    ok=True
    r=re.compile(r'server glx version string')
    for d in range(ndisplay):
        cmd="/opt/VirtualGL/bin/glxinfo -display :{}|head".format(d);
        with Popen([cmd],stdout=PIPE,stderr=PIPE,shell=True) as proc:
            lines=proc.stdout.read().decode().splitlines()

#            print("=======================")
            for l in lines:
                m=r.search(l)
                if m:
#                    print("+ Display :"+str(d)+" GLX OK")
                    break;
            else:
                print("\033[31m\t- Display :"+str(d)+" GLX ERROR!!\033[0m")
                ok=False

#    print("\n")
    return ok









#def check_x264():
#
#    if 'libx264.so' in libs:
#        print("+ X264 found!!");
#    else:
#        ok=False
#        print("- X264 not found!!");










def print_check(name,ret,idx=[0]):
    idx[0]+=1
    i=idx[0]

    ndot=50-len(name)
    

    print("%2d. Check %s %s"%(i,name,ndot*"."),end=' ')
    if ret:
        print("\033[32mSuccess\033[0m")
    else:
        print("\033[31mFailed\033[0m")



def check_os():
    osver="<UNKNOWN>"
    with open('/etc/issue') as f:
        r=re.compile(r'([^\\]+).*')
        lines=f.readlines()
        for l in lines:
            m=r.search(l)
            if m:
                osver=m.groups()[0]
                break;

    return True,osver
 


def do_check():
#check gpu
 

    show_info();

#    ret,ver=check_os()
#    print_check("OS ["+ver+"]",ret)

    ret,ver=check_gpudrv()
    print_check("GPU Driver ["+ver+"]",ret)

    ret=check_xorg()
    print_check("Xorg",ret)

    ret,ver=check_vgl()
    print_check("VGL ["+ver+"]",ret)


    ngpu=_get_gpu_core()
    ret=check_glx(ngpu)
    print_check("GLX",ret)

    ret=check_memory()
    print_check("memory-config",ret)


    libs=os.listdir('/usr/local/lib');

    ret=check_ipp(libs)
    print_check("IPP",ret)

    ret,ver=check_pulse()
    print_check("pulseaudio ["+ver+"]",ret)

#    ret=check_library(libs)
#    print_check("avenc-libs",ret)

    ret,ver=check_avencoder()
    print_check("avencoder ["+ver+"]",ret)

    ret,ver=check_bvbcs()
    print_check("bvbcs ["+ver+"]",ret)

    ret,ver=check_chrome()
    print_check("web ["+ver+"]",ret)

    ret,ver=check_audio()
    print_check("audio ["+ver+"]",ret)

    ret,ver=check_vlc()
    print_check("vlc ["+ver+"]",ret)

    ret,ver=check_vlcplugin()
    print_check("vlcplugin ["+ver+"]",ret)


    ret=check_fonts()
    print_check("fonts",ret)

    ret=check_html()
    print_check("htmls",ret)


    print("\n\033[32m ** Check Over!!\033[0m\n")
#    if ok:
#        print("\n\033[32m ** Check Success\033[0m\n")
#    else:
#        print("\n\033[31m ** Check Failed!!\033[0m\n")







if __name__ == "__main__":


    version='1.0.02'

    to_do_check=False
    

    print(""+sys.argv[0]+" Version:"+version)
#    print("Usage: sudo "+sys.argv[0]+" -options...")
    sys.argv.pop(0);



    do_check();

