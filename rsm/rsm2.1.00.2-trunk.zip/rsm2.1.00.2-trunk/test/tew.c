#include"../eventworker.h"
#include<stdio.h>
#include<unistd.h>

int i=0;

static int dowork(void*d,void*dd){

    fprintf(stderr,"Do work %d(dd:%p),\n",i++,dd);

    eventworker_emit_event(d,10,dd);

}

static void* emit_work(void*d){

    eventworker_t*ew=(eventworker_t*)d;

    sleep(1);
    while(1){
        
    eventworker_emit_event(ew,10,ew);

    }
}

int main(int argc,char**argv)
{


    eventworker_t e;

    eventworker_init(&e);

    pthread_t tid;
    pthread_create(&tid,NULL,emit_work,&e);
    eventworker_register_event(&e,10,dowork,&e);


    eventworker_start(&e);


    return 0;

}
