
#include"rsm_net.h"
#include<stdio.h>
#include<stdlib.h>


int main()
{


    rsm_netlbinder_t*binder=rsm_netlbinder_new("/tmp/bind0");



    char buff[128];
    int ret;

    while(1){


        ret=rsm_netlbinder_recv(binder,buff,sizeof buff);


        fprintf(stderr,"(%d)[%s]\n",ret,buff);

        ret=rsm_netlbinder_reply(binder,"as",2);

        fprintf(stderr,"(%d)\n",ret);

    }




    return 0;


}
