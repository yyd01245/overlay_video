#!/bin/bash

#1.get plugins' url from rsm.conf

SAVPATH=/opt

URL=$(sed -r -n '/VNCMS\.CHROME_PLUGIN/{s/.+= *([^ #]+) *#*.*/\1/p}' rsm.conf)

echo $URL

#2.save file
sudo wget $URL -O $SAVPATH &>/dev/null

#3.uncompress 
