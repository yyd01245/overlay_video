#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"rsm_net.h"
#include<unistd.h>
#include<time.h>


#define JSON_OPENAVENC "{\"action\":\"open-avenc\",\"destaddr\":\"192.168.70.101:4072\",\"rate\":\"3072\"}"
#define JSON_CLOSEAVENC "{\"action\":\"close-avenc\"}"

#define JSON_OPENWEBC "{\"action\":\"open-webc\"}"
#define JSON_CLOSEWEBC "{\"action\":\"close-webc\"}"

void mk_msg(char*obuff,int osiz,int id){

    if(id==0){
        strlcpy(obuff,JSON_OPENWEBC,osiz);
    }else if(id==1){
        strlcpy(obuff,JSON_CLOSEWEBC,osiz);
    }else if(id==2){
        strlcpy(obuff,JSON_OPENAVENC,osiz);
    }else{
        strlcpy(obuff,JSON_CLOSEAVENC,osiz);

    }



}



int main(int argc,char**argv)
{

    int idx=1;
    if(argc>1)
        idx=atoi(argv[1]);

    char sbuff[128];
    char rbuff[128]={0,};

    rsm_netsender_t* sndr=rsm_netsender_new("0.0.0.0",63000+idx);

    int c=0;

    int ret;

   
    srand(time(NULL));

    while(1){
        
    int i=rand()%4;

   
    mk_msg(sbuff,sizeof sbuff,i);
    fprintf(stderr,"%d:ToSend  %d[%s]\n",c,i,sbuff);
        
    ret=rsm_netsender_shot(sndr,sbuff,strlen(sbuff),rbuff,sizeof(rbuff));

    fprintf(stderr,"%d:Receive %d[%s]\n",c,i,rbuff);

    sleep(1);
    c++;
    }










}
