
#include<stdio.h>
#include"../rsm_utils.h"

int main(int argc,char**argv)
{


cJSON*pj=rsm_parse_json_file(argv[1]);


cJSON*pv=cJSON_GetObjectItem(pj,"version");

printf("version:%s\n",pv->valuestring);

printf("%s\n",
cJSON_Print(pj));

return 0;

}
