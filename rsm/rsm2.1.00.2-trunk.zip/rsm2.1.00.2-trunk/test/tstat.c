#include<unistd.h>
#include<stdio.h>
#include<string.h>
#include<errno.h>
#include<sys/types.h>
#include<sys/stat.h>


int main(int argc,char**argv)
{



    int ret;
    
    struct stat sb;
    ret=stat(argv[1],&sb);
    if(ret<0){
        fprintf(stderr,"-1111,{%s}\n",strerror(errno));
    } 






}
