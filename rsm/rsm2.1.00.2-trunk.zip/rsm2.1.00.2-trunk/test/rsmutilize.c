#include"rsm_utils.h"
#include<stdio.h>


int main(int argc,char**argv)
{



    cpu_stat o={0,};
    cpu_stat n={0,};
    mem_stat m={0,};
    gpu_stats g={0,};

    while(1){
        
        get_gpustats(&g);
        get_memstat(&m);
        get_cpustat(&n);
        int val=calc_cpuoccupy(&o,&n);
        int mval=calc_memoccupy(&m);

        o=n;

        int gu,mu,encu,decu;
        calc_gpuoccupy(&g,&gu,&mu,&encu,&decu);




        printf("CPU status:%d .mem:%d\n",val,mval);
        printf("Gpu :%d .mem:%d .enc:%d, dec:%d\n",gu,mu,encu,decu);

        sleep(1);
    }



    return 0;

}










