
#include<unistd.h>
#include"rsm_net.h"
#include<stdio.h>
#include<stdlib.h>


int main()
{


    rsm_netlsender_t*sender=rsm_netlsender_new("/tmp/bind0");



    char buff[128];
    int ret;

    while(1){

        ret=read(1,buff,sizeof buff);

        fprintf(stderr,"(%d)[%s]--\n",ret,buff);
        ret=rsm_netlsender_send(sender,buff,ret);

        ret=rsm_netlsender_recv(sender,buff,sizeof buff);
        fprintf(stderr,"(%d)[%s]\n",ret,buff);


    }




    return 0;


}
