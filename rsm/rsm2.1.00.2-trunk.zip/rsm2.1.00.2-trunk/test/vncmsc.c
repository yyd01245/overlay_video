
#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include"../rsm_net.h"
#include"../vncms_msg.h"

#define OFFSET 63000



int main(int argc,char**argv){



    rsm_netsenders_t*snd=rsm_netsenders_new("0.0.0.0",OFFSET+atoi(argv[1]));
    

    char msgbuf[128];
    char rbuff[256];

#if 0

    int i;
    while(1){

        int v=i%5;
        if(v==0) 
            snprintf(msgbuf,sizeof msgbuf,"{\"action\":\"open-webc\"}");
        else if(v==1)
            snprintf(msgbuf,sizeof msgbuf,"{\"action\":\"close-webc\"}");
        else if(v==2)
            snprintf(msgbuf,sizeof msgbuf,"{\"action\":\"reset\"}");
        else if(v==3)
            snprintf(msgbuf,sizeof msgbuf,"{\"action\":\"open-audio\"}");
        else if(v==4)
            snprintf(msgbuf,sizeof msgbuf,"{\"action\":\"close-audio\"}");


        int ret=rsm_netsenders_shot(snd,msgbuf,strlen(msgbuf),rbuff,sizeof rbuff);

        printf("ret=%d\n",ret);

        printf("\033[32m[%s]==>\n[%s]\033[0m\n",msgbuf,rbuff);

        i++;
        sleep(1);
    }


#else

    int ret;


    snprintf(msgbuf,sizeof msgbuf,"{\"action\":\"reset\"}");
    ret=rsm_netsenders_shot(snd,msgbuf,strlen(msgbuf),rbuff,sizeof rbuff);
    msgbuf[ret]=0;

    sleep(1);



    snprintf(msgbuf,sizeof msgbuf,"{\"action\":\"open-webc\"}");
    ret=rsm_netsenders_shot(snd,msgbuf,strlen(msgbuf),rbuff,sizeof rbuff);
    msgbuf[ret]=0;


#endif

    return 0;
}
