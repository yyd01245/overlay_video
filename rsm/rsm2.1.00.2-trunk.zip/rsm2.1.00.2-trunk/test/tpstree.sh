#!/bin/bash




node=${1:-"1"}


while [ 1 ];do


    echo     pstree -ulp $node
    pstree -ulp $node

    sleep 1


done
