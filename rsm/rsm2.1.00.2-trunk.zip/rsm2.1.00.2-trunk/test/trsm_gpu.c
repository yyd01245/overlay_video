#include"../rsm_utils.h"
#include<stdio.h>
#include<unistd.h>
int main(int argc,char**argv)
{

    int c=0;
    while(1){
        c=get_next_core_for_vgl();
        fprintf(stderr,"Core:%d\n",c);
        sleep(1);
        int i=0;
        while(i++<8){
            c=get_next_core_for_vgl();
            fprintf(stderr,"Core:%d\n",c);

        }


    }




}
