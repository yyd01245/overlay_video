#!/usr/bin/python3

from subprocess import *
import sys
import re
import os
import shutil


#0 for bluelink
#1 for nvidia
platform=0

def _get_gpu_core():
    gpuids=[]
    with Popen(['lspci'],stdout=PIPE)as proc:
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'([0-9a-z]+:[0-9a-z]+\.[0-9a-z]+)\ +VGA.+NVIDIA')
        for l in lines:
            m=r.search(l)
            if m:
                gpuids.append(m.groups()[0])
        print("\n-->GPU.busids")
        print(gpuids)
        print("\n")
        return len(gpuids)            

def _get_bluelink_card():
    encids=[]
    with Popen(['lspci'],stdout=PIPE)as proc:
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'([0-9a-z]+:[0-9a-z]+\.[0-9a-z]+).+Texas')
        for l in lines:
            m=r.search(l)
            if m:
                encids.append(m.groups()[0])
        print("\n-->Bluelink.busids")
        print(encids)
        print("\n")
        return len(encids)         


def check_bluelink(nenc):
#    nenc=_get_bluelink_card()
#    if nenc==0:
#        return False
    with Popen(["cat  /proc/netra |sed '/banka_productname/d'"],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().decode().splitlines()
        r=re.compile(r'\[dev_status_\d+\]')
        nitem=0
        for l in lines:
            m=r.search(l)
            if m:
                nitem+=1
        if nitem!=nenc:
            print("Error: /proc/netra file malformed..")

#chan_4_19_status=bad
    r=re.compile(r'chan_.+_status=([a-z])')
    nchan=0;
    nfree=0;
    nbad=0;
    for l in lines:
        m=r.search(l)
        if m:
            nchan+=1
            if m.groups()[0]=='free':
                nfree+=1
            if m.groups()[0]=='bad':
                nbad+=1
            
    print("Total Channels:{} free:{} + bad:{}".format(nchan,nfree,nbad))
    if nbad!=0:
        return False

    return True


def check_pulse():

    ok=False
    with open('/etc/pulse/default.pa') as f:
        lines=f.readlines()
        r=re.compile(r'load-module\ +module-null-sink\ +sink_name=(\d+)')
        nsink=0
        for l in lines:
            m=r.search(l);
            if m:
                nsink+=1;

        print("Total Null-Sinks: {}".format(nsink))
    if not nsink==0:
        ok=True

    return ok

def check_binary():
    print('''
    ++Check Binary.
            ''')
    f_avenc=False#avencoder
    f_bvbcs=False#bvbcs
    f_audio=False#AudioRecord
    f_chrome=False#google-chrome

    with Popen(['which avencoder'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().splitlines();
        if len(lines)==0:
            print("\033[31m avencoder not found!!\033[0m\n")
        else:
            with Popen(['avencoder -?'],stdout=PIPE,shell=True) as sproc:
                lines=sproc.stdout.read().splitlines();
                #avencoder version 1.0.01.1
                r=re.compile(r'avencoder\ +version\ +([0-9.]+)')
                f=False
                for l in lines:
                    m=r.search(l.decode())
                    if m:
                        print("- avencoder version :{}\n".format(m.groups()[0]))
                        f=True
                        break;
                if not f:
                    print("- avencoder version UNKNOW\n")




    with Popen(['which bvbcs'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().splitlines();
        if len(lines)==0:
            print("\033[31m bvbcs not found!!\033[0m\n")
        else:
            with Popen(['bvbcs -version'],stderr=PIPE,shell=True) as sproc:
                lines=sproc.stderr.read().decode().splitlines();
                if len(lines)>0:
                    print("- {}\n".format(lines[0]))
                else:
                    print("- Unknown BVBCS version")




    with Popen(['which AudioRecord'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().splitlines();
        if len(lines)==0:
            print("\033[31m AudioRecord not found!!\033[0m\n")
#        else:
#            with Popen(['AudioRecord  --version'],stdout=PIPE,shell=True) as sproc:
#                lines=sproc.stdout.read().decode().splitlines();
#                if len(lines)>0:
#                    print("- {}\n".format(lines[0]))
#                else:
#                    print("- Unknown Google Chrome version")



    with Popen(['which google-chrome'],stdout=PIPE,shell=True) as proc:
        lines=proc.stdout.read().splitlines();
        if len(lines)==0:
            print("\033[31m chrome not found!!\033[0m\n")
        else:
            with Popen(['google-chrome --version'],stdout=PIPE,shell=True) as sproc:
                lines=sproc.stdout.read().decode().splitlines();
                if len(lines)>0:
                    print("- {}\n".format(lines[0]))
                else:
                    print("- Unknown Google Chrome version")



def check_library():
    
    libs=os.listdir('/usr/local/lib');
    
    if 'libvideosource.so' in libs:
        pass
#TODO






RCLOCAL_PATH="/etc/init.d/rc.local"
#RCLOCAL_PATH="rc.local"


def config_bluelink():
    print('''
    >>Configure Bluelink'encoder 
''')
#start 
#/etc/init.d/dm816x start 63
    with open(RCLOCAL_PATH,"r+") as f:
        lines=f.readlines();
        print(lines)
        r=re.compile(r'.+dm816x\ +start')
        #/etc/init.d/init-enc.sh
        rc=re.compile(r'/init-enc\.sh')#for backward compatible    

        nlines=[]
        ok=False
        for l in lines:
            m=r.search(l)
            if m:
                ok=True
                #OK
            m=rc.search(l)
            if m:
                continue

            nlines.append(l) 
    
        if not ok:
            nlines.append("/etc/init.d/dm816x start 63\n")
    
        f.truncate(0)
        f.seek(0,0)
        f.writelines(nlines)
        f.close()
    return True    


def config_gpu():
    print('''
    >>Configure Nvidia and X
''')
    ok=False
    gpudict={};
    ngpu=0
    gpus=[];
    with Popen(["ls" ,"/proc/driver/nvidia/gpus"], stdout=PIPE,shell=False) as proc:
        gpus=proc.stdout.read().decode().splitlines()
#    print(gpus)
    ngpu=len(gpus)
    
    if 0==ngpu:
        print("ERROR::Could not list /proc/driver/nvidia/gpus..")
        return ok

    r=re.compile(r'\d+:([a-z0-9A-Z]+):([a-z0-9A-Z]+)\.([a-z0-9A-Z]+)')
#0000:02:00.0
    i=0
    for bus in gpus:
        m=r.search(bus)
        busid_str=m.groups()
        busid_int=int(busid_str[0],16),int(busid_str[1],16),int(busid_str[2],16)
        busid_str=str(busid_int[0]),str(busid_int[1]),str(busid_int[2])
        gpudict[i]=":".join(busid_str)
        i+=1

#    print(gpudict)

#nvidia-xconfig --busid=PCI:$id:0:0 --use-display-device=None --force-generate --no-probe-all-gpus -o ${file}
    for k in gpudict.keys():
        cmd="nvidia-xconfig --busid=PCI:"+gpudict[k]+" --use-display-device=None --force-generate --no-probe-all-gpus -o /etc/X11/xorg.conf."+str(k)
        print(cmd);
        with Popen([cmd],stdout=PIPE,shell=True) as proc:
            pass
	
#        Popen([cmd],shell=True);

#disable lightdm for launch X session
    with open('/etc/init/lightdm.conf','r+')as f:
        lines=f.readlines();
        nlines=[] 
    #    print(filecnt)
    #      and runlevel [!06]
    #stop on runlevel [016]
        r0=re.compile(r'and\ +runlevel\ +\[!(\d+)\]')
        r1=re.compile(r'stop\ +on\ +runlevel\ +\[(\d+)\]')
        for l in lines:
            m0=r0.search(l)
            if m0:
    #            print(m0.groups())
                if m0.groups()[0]!="026":
                    nlines.append("\t\tand runlevel [!026]\n")
                    continue
    
            m1=r1.search(l)
            if m1:
                if m1.groups()[0]!="0126":
                    nlines.append("stop on runlevel [0126]\n")
                    continue
    
            nlines.append(l)
           
        f.truncate(0)
        f.seek(0,0)
        f.writelines(nlines)
        f.close()

    
#write X to rc.local
#X -config /etc/X11/xorg.conf.0 :0 -sharevts
    with open(RCLOCAL_PATH,'r+')as f:
        lines=f.readlines()
        nlines=[]
        r=re.compile(r'X\ +-config ')
        for l in lines:
            m=r.search(l)
            if not m:
                nlines.append(l)
    
    
        for v in range(ngpu):
            l="X -config /etc/X11/xorg.conf.{} :{} -sharevts &\n".format(v,v)
            nlines.append(l)
    
        print(nlines)
        f.truncate(0)
        f.seek(0,0)
        f.writelines(nlines)
        f.close() 
    
    ok=True
    return ok


def check_glx(ndisplay):
    print('''
    >>Check GLX extension of X11,required by VirtualGL
''')
    ok=True
    r=re.compile(r'server glx version string')
    for d in range(ndisplay):
        cmd="glxinfo -display :{}|head".format(d);
        with Popen([cmd],stdout=PIPE,stderr=PIPE,shell=True) as proc:
            lines=proc.stdout.read().decode().splitlines()
            print("=======================")
            for l in lines:
                m=r.search(l)
                if m:
                    print("Display :"+str(d)+" GLX OK")
                    break;
            else:
                print("Display :"+str(d)+" GLK ERROR")
                ok=False
    print("\n")
    return ok



def do_vgl():
    pass



def cleanup_rsmlog():

    print('''
    >>Cleanup RSM log
''')
    cwd=os.getcwd()
    if cwd.find('rsm-release')<0:
        print("CWD={},not in `rsm-release'".format(cwd))
        return False
    fl=os.listdir(cwd)
    if not 'log' in fl:
        print("Caution: directory `log' not found.")
        return False
    lf=os.listdir(cwd+'/log')
    for i in lf:
        if i.find('log')>0:
            os.remove(cwd+'/log/'+i)
    
    return True



def cleanup_tmp():
    print('''
    >>Cleanup temporal file under /tmp .
''')

    #rm chrome files
    fl=os.listdir("/tmp")
#    print(fl)
    print("sizeof fl:"+str(len(fl)))
    r=re.compile(r'.com.google.Chrome.[a-zA-Z0-9]+');
    for l in fl:
        m=r.search(l)
        if m:
            print("/tmp/"+l)
            shutil.rmtree("/tmp/"+l)

    r=re.compile(r'chrome[0-9]+');
    for l in fl:
        m=r.search(l)
        if m:
            print("/tmp/"+l)
            shutil.rmtree("/tmp/"+l)

    r=re.compile(r'smooth.log.[0-9]+')
    for l in fl:
        m=r.search(l)
        if m:
            print("/tmp/"+l)
            os.remove("/tmp/"+l)
#
#avencoder.19
    r=re.compile(r'avencoder.[0-9]+')
    for l in fl:
        m=r.search(l)
        if m:
            print("/tmp/"+l)
            os.remove("/tmp/"+l)

#pulse-1yhc3uavuaOb
    r=re.compile(r'pulse-[0-9a-zA-Z]{6,}')
    for l in fl:
        m=r.search(l)
        if m:
            print("/tmp/"+l)
            shutil.rmtree("/tmp/"+l)
#remove Xvnc' lock
    return True



def do_check():
    platform=0
    print('''
++Do Check
''')
    ncard=_get_bluelink_card()
    if ncard>0:
        platform=0
    else:
        platform=1

    if platform==0:
        print("\033[32m==Platform:: BlueLink\033[0m")
        check_bluelink(ncard)
    elif platform==1:
        print("\033[32m==Platform:: Nvidia\033[0m")
    else:
        print("\033[32m==Platform:: UNKNOWN\033[0m")

#check gpu
    ngpu=_get_gpu_core()
    check_glx(ngpu)

    check_binary()
    check_library()
    #check_other()




def do_cleanup():
    print('''
++Do Cleanup
''')
    cleanup_tmp()
    cleanup_rsmlog()
    #cleanup_other()



def do_config():
    print('''
++Do Config
''')
    ncard=_get_bluelink_card()
    if ncard!=0: 
        config_bluelink()

    config_gpu()

    #check_other()





if __name__ == "__main__":



    to_do_check=False
    to_do_config=False
    to_do_cleanup=False
    

    print("Usage: sudo "+sys.argv[0]+" -options...")
    sys.argv.pop(0);



    print("Argvs:"+str(sys.argv))
    for arg in sys.argv:
        if arg=="-check":
            to_do_check=True
            continue;
        if arg=="-clean":
            to_do_cleanup=True;
            continue
        if arg=="-config":
            to_do_config=True
            continue
    

        
    if not to_do_check and not to_do_cleanup and not to_do_config:
        to_do_check=True;

    
    if to_do_check:
        do_check();

    if to_do_config:
        do_config();

    if to_do_cleanup:
        do_cleanup();


