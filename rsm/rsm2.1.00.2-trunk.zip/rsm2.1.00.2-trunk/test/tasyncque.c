#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include"rsm_log.h"






rsm_log_t logger;

int ss;


static void* _log_thr(void*arg){

    int i=(int)arg;
    int c=0;

    while(1){

    rsm_log(&logger,LOG_LEVEL_MSG,"MDMD","(%d)_%d_:[%d]...",i,c,"HelLo");

    c++;
    }

    return 0;

}




int main(int argc,char** argv)
{



    pthread_t tid[5];

    rsm_log_init(&logger);


    rsm_log_reset_func(&logger,"tlog.log");

    int i;
    for(i=0;i<5;i++ )
    pthread_create(&tid[0],NULL,_log_thr,i);

    
    while(1){
        pause();
    }



    return EXIT_SUCCESS;
}
