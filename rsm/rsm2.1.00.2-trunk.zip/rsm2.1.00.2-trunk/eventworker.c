#include"eventworker.h"

#include<string.h>
#include<stdlib.h>
#include<stdio.h>

#include"rzut/chks.h"
#include"rzut/defs.h"


int eventworker_init(eventworker_t*ew)
{
    int ret;


    return_val_if_fail(ew!=NULL,-1);
    bzero(ew,sizeof(eventworker_t));
    
    INIT_LIST_HEAD(&ew->workers);

    ret=async_que_init(&ew->evtq);
    CHK_RUN(ret<0,"Init event queue Failed..",
            return -2);

    strlcpy(ew->name,"Eventworker",sizeof ew->name);

    pthread_mutexattr_t mtxattr;
    pthread_mutexattr_init(&mtxattr);
    pthread_mutexattr_settype(&mtxattr,PTHREAD_MUTEX_RECURSIVE);

    pthread_mutex_init(&ew->lock,&mtxattr);
    pthread_mutexattr_destroy(&mtxattr);

    return 0;
}


void eventworker_fini(eventworker_t*ew)
{

    return_if_fail(ew!=NULL);

    pthread_mutex_destroy(&ew->lock);

    async_que_fini(&ew->evtq);

    evtwork_t*pwk,*savwk;
    list_for_each_entry_safe(pwk,savwk,&ew->workers,list){

        free(pwk);
    }

}


void eventworker_setname(eventworker_t*ew,const char*name)
{
    strlcpy(ew->name,name,sizeof ew->name);
}


int eventworker_unregister_event(eventworker_t*ew,int type)
{

    int ret=-2;
    return_val_if_fail(ew!=NULL,-1);


    evtwork_t*pwk,*savwk;
    pthread_mutex_lock(&ew->lock);
    list_for_each_entry_safe(pwk,savwk,&ew->workers,list){

        if(pwk->type==type){
            list_del(&pwk->list);
            free(pwk);
            ew->nb_workers--;
            break;
        }
    }

    pthread_mutex_unlock(&ew->lock);

    return 0;

}


int eventworker_register_event(eventworker_t*ew,int type,eventworker_func func,void*workdata)
{

    int ret;
    return_val_if_fail(ew!=NULL,-1);

    evtwork_t*nwk;
    nwk=calloc(1,sizeof(evtwork_t));
    CHK_RUNe(!nwk,"Allocate Failed..",return -2);

    nwk->type=type;
    nwk->func=func;
    nwk->workdata=workdata;
//1.Remove Exists' event
    evtwork_t*pwk,*savwk;
    pthread_mutex_lock(&ew->lock);
    list_for_each_entry_safe(pwk,savwk,&ew->workers,list){
//    fprintf(stderr,"search work\n");
        if(pwk->type==type){
            list_del(&pwk->list);
            free(pwk);
            ew->nb_workers--;
            break;
        }
    }
//    pthread_mutex_unlock(&ew->lock);
//    pthread_mutex_lock(&ew->lock);
//2.Add New Event.
    list_add(&ew->workers,&nwk->list);
    ew->nb_workers++;
    pthread_mutex_unlock(&ew->lock);

//    fprintf(stderr,"----\n");
    return 0;
}


static void*arbiter_thread(void*arg);

int eventworker_start(eventworker_t*ew)
{

    int ret;
    return_val_if_fail(ew!=NULL,-1);

    pthread_attr_t arbiter_attr;
    pthread_attr_init(&arbiter_attr);
    pthread_attr_setdetachstate(&arbiter_attr,PTHREAD_CREATE_JOINABLE);

    ret=pthread_create(&ew->arbiter_tid,&arbiter_attr,arbiter_thread,ew);
    pthread_attr_destroy(&arbiter_attr);
    CHK_RUNe(ret<0,"Create Arbiter Thread Failed..",return -2);


    ret=pthread_join(ew->arbiter_tid,NULL);
    CHK_RUNe(ret<0,"Join Arbiter Thread Failed..",return -3);

    return 0;
}


#if 0
int eventworker_stop(eventworker_t*ew)
{
    int ret;
    return_val_if_fail(ew!=NULL,-1);

    ret=pthread_cancel(ew->arbiter_tid);
    CHK_RUNe(ret!=0,"Thread Cancel Failed..",return -2) ;

    return 0;
}
#else

int eventworker_stop(eventworker_t*ew)
{
    
    int ret;
    return_val_if_fail(ew!=NULL,-1);
    
    return eventworker_emit_event(ew,EV_BRK,NULL);

}
#endif


int eventworker_emit_event(eventworker_t*ew,int type,void*userdata)
{
    
//    fprintf(stderr,"++Emit\n");
    int ret;
    return_val_if_fail(ew!=NULL,-1);

    evtinfo_t*nev=calloc(1,sizeof(evtinfo_t));
    CHK_RUNe(!nev,"Allocate evtinfo.",
            return -2);

    nev->type=type;
    nev->userdata=userdata;

    ret=async_que_enque(&ew->evtq,nev);
    CHK_EXPR(ret<0,"Enqueue New Event.")
        free(nev);
        return -3;
    END_CHK_EXPR

    return 0;
}




static void*arbiter_thread(void*arg)
{

    int ret;
    eventworker_t*ew=(eventworker_t*)arg;
    pthread_setname_np(pthread_self(),ew->name);

    evtwork_t*pwk,*savwk;
    evtinfo_t*pev;
    while(1){

        ret=async_que_deque(&ew->evtq,(void**)&pev);

        CHK_EXPR(pev->type==EV_BRK,"Break EventWorker..")
            free(pev);
            break;
        END_CHK_EXPR
        

        pthread_mutex_lock(&ew->lock);
        list_for_each_entry_safe(pwk,savwk,&ew->workers,list){

            if(pev->type==pwk->type){
                ret=pwk->func(pwk->workdata,pev->userdata);
                if(ret==EVW_ONCE){
                    list_del(&pwk->list);
                    free(pwk);
                    ew->nb_workers--;
                }

                break;
            }
        } 
        pthread_mutex_unlock(&ew->lock);

        free(pev);

    }


    return NULL;
}


