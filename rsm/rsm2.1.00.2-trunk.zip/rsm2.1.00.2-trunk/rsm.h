#ifndef _H_RSM_
#define _H_RSM_

#include"rsm_log.h"

#define MODULE "RSM"

#define RSM_VERSION "2.1.00.2"

extern rsm_log_t* global_rsmlog;

#ifdef RSM_LOG_DEBUG
#undef RSM_LOG_DEBUG
#endif
#define RSM_LOG_DEBUG(fmt,args...)\
        rsm_log(global_rsmlog,LOG_LEVEL_DEBUG,MODULE,fmt,##args);


#ifdef RSM_LOG_INFO
#undef RSM_LOG_INFO
#endif
#define RSM_LOG_INFO(fmt,args...)\
        rsm_log(global_rsmlog,LOG_LEVEL_INFO,MODULE,fmt,##args);


#ifdef RSM_LOG_MSG
#undef RSM_LOG_MSG
#endif
#define RSM_LOG_MSG(fmt,args...)\
        rsm_log(global_rsmlog,LOG_LEVEL_MSG,MODULE,fmt,##args);


#ifdef RSM_LOG_WARN
#undef RSM_LOG_WARN
#endif
#define RSM_LOG_WARN(fmt,args...)\
        rsm_log(global_rsmlog,LOG_LEVEL_WARN,MODULE,fmt,##args);


#ifdef RSM_LOG_ERROR
#undef RSM_LOG_ERROR
#endif
#define RSM_LOG_ERROR(fmt,args...)\
        rsm_log(global_rsmlog,LOG_LEVEL_ERROR,MODULE,fmt,##args);



#ifndef SET_THREAD_NAME
#define SET_THREAD_NAME(name) \
    pthread_setname_np(pthread_self(),name)
#endif




#endif
