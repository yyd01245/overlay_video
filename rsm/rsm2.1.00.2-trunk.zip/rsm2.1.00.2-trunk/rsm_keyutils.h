#ifndef _H_KEYUTILS_RSM_
#define _H_KEYUTILS_RSM_


#include"rfb/keysym.h"
#include"keydefs.h"


#include<stdint.h>



#define SWAP32(val) (((val<<24)&0xff000000)|\
                      ((val>>24)&0x000000ff)|\
                      ((val<<8)&0x00ff0000)|\
                      ((val>>8)&0x0000ff00)\
                      )

#define SWAP16(val) (((val<<8)&0xff00)|\
                      ((val>>8)&0x00ff)\
                      )


#if 0
#define rfbPointerEvent   5
#define rfbKeyEvent   4


typedef struct _rfbKeyEventMsg{

    uint8_t type;
    uint8_t down;
    uint16_t pad;
    uint32_t key;

}rfbKeyEventMsg;


typedef struct _rfbPointerEventMsg{

    uint8_t     type;
    uint8_t     buttonMask;
    uint16_t    x;
    uint16_t    y;

}rfbPointerEventMsg;

#endif

typedef struct key_agent{

    struct sockaddr_un addr;
    char msgbuff[64];
    int sockfd;

}KeyAgent;



int init_keyagent(KeyAgent*ka,int idx);

int send_pointer_event(KeyAgent*ka,int x,int y,int buttonMask);
int send_key_event(KeyAgent*ka,int key,int down);





int combine_key(BlcYunKeyIrrMsg* irrmsg);//组合键


int conv_key_type(BlcYunKeyIrrMsg* irrmsg);//遥控器及机顶盒前面板


int conv_keyboard_value(BlcYunKeyKeyboardMsg* keboardmsg,int opt);//键盘


int conv_wheel_type(BlcYunKeyMouseMsg* mousemsg);//鼠标滚轮



int conv_mouse_type(BlcYunKeyMouseMsg* mousemsg);//鼠标










#endif
