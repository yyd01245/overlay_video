
#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<signal.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<time.h>
#include<pwd.h>
#include<pthread.h>



#include"rsm_vncms.h"
#include"rsm_utils.h"
#include"rsm_config.h"
#include"rsm_log.h"
#include"rsm_keyutils.h"

#include"rzut/chks.h"
#include"rzut/defs.h"
#include"asyncqueue.h"

#include"keydefs.h"
#include"vncms_msg.h"
#include"rsm_msg.h"

#include"vncms.h"


//GLOBAL
rsm_log_t*global_vncmslog;

//calculate sink number`{1..8}` & userid`X{00..}` from index
static int index1(idx_t index,int*osink,int*ouid,int pa_amount)
{

    int ret;
//    return_val_if_fail((index>0&&index<100&&pa_amount>0),-1);
#if 0
    *ouid=(index-1)/8;
    *osink=(index-1)%8;
#else

    int s;
    *ouid=(index-1)/pa_amount;
    s=index%pa_amount;
    if(s==0)
        s=pa_amount;
        
    *osink=s;

#endif
    return 0;
}



static void switch_user_to(rsm_vncms_t*vncms)
{
    int ret;
    char unam[16];
    snprintf(unam,sizeof(unam),"x%.2d",vncms->userid);

    VNCMS_LOG_MSG(vncms->index,"Switch User to [%s]",unam);
    struct passwd*urec=getpwnam(unam);
    if(urec){
        ret=setuid(urec->pw_uid);
        CHK_EXPRe(ret<0,"Setuid() Failed..")
            VNCMS_LOG_WARN(vncms->index,"Switch to user[%s] Failed",unam);
        END_CHK_EXPRe

        ret=setenv("HOME",urec->pw_dir,1);
//        CHK_EXPRe_ONLY(ret<0,"Set HOME Failed..");
    }else{
        VNCMS_LOG_WARN(vncms->index,"No such user[%s]",unam);
    }

}

static int switch_to_root(rsm_vncms_t*pvncms)
{
    int ret; 
  
    VNCMS_LOG_MSG(pvncms->index,"Switch to [root]");
    struct passwd*urec=getpwnam("root");

    ret=setuid(urec->pw_uid);
    CHK_EXPRe(ret<0,"SetUid to root failed")
        VNCMS_LOG_WARN(pvncms->index,"Switch to [root] Failed");
        return -1;
    END_CHK_EXPRe

    return 0;
}



static void rsm_vncms_init_system(rsm_vncms_t*vncms)
{
    pthread_mutex_init(&vncms->othlock,NULL);
    pthread_cond_init(&vncms->othcond,NULL);
}


static void rsm_vncms_fini_system(rsm_vncms_t*vncms)
{
    pthread_mutex_destroy(&vncms->othlock);
    pthread_cond_destroy(&vncms->othcond);
}



static int rsm_vncms_system(rsm_vncms_t*vncms,const char*cmd)
{
    int ret;

    int pid=fork();
    if(pid<0){
        VNCMS_LOG_ERROR(vncms->index,"vncms_system Failed(fork)..");
        return -1;
    }
    if(pid!=0){
        vncms->otherid=pid; 
        pthread_mutex_lock(&vncms->othlock);

        while(vncms->otherid!=0){
//            fprintf(stderr,"\033[31mXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\033[0m");
            pthread_cond_wait(&vncms->othcond,&vncms->othlock);
        }

        pthread_mutex_unlock(&vncms->othlock);

        return 0;
    }

    ret=execlp("/bin/sh","sh","-c",cmd,NULL);

    return EXEC_FAIL;
}



static void rm_x_lock(rsm_vncms_t*vncms)
{
    int ret; 
    char act[128];

    snprintf(act,sizeof(act),"/tmp/.X%d-lock",vncms->index);

    ret=unlink(act);
    CHK_EXPRe(ret<0 && errno!=ENOENT ,"Unlink X-lock..")
        VNCMS_LOG_WARN(vncms->index,"Remove X lock Failed..");
    END_CHK_EXPRe

    snprintf(act,sizeof(act),"/tmp/.X11-unix/X%d",vncms->index);
    ret=unlink(act);
    CHK_EXPRe(ret<0 && errno!=ENOENT,"Unlink X11unix-lock..")
        VNCMS_LOG_WARN(vncms->index,"Remove X11 unix-lock Failed..");
    END_CHK_EXPRe

}


static void rm_chrome_userdata(rsm_vncms_t*vncms){

    VNCMS_LOG_MSG(vncms->index,"TO Remove Chrome Data Files...");

    //FIXME if/tmp/chrome%d exists wait..

    int ret;
    char act[128];
    snprintf(act,sizeof(act),"rm -rf /tmp/chrome%d",vncms->index);
    ret=rsm_vncms_system(vncms,act);
    CHK_EXPRe(ret!=0,"Delete User Data")
        VNCMS_LOG_DEBUG(vncms->index,"Delete chrome-user-data failed(May Ignore).");
    END_CHK_EXPRe

}

//called with privileged user,aka root
static void make_chrome_userdata(rsm_vncms_t*vncms)
{
    int ret; 


    rm_chrome_userdata(vncms);
    //Copy .chrome to /tmp/chrome<index>
    char act[128];
    if(vncms->chrome_type==CHROME_Normal)
        snprintf(act,sizeof(act),"cp -r .chrome /tmp/chrome%d",vncms->index);
    else
        snprintf(act,sizeof(act),"cp -r .Interchrome /tmp/chrome%d",vncms->index);

    VNCMS_LOG_DEBUG(vncms->index,"Copy chrome user-data..Type(%d){0:Normal,1:TVnet}",vncms->chrome_type);

//    ret=system(act);
    ret=rsm_vncms_system(vncms,act);
    CHK_EXPRe(ret!=0,"System Copy User Data")

        VNCMS_LOG_DEBUG(vncms->index,"Copy chrome-user-data failed (May Ignore).");
    END_CHK_EXPRe


    //chmod &chown
    //
#if 0
    snprintf(act,sizeof(act),"chown -R x%2d /tmp/chrome%d",vncms->userid,vncms->index);
    ret=system(act);
    CHK_EXPRe(ret<0,"System Copy User Data")

        VNCMS_LOG_DEBUG(vncms->index,"Exec Chown for chrome-user-data.",vncms->chrome_type);
    END_CHK_EXPRe

#endif

    snprintf(act,sizeof(act),"chmod -R 777 /tmp/chrome%d",vncms->index);
//    ret=system(act);
    ret=rsm_vncms_system(vncms,act);
    CHK_EXPRe(ret!=0,"System Chmod")

        VNCMS_LOG_DEBUG(vncms->index,"Chmod for chrome-user-data failed (May Ignore).");
    END_CHK_EXPRe

}

////////////////
//For  VNCMS_EVT_NOTIFY

static void _notify_alive(rsm_vncms_t*vncms)
{
    int ret;
    char sbuff[128];
//    char rbuff[128];
    time_t now;
    time(&now);
    char tmstr[16];

    snprintf(tmstr,sizeof(tmstr),"%u",(unsigned int)now);
    cJSON*pjson=vncms_get_json_notify(VNCMS_NTF_ALIVE,"time",tmstr,NULL);
    vncms_make_json_msg(pjson,sbuff,sizeof sbuff);
    cJSON_Delete(pjson);
    
    VNCMS_LOG_MSG(vncms->index,"Tell RSM Alive[%s]",sbuff);
//    ret=send_to_rsm_safe(vncms,sbuff,strlen(sbuff),rbuff,sizeof(rbuff));
    ret=rsm_netlsender_send(vncms->notifysender,sbuff,strlen(sbuff));
    CHK_RUNe(ret<0,"Send <Alive> to RSM Failed",);

}



static void _notify_timeout(rsm_vncms_t*vncms)
{
    int ret;
    char sbuff[128];
//    char rbuff[128];
    time_t now;
    time(&now);
    char tmstr[16];

    snprintf(tmstr,sizeof(tmstr),"%u",(unsigned int)now);
    cJSON*pjson=vncms_get_json_notify(VNCMS_NTF_TIMEOUT,"time",tmstr,NULL);
    vncms_make_json_msg(pjson,sbuff,sizeof sbuff);
//    snprintf(sbuff,sizeof(sbuff),"%s",cJSON_PrintUnformatted(pjson));
    cJSON_Delete(pjson);
    
    VNCMS_LOG_MSG(vncms->index,"Tell RSM Timeout[%s]",sbuff);
//    ret=send_to_rsm_safe(vncms,sbuff,strlen(sbuff),rbuff,sizeof(rbuff));
    ret=rsm_netlsender_send(vncms->notifysender,sbuff,strlen(sbuff));
    CHK_RUNe(ret<0,"Send <Timeout> to RSM Failed",);

}


static void _notify_exit(rsm_vncms_t*vncms)
{
    int ret;
    char sbuff[128];
//    char rbuff[128];
    time_t now;
    char tmstr[16];
    time(&now);

    snprintf(tmstr,sizeof(tmstr),"%u",(unsigned int)now);
    cJSON*pjson=vncms_get_json_notify(VNCMS_NTF_EXIT,"time",tmstr,NULL);
    vncms_make_json_msg(pjson,sbuff,sizeof sbuff);
//    snprintf(sbuff,sizeof(sbuff),"%s",cJSON_PrintUnformatted(pjson));
    cJSON_Delete(pjson);
    
    VNCMS_LOG_MSG(vncms->index,"Tell RSM Exit[%s]",sbuff);
//    ret=send_to_rsm_safe(vncms,sbuff,strlen(sbuff),rbuff,sizeof(rbuff));
    ret=rsm_netlsender_send(vncms->notifysender,sbuff,strlen(sbuff));
    CHK_RUNe(ret<0,"Send <Exit> to RSM Failed",);

}


static void _notify_action_reply(rsm_vncms_t*vncms,cJSON*pjson)
{
    int ret;
    char sbuff[256];
    vncms_make_json_msg(pjson,sbuff,sizeof sbuff);
//    cJSON_Delete(pjson);
    
    VNCMS_LOG_MSG(vncms->index,"Tell RSM Action-Reply[%s]",sbuff);


    ret=rsm_netlsender_send(vncms->notifysender,sbuff,strlen(sbuff));
    CHK_RUNe(ret<0,"Send <Action-Reply> to RSM Failed",);

}



static void _notify_proc_exit(rsm_vncms_t*vncms,cJSON*pjson)
{
    int ret;
    char sbuff[256];
    vncms_make_json_msg(pjson,sbuff,sizeof sbuff);
//    cJSON_Delete(pjson);
    
    VNCMS_LOG_MSG(vncms->index,"Tell RSM Proc-Exit[%s]",sbuff);


    ret=rsm_netlsender_send(vncms->notifysender,sbuff,strlen(sbuff));
    CHK_RUNe(ret<0,"Send <Proc-Exit> to RSM Failed",);

}

static void _notify_chrome_check_show(rsm_vncms_t*vncms,int ok)
{

    int ret;
    char sbuff[128];
//    char rbuff[128];
    time_t now;
    char tmstr[16];
    char idxstr[16];
    char okstr[16];

    time(&now);
    snprintf(tmstr,sizeof(tmstr),"%u",(unsigned int)now);
    snprintf(idxstr,sizeof(idxstr),"%d",vncms->index);
    snprintf(okstr,sizeof(okstr),"%d",ok);


    cJSON*pjson=vncms_get_json_notify(VNCMS_NTF_CHROME_CHECK_SHOW,"index",idxstr,"show",okstr,"time",tmstr,NULL);
    vncms_make_json_msg(pjson,sbuff,sizeof sbuff);
//    snprintf(sbuff,sizeof(sbuff),"%s",cJSON_PrintUnformatted(pjson));
    cJSON_Delete(pjson);
    
    VNCMS_LOG_MSG(vncms->index,"Tell RSM ChromeCheckShow[%s]",sbuff);
//    ret=send_to_rsm_safe(vncms,sbuff,strlen(sbuff),rbuff,sizeof(rbuff));
    ret=rsm_netlsender_send(vncms->notifysender,sbuff,strlen(sbuff));
    CHK_RUNe(ret<0,"Send <ChromeCheckShow> to RSM Failed",);


}



#ifdef _ENABLE_CHROME_CHECK_SHOW


static void check_chrome_show(union sigval arg)
{
    SET_THREAD_NAME("timer_chk_webc");

    int ret;
    rsm_vncms_t*vncms=(rsm_vncms_t*)arg.sival_ptr;
   
    VNCMS_LOG_DEBUG(vncms->index,"Check Chrome Show Now(%d)..",vncms->webcchk_delay);
    videosource_instanse*pinstance=locate_video_source(vncms->index,vncms->width,vncms->height);

    int gray=check_pattern(pinstance); 

    struct ew_ntfinfo*info=(struct ew_ntfinfo*)calloc(1,sizeof *info);
    info->type=TYPE_NTF_CHROME_CHECK_SHOW;

    if(gray){
        info->value=-vncms->index;
    }else{
        info->value=vncms->index;
    }
        
    eventworker_emit_event(&vncms->evtworker,VNCMS_EVT_NOTIFY,info);

}


static void fini_chrome_check_show(rsm_vncms_t*vncms){

    timer_delete(vncms->webcchk_timer);
    vncms->webcchk_timer=0;
}

static int init_chrome_check_show(rsm_vncms_t*vncms){

//        VNCMS_LOG_WARN(vncms->index,"Init Timer for Chrome-CheckShow -Begin..");
    int ret;
    struct sigevent sigev;
    bzero(&sigev,sizeof sigev);
    
    pthread_attr_t tattr;
    pthread_attr_init(&tattr);
    pthread_attr_setdetachstate(&tattr,PTHREAD_CREATE_DETACHED);

    sigev.sigev_notify=SIGEV_THREAD;
    sigev.sigev_notify_function=check_chrome_show;
    sigev.sigev_notify_attributes=&tattr;
    sigev.sigev_value.sival_ptr=vncms;

    if(vncms->webcchk_timer){
        ret=timer_delete(vncms->webcchk_timer);
//    CHK_EXPRe(ret<0,"Delete Timer Failed")
//        VNCMS_LOG_WARN(vncms->index,"Delete Timer for Chrome-CheckShow Failed(ignore)..");
//    END_CHK_EXPRe
    }
    ret=timer_create(CLOCK_REALTIME,&sigev,&vncms->webcchk_timer);
    pthread_attr_destroy(&tattr);
    CHK_EXPRe(ret<0,"Create Timer Failed")
        VNCMS_LOG_WARN(vncms->index,"Create Timer for Checking Chrome Failed..");
        return -1;
    END_CHK_EXPRe
    
//        VNCMS_LOG_WARN(vncms->index,"Init Timer for Chrome-CheckShow -End..");
    return 0;

}

static int sche_chrome_check_show(rsm_vncms_t*vncms)
{
    int ret;

    struct itimerspec tmrsp;
    bzero(&tmrsp,sizeof tmrsp);
    tmrsp.it_interval.tv_sec=0;
    tmrsp.it_value.tv_sec=vncms->webcchk_delay;
    VNCMS_LOG_DEBUG(vncms->index,"Set timer For Chrome check show...");
    ret=timer_settime(vncms->webcchk_timer,0,&tmrsp,NULL);
    CHK_EXPRe(ret<0,"Set Timer Failed")
        VNCMS_LOG_WARN(vncms->index,"Set Timer for Checking Chrome Failed..");
        return -1;
    END_CHK_EXPRe

    return 0;

} 

#endif




#ifdef _ENABLE_KEY_TIMEOUT

static inline void vncms_set_keytimeout(rsm_vncms_t*vncms);
static inline void vncms_reset_keytimeout(rsm_vncms_t*vncms);
static inline void vncms_set_closetimeout(rsm_vncms_t*vncms);
static inline void vncms_unset_timeout(rsm_vncms_t*vncms);
#endif
////////////////////////////////////////////////
////////////////////////////////////////////////
//EventWorker callbacks ,Wrappers

int ew_dispose_action(void*data,void*udata)
{
    
    int ret=0;
    rsm_vncms_t*pvncms=(rsm_vncms_t*)data;
    struct ew_actinfo*act=(struct ew_actinfo*)udata;
    cJSON*pjson=act->json;
    act_t action=act->type;

    free(act);

    VNCMS_LOG_MSG(pvncms->index,"Process Event Action[%s]..",vncms_get_action_str(action));

    


    if(action==VNCMS_ACT_OPEN_AVENC){
//
        char*rrate=NULL;
        char*rdestaddr=NULL;
        int n=rsm_json_fill(pjson,"destaddr",&rdestaddr,NULL);
        if(n<1){
            VNCMS_LOG_WARN(pvncms->index,"Resume Paused Avencoder?(destaddr|%s)",pvncms->av_destaddr);
        }else{
            strlcpy(pvncms->av_destaddr,rdestaddr,sizeof(pvncms->av_destaddr));
        }

        n=rsm_json_fill(pjson,"rate",&rrate,NULL);
        if(n==1){
            pvncms->av_bitrate=atoi(rrate)*1024;
            free(rrate);
        }else{
            VNCMS_LOG_WARN(pvncms->index,"No Rate Specified(Default:%d)..",pvncms->av_bitrate);
        }
//        pvncms->av_peakbitrate=

        if(rdestaddr)
            free(rdestaddr);
//      
        ret=rsm_vncms_open_encoder(pvncms);
        pvncms->nb_relaunch_enc=NUM_RELAUNCH;
        VNCMS_LOG_MSG(pvncms->index,"Open Encoder<%d>",ret);

        if(pvncms->b_audio){
            ret=rsm_vncms_open_audiorecorder(pvncms);
            pvncms->nb_relaunch_aud=NUM_RELAUNCH;
            VNCMS_LOG_MSG(pvncms->index,"Open audiorecorder<%d>",ret);
        }

    }else

    if(action==VNCMS_ACT_CLOSE_AVENC){
        ret=rsm_vncms_close_encoder(pvncms);
        VNCMS_LOG_MSG(pvncms->index,"Close Encoder<%d>",ret);

        if(pvncms->b_audio){
            ret=rsm_vncms_close_audiorecorder(pvncms);
            VNCMS_LOG_MSG(pvncms->index,"Close audiorecorder<%d>",ret);
        }
    }else

    if(action==VNCMS_ACT_OPEN_WEBC){
        pvncms->b_timeout=0;
        ret=rsm_vncms_open_webc(pvncms);
        pvncms->nb_relaunch_webc=NUM_RELAUNCH;
        VNCMS_LOG_MSG(pvncms->index,"Open Chrome<%d>",ret);

    }
    else

    if(action==VNCMS_ACT_CLOSE_WEBC){
        ret=rsm_vncms_close_webc(pvncms);
        VNCMS_LOG_MSG(pvncms->index,"Close Chrome<%d>",ret);

    }
    else

    if(action==VNCMS_ACT_RESET){
        ret=rsm_vncms_reset(pvncms);
        VNCMS_LOG_MSG(pvncms->index,"Reset VNCMS<%d>",ret);
    }else

#ifdef _ENABLE_KEY_TIMEOUT
    if(action==VNCMS_ACT_SET_TIMEOUT){
        pvncms->b_timeout=1;
       
        int sec=KEY_TIMEOUT;
        char*rtimeval;
        int n=rsm_json_fill(pjson,"val",&rtimeval,NULL);
        CHK_EXPR(n==1,"SET TIMER..")
            sec=atoi(rtimeval);
            free(rtimeval);
        END_CHK_EXPR

        ret=rsm_vncms_set_timeout(pvncms,sec);
        VNCMS_LOG_MSG(pvncms->index,"Set Timeout<%d>",ret);
    }
    else
#endif
    if(action==VNCMS_ACT_OPEN_ENC){
        ret=rsm_vncms_open_encoder(pvncms);
        pvncms->nb_relaunch_enc=NUM_RELAUNCH;
        VNCMS_LOG_MSG(pvncms->index,"Open Encoder<%d>",ret);

    }
    else

    if(action==VNCMS_ACT_CLOSE_ENC){
        ret=rsm_vncms_close_encoder(pvncms);
        VNCMS_LOG_MSG(pvncms->index,"Close Encoder<%d>",ret);

    }
    else

    if(action==VNCMS_ACT_OPEN_AUD){
        ret=rsm_vncms_open_audiorecorder(pvncms);
        pvncms->nb_relaunch_aud=NUM_RELAUNCH;
        VNCMS_LOG_MSG(pvncms->index,"Open audiorecorder<%d>",ret);

    }
    else
    if(action==VNCMS_ACT_CLOSE_AUD){
        ret=rsm_vncms_close_audiorecorder(pvncms);
        VNCMS_LOG_MSG(pvncms->index,"Close audiorecorder<%d>",ret);

    }
    else

    if(action==VNCMS_ACT_START_XVNC){
        ret=rsm_vncms_start_xvnc(pvncms);
        pvncms->nb_relaunch_xvnc=NUM_RELAUNCH;
        VNCMS_LOG_MSG(pvncms->index,"Start VNC<%d>",ret);
    }else

    if(action==VNCMS_ACT_STOP_XVNC){
        ret=rsm_vncms_stop_xvnc(pvncms);
        VNCMS_LOG_MSG(pvncms->index,"Stop VNC<%d>",ret);

    }else
    
    {
        
        VNCMS_LOG_MSG(pvncms->index,"UNKNOW ACTION(%d)",action);
        pjson=NULL;

    }


///////////////
//Only reply notify:action-reply when rsm_vncms_{open,close}_* return non-zero..
    if(ret!=0){
        struct ew_ntfinfo*info=(struct ew_ntfinfo*)calloc(1,sizeof *info);
        info->type=TYPE_NTF_ACT_REPLY;

        info->json=vncms_get_json_notify_action_reply(action,ret,"hello","world",NULL);

        eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_NOTIFY,info);

    }


    if(pjson)
        cJSON_Delete(pjson);

    return EVW_PRESIS;

}

//recycle subprocesses' status
static int ew_dispose_sigchld(void*data,void*udata)
{
    
    rsm_vncms_t*pvncms=(rsm_vncms_t*)data;


    struct ew_siginfo*sigi=(struct ew_siginfo*)udata;

    int pid=sigi->pid;
    int fl_exit=sigi->fl_exit;
    int fl_kill=sigi->fl_kill;
    int which=sigi->which;
    int crashed=sigi->crashed;

    free(sigi);

    VNCMS_LOG_MSG(pvncms->index,"Process Event SIGCHLD[:%d(k:%d|e:%d)]..",pid,fl_kill,fl_exit);

  
    if(which==TYPE_SIG_XVNC){//Xvnc失败意味着vncms应该退出

        VNCMS_LOG_MSG(pvncms->index,"Xvnc<pid:%d> has been reaped..",pid);

        //1.reset xvnc_id in vncms (may ignore)
        pvncms->xvncid_sav=0;

        //2.check if process terminated unexpectedly
        if(crashed){

            if(fl_exit!=EXEC_FAIL){
                VNCMS_LOG_WARN(pvncms->index,"Xvnc Stopped Exceptionally<Killed:%d or Exited:%d>..!!",fl_kill,fl_exit);
#if 0
                //2.5 Need ReLaunch?????
                int ntry=__sync_fetch_and_sub(&pvncms->nb_relaunch_xvnc,1);
                if(ntry>0){
                    VNCMS_LOG_WARN(pvncms->index,"To Relaunch Xvnc<cnt:%d>..!!",ntry-1);
                    rsm_vncms_start_xvnc(pvncms);
                }
#else
                VNCMS_LOG_WARN(pvncms->index,"Fatal Error :Could not Launch BVBCS..!!");
                eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_TERM,NULL);

#endif
            }else{
                //can not exec new binary,no such binary???
                VNCMS_LOG_WARN(pvncms->index,"EXEC Xvnc@{%s} Failed<%d>....",pvncms->xvnc_path,fl_exit);
    
                eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_TERM,NULL);
            }
    
        }else{
            //stopped by rsm_vncms_stop_xvnc();           
        }


    }else

    if(which==TYPE_SIG_WEBC){
#ifdef _ENABLE_KEY_TIMEOUT
        //clean up timer..
        if(!timer_is_null(&pvncms->keytimeout_timer))
            timer_fini(&pvncms->keytimeout_timer);
#endif 

        VNCMS_LOG_MSG(pvncms->index,"Chrome<pid:%d> has been reaped..",pid);

        pvncms->webcid_sav=0;

        //killed by signal or exited
        if(crashed){

        //reset webcid within vncms for relaunch wenc
            if(fl_exit!=EXEC_FAIL){

                VNCMS_LOG_WARN(pvncms->index,"Chrome Stopped Exceptionally<Killed:%d or Exited:%d>!..",fl_kill,fl_exit);
                //To ReLaunch ..
                int ntry=__sync_fetch_and_sub(&pvncms->nb_relaunch_webc,1);
                if(ntry>0){

                    VNCMS_LOG_WARN(pvncms->index,"To Relaunch Chrome<cnt:%d>..!!",ntry-1);
                    rsm_vncms_open_webc(pvncms);

                    struct ew_ntfinfo*info=(struct ew_ntfinfo*)calloc(1,sizeof *info);
                    info->type=TYPE_NTF_PROC_EXIT;
                    info->json=vncms_get_json_notify_proc_exit(PROC_TYPE_WEBC,pid,ntry-1,"hello","world",NULL);
                    eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_NOTIFY,info);
                }

            }else{
                //can not exec new binary,no such binary???
                VNCMS_LOG_WARN(pvncms->index,"EXEC Chrome@{%s} Failed<%d>....",pvncms->webc_path,fl_exit);

                eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_TERM,NULL);
            }
        }else{
            //Nothing
            //stopped by rsm_vncms_close_webc();           
        }

    }else

    if(which==TYPE_SIG_ENC){

        VNCMS_LOG_MSG(pvncms->index,"Encoder<pid:%d> has been reaped..",pid);

        pvncms->encid_sav=0;
        if(crashed){
        
            if(fl_exit!=EXEC_FAIL){
                VNCMS_LOG_WARN(pvncms->index,"Encoder Stopped Exceptionally<Killed:%d or Exited:%d>!..",fl_kill,fl_exit);
                //To ReOpen..
                int ntry=__sync_fetch_and_sub(&pvncms->nb_relaunch_enc,1);
                if(ntry>0){
                    VNCMS_LOG_WARN(pvncms->index,"To Relaunch Encoder<cnt:%d>..!!",ntry-1);
                    rsm_vncms_open_encoder(pvncms);
//                    pvncms->nb_relaunch_enc--;
#if 1
                    struct ew_ntfinfo*info=(struct ew_ntfinfo*)calloc(1,sizeof *info);
                    info->type=TYPE_NTF_PROC_EXIT;
                    info->json=vncms_get_json_notify_proc_exit(PROC_TYPE_ENCODER,pid,ntry-1,"hello","world",NULL);
                    eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_NOTIFY,info);
#endif

                }

            }else{
                
                VNCMS_LOG_WARN(pvncms->index,"EXEC Encoder@{%s} Failed<%d>....",pvncms->encoder_path,fl_exit);

                eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_TERM,NULL);
            }
        }else{
            //Nothing
            //stopped by rsm_vncms_close_encoder();           
        }

    }else

    if(which==TYPE_SIG_AUD){

        VNCMS_LOG_MSG(pvncms->index,"Audio<pid:%d> has been reaped..",pid);

        pvncms->audid_sav=0;

        if(crashed){

            if(fl_exit!=EXEC_FAIL){
                VNCMS_LOG_WARN(pvncms->index,"Audio Stopped Exceptionally<Killed:%d or Exited:%d>!..",fl_kill,fl_exit);
                //To ReOpen..
                int ntry=__sync_fetch_and_sub(&pvncms->nb_relaunch_aud,1);
                if(ntry>0){
                    VNCMS_LOG_WARN(pvncms->index,"To Relaunch Audio<cnt:%d>..!!",ntry-1);
                    rsm_vncms_open_audiorecorder(pvncms);
//                    pvncms->nb_relaunch_aud--; 
#if 1
                    struct ew_ntfinfo*info=(struct ew_ntfinfo*)calloc(1,sizeof *info);
                    info->type=TYPE_NTF_PROC_EXIT;
                    info->json=vncms_get_json_notify_proc_exit(PROC_TYPE_AUDIO,pid,ntry-1,"hello","world",NULL);
                    eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_NOTIFY,info);
#endif

                }

            }else{
                
                VNCMS_LOG_WARN(pvncms->index,"EXEC Audio@{%s} Failed<%d>....",pvncms->audio_path,fl_exit);

                eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_TERM,NULL);
            }
        }else{
            //Nothing
            //stopped by rsm_vncms_close_encoder();           
        }
    }
/////////
    else{
        //system() may  fall into here..
        VNCMS_LOG_MSG(pvncms->index,"XXXX<pid:%d> has been reaped..",pid);
    }
            

    return EVW_PRESIS;

}

static int ew_dispose_term(void*data,void*udata)
{

    rsm_vncms_t*pvncms=(rsm_vncms_t*)data;
    VNCMS_LOG_MSG(pvncms->index,"Process Term Event..");

    rsm_vncms_close_webc(pvncms);
    rsm_vncms_close_encoder(pvncms);
    if(pvncms->b_audio)
        rsm_vncms_close_audiorecorder(pvncms);
//    rsm_vncms_stop_vnc(pvncms);

    eventworker_stop(&pvncms->evtworker);

    return EVW_PRESIS;
}

//Send notify to RSM here
static int ew_dispose_notify(void*data,void*udata)
{
    
    rsm_vncms_t*pvncms=(rsm_vncms_t*)data;
    struct ew_ntfinfo*info=(struct ew_ntfinfo*)udata;
    int type=info->type;
    int val=info->value;
    cJSON*pjson=info->json;
    free(info);

    VNCMS_LOG_MSG(pvncms->index,"Process Event Notify[%d]..",(type));

    switch(type){

        case TYPE_NTF_ALIVE:{

            _notify_alive(pvncms);
            break;
            }

        case TYPE_NTF_TIMEOUT:{

            _notify_timeout(pvncms);
            break;
            }
        case TYPE_NTF_EXIT:{

            _notify_exit(pvncms);
            break;
            }
        case TYPE_NTF_ACT_REPLY:{

            _notify_action_reply(pvncms,pjson);
            break;
            }
        case TYPE_NTF_PROC_EXIT:{

            _notify_proc_exit(pvncms,pjson);

            break;
            }
#ifdef _ENABLE_CHROME_CHECK_SHOW
        case TYPE_NTF_CHROME_CHECK_SHOW:{
            int ok=val>0;
            _notify_chrome_check_show(pvncms,ok);
            if(!ok){
//                VNCMS_LOG_WARN(pvncms->index,"Chrome Check Show Fail, Counter:%d",pvncms->webcchk_times);
            }
            break;
            }

#endif

        default:
            break;

    }
    if(pjson)
        cJSON_Delete(pjson);


    return EVW_PRESIS;
}



////////////////////////////////////////////////
//////////////////Work Threads//////////////////
////////////////////////////////////////////////
//

static int forward_key(rsm_netbinder_t*binder,char*buff,int len,void*data);

//udp For listen user's key operations
static void* _thread_keylistener(void*arg)
{
    SET_THREAD_NAME("keyListener");

    rsm_vncms_t*pvncms=(rsm_vncms_t*)arg;
    
    char rbuff[256];
    int nr;

    while(1){
        
        nr=rsm_netbinder_recv(pvncms->keylistener,rbuff,sizeof(rbuff));

        forward_key(pvncms->keylistener,rbuff,nr,pvncms);

    }


    return NULL;
}

//Local Socket For listen RSM's commands 
static void* _thread_actbinder(void*arg)
{

    SET_THREAD_NAME("actListener");

    rsm_vncms_t*pvncms=(rsm_vncms_t*)arg;

    char rbuff[128];
    int nr,ret;
    act_t a;
    cJSON*pjson=NULL;

    while(1){

        nr=rsm_netlbinder_recv(pvncms->actbinder,rbuff,sizeof(rbuff));
        CHK_EXPRe(nr<0,"NetBinders read failed..Continue")
            VNCMS_LOG_DEBUG(pvncms->index,"Read Action From RSM Failed...Skip");
            continue;
        END_CHK_EXPR
        rbuff[nr]=0;

        a=vncms_parse_json_action(rbuff,&pjson);
        struct ew_actinfo*info=(struct ew_actinfo*)calloc(1,sizeof(struct ew_actinfo));
        info->json=pjson;
        info->type=a;

        VNCMS_LOG_DEBUG(pvncms->index,"Read Action From RSM{type:%s}",vncms_get_action_str(a));

        eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_ACTION,info);

    }

    return NULL;
}



static void* _thread_notify(void*arg)
{
    SET_THREAD_NAME("rsmNotify");
    int ret; 
    rsm_vncms_t*pvncms=(rsm_vncms_t*)arg;
    VNCMS_LOG_MSG(pvncms->index,"Enter Notify Thread..");
 

    int c;
    while(1){
        sleep(60) ;   
#if 0
        //notify alive
        VNCMS_LOG_MSG(pvncms->index,"Notify RSM Alive..");
        struct ew_ntfinfo*info=(struct ew_ntfinfo*)calloc(1,sizeof *info);
        info->type=TYPE_NTF_ALIVE;
        eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_NOTIFY,info);
#endif
    }

    return NULL;
}






//Handle Signals 
//e.g. catch SIGCHLD to cleanup subprocesses'status.
static void*_thread_signalhandler(void*arg){

    SET_THREAD_NAME("sigHandler");

    int ret;
    sigset_t set,oset;

    rsm_vncms_t*pvncms=(rsm_vncms_t*)arg;

    
    int signo;
    sigemptyset(&set);
    sigaddset(&set,SIGCHLD);
    sigaddset(&set,SIGTERM);

    while(1){
        
        ret=sigwait(&set,&signo);
        CHK_RUNe(ret!=0,"SigWait Failed",break);
        int status;
        int pid;
        
        int fl_exit;
        int fl_kill;

        switch(signo){

            case SIGCHLD:

                while((pid=waitpid(-1,&status,WNOHANG))>0){
//                    CHK_EXPRe_ONLY(1,"ENTER WAIT......");
                    VNCMS_LOG_DEBUG(pvncms->index,"Enter WaitPid(%d)..",pid);
                    fl_exit=0;
                    fl_kill=0;
//                    int savpid=pid;
                    if(WIFEXITED(status)){
                        fl_exit=WEXITSTATUS(status);
//                        fprintf(stderr,"[Exited](%d)",fl_exit);
                        if(fl_exit==EXEC_FAIL){
                            VNCMS_LOG_ERROR(pvncms->index,"Launching Process Failed..");
                        }else{
                            VNCMS_LOG_MSG(pvncms->index,"A Process Exited..");
                        }

                    }else if(WIFSIGNALED(status)){
                        fl_kill=WTERMSIG(status);
//                        fprintf(stderr,"[Signaled](%u)",fl_kill);
                        VNCMS_LOG_MSG(pvncms->index,"Process Signaled By <SIG:%d>..",fl_kill);

                    }else{
                        VNCMS_LOG_WARN(pvncms->index,"VNCMS Got SIGCHLD with Other reasons..")
                    }

                    struct ew_siginfo*sigi=(struct ew_siginfo*)malloc(sizeof *sigi);
                    sigi->pid=pid;
                    sigi->fl_kill=fl_kill;
                    sigi->fl_exit=fl_exit;


                    if(pid==pvncms->encid_sav){
                        sigi->which=TYPE_SIG_ENC;
                        sigi->crashed=0;
                    }else
                    if(pid==pvncms->audid_sav){
                        sigi->which=TYPE_SIG_AUD;
                        sigi->crashed=0;
                    }else
                    if(pid==pvncms->webcid_sav){
                        sigi->which=TYPE_SIG_WEBC;
                        sigi->crashed=0;
                    }else
                    if(pid==pvncms->xvncid_sav){
                        sigi->which=TYPE_SIG_XVNC;
                        sigi->crashed=0;
                    }else

                    if(pid==pvncms->xvncid){
                        sigi->which=TYPE_SIG_XVNC;
                        sigi->crashed=1;
                        pvncms->xvncid=0;//reset as soon as possible
                    }else
                    if(pid==pvncms->webcid){
                        sigi->which=TYPE_SIG_WEBC;
                        sigi->crashed=1;
                        pvncms->webcid=0;
                    }else
                    if(pid==pvncms->encid){
                        sigi->which=TYPE_SIG_ENC;
                        sigi->crashed=1;
                        pvncms->encid=0;
                    }else
                    if(pid==pvncms->audid){
                        sigi->which=TYPE_SIG_AUD;
                        sigi->crashed=1;
                        pvncms->audid=0;
                    }else

                    if(pid==pvncms->otherid){
                    //if enter here, pid was created by vncms_system
                        VNCMS_LOG_MSG(pvncms->index,"vncms_system(pid:%d/ret:%d) Finished..",pid,fl_exit);
                        pvncms->otherret=fl_exit;
                        pvncms->otherid=0;
                        pthread_cond_signal(&pvncms->othcond);
                        sigi->which=TYPE_SIG_SYSTEM;
                    }else

                    
                    {
                        sigi->which=TYPE_SIG_NONE;
                        sigi->crashed=0;
                    }


                    if(sigi->which==TYPE_SIG_SYSTEM){
                        free(sigi);
                    }else
                    if(sigi->which==TYPE_SIG_NONE){
                    //not emit event
                        VNCMS_LOG_WARN(pvncms->index,"Other SigEvent received..");
                        free(sigi);
                    }else{
                        
                        eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_SIGCHLD,sigi);
                    }
                }


                break;

            case SIGTERM:

                VNCMS_LOG_WARN(pvncms->index,"TO Terminate VNCMS<%d>..",pvncms->index);

//                usleep(500000);
                eventworker_emit_event(&pvncms->evtworker,VNCMS_EVT_TERM,NULL);

//                eventworker_stop(&pvncms->evtworker);
                break;
            default:
                CHK_EXPR_ONLY(1,"Other Signal Caugth...");
                break;
        }

    }
    VNCMS_LOG_ERROR(pvncms->index,"SigHandle Thread Failed!!..");

    return NULL;

}




void rsm_vncms_print_info(rsm_vncms_t*pvncms)
{
#define PRBUFFSIZ (4*1024)

    char*obuff=calloc(1,PRBUFFSIZ);

#if 1
    rsm_snprintf_append(obuff,PRBUFFSIZ," VNCMS <%d>\n",pvncms->index);
    rsm_snprintf_append(obuff,PRBUFFSIZ,"\twidth      :=%d\n",pvncms->width);
    rsm_snprintf_append(obuff,PRBUFFSIZ,"\theight     :=%d\n",pvncms->height);
    rsm_snprintf_append(obuff,PRBUFFSIZ,"\tkeyport    :=%d\n",pvncms->keyport);
    rsm_snprintf_append(obuff,PRBUFFSIZ,"\txvncport   :=%d\n",pvncms->xvncport);
    rsm_snprintf_append(obuff,PRBUFFSIZ,"\tlistenport :=%d\n",pvncms->listenport);
    rsm_snprintf_append(obuff,PRBUFFSIZ,"\tURL        :=%s\n",pvncms->url);
    rsm_snprintf_append(obuff,PRBUFFSIZ,"\txvnc_path  :=%s\n",pvncms->xvnc_path);
    rsm_snprintf_append(obuff,PRBUFFSIZ,"\tav_destaddr:=%s(DEFAULT)\n",pvncms->av_destaddr);
    rsm_snprintf_append(obuff,PRBUFFSIZ,"\tav_bitrate :=%d(DEFAULT)\n",pvncms->av_bitrate);
#endif

    VNCMS_LOG_MSG(pvncms->index,"%s\n",obuff);
    free(obuff);

}





rsm_vncms_t*rsm_vncms_new(idx_t idx)
{

    int ret;
    CHK_RUN(idx<=0,"Invalid index..",
            return NULL);


    rsm_vncms_t*pvncms=calloc(1,sizeof(rsm_vncms_t));
    CHK_RUNe(!pvncms,"Allocate rsm_vncms Failed..",
            goto fail0);

    pvncms->index=idx;

// Initialize logger
    ret=rsm_log_init(&pvncms->vncms_log);
    CHK_EXPR(ret<0,"Init Log Facility Failed.")
//        VNCMS_LOG_WARN(pvncms->index,"Initialize Log() Failed!!");
        goto fail1;
    END_CHK_EXPR
//for export global logger
    global_vncmslog=&pvncms->vncms_log;


//init vncms's configuration file, shared with RSM
    ret=rsm_conf_init(&pvncms->vncms_conf,"rsm.conf");
    CHK_EXPR(ret<0,"Init Config Facility.")
        VNCMS_LOG_ERROR(pvncms->index,"Initialize Config(rsm.conf) Failed!!");
        goto fail2;
    END_CHK_EXPR

///
    int paamount=atoi(pvncms->vncms_conf.rsm_vid_pa_num);
    ret=index1(pvncms->index,&pvncms->sinkid,&pvncms->userid,paamount);
    CHK_EXPR_ONLY(ret<0,"Invalid index..");
///

    char logname[128];
    snprintf(logname,sizeof(logname),"%s/vncms-%d.log",pvncms->vncms_conf.rsm_log_path,idx);
    rsm_log_reset_func(&pvncms->vncms_log,logname);
    rsm_log_set_maxsize(&pvncms->vncms_log,convert_size(pvncms->vncms_conf.rsm_log_size));

    VNCMS_LOG_MSG(pvncms->index,"\n\t\tVNCMS Version: "VNCMS_VERSION"(%s)\n",__DATE__);

    ret=is_launch_with_root();
    CHK_EXPRe(ret==0,"`root' privilege required!!")
        VNCMS_LOG_WARN(pvncms->index,"`root' privilege required!! Aborting...");
        goto fail3; 
    END_CHK_EXPRe




    ret=rsm_get_addr_by_iface(pvncms->vncms_conf.rsm_net_iface,pvncms->vncmsip,sizeof(pvncms->vncmsip));
    CHK_RUN(ret<0,"Get address of NetIface failed..",
            goto fail3);
/*
*/

    pvncms->width=atoi(pvncms->vncms_conf.rsm_vid_width);
    pvncms->height=atoi(pvncms->vncms_conf.rsm_vid_height);

    pvncms->keyport=atoi(pvncms->vncms_conf.vncms_keyport)+idx;
    pvncms->xvncport=atoi(pvncms->vncms_conf.vncms_serverport)+idx;
    pvncms->listenport=atoi(pvncms->vncms_conf.vncms_listenport)+idx;
    pvncms->rsm_listenport=atoi(pvncms->vncms_conf.rsm_vncms_listenport)+idx;

    pvncms->url=strdup(pvncms->vncms_conf.rsm_pre_url);//"file:///opt/init.html";
    pvncms->xvnc_path=strdup(XVNC_BIN);
    pvncms->audio_path=strdup(pvncms->vncms_conf.rsm_enc_audiopath);
    pvncms->encoder_path=strdup(pvncms->vncms_conf.rsm_enc_path);
    pvncms->webc_path=strdup(WEBC_BIN);
    pvncms->chrome_type=atoi(pvncms->vncms_conf.rsm_chrome_type);
    pvncms->b_vgl=atoi(pvncms->vncms_conf.vncms_enable_vgl);
    pvncms->b_audio=atoi(pvncms->vncms_conf.rsm_enc_audio);


    snprintf(pvncms->av_pids,sizeof(pvncms->av_pids),"%d:%d:%d:%d",atoi(pvncms->vncms_conf.rsm_enc_pmt_pid),atoi(pvncms->vncms_conf.rsm_enc_service_id),
               atoi(pvncms->vncms_conf.rsm_enc_pmt_vid),atoi(pvncms->vncms_conf.rsm_enc_pmt_aid) );

    snprintf(pvncms->av_gopsiz,sizeof(pvncms->av_gopsiz),"%s",pvncms->vncms_conf.rsm_enc_gop);

    pvncms->av_bitrate=atoi(pvncms->vncms_conf.rsm_enc_video_rate)*1024*1024;
    pvncms->av_peakbitrate=atoi(pvncms->vncms_conf.rsm_enc_video_peakrate)*1024*1024;
    if(pvncms->av_peakbitrate<=pvncms->av_bitrate)
        pvncms->av_peakbitrate=pvncms->av_bitrate*3;
//    snprintf(pvncms->av_bitrate,sizeof(pvncms->av_bitrate),"%s", atoi(pvncms->vncms_conf.rsm_enc_video_rate)*1024);

    strlcpy(pvncms->av_destaddr,"127.0.0.1:14000",sizeof(pvncms->av_destaddr));
#ifdef _ENABLE_KEY_TIMEOUT
    pvncms->keytimeout_val=KEY_TIMEOUT;
#endif

#ifndef _HAVE_LIBVNC
    init_keyagent(&pvncms->ka,pvncms->index);
#endif

#ifdef _ENABLE_CHROME_CHECK_SHOW
    pvncms->webcchk_times=3;
#endif

    char path[32];

    snprintf(path,sizeof path,"/tmp/rsm_binder%d",pvncms->index);
    pvncms->notifysender=rsm_netlsender_new(path);
    CHK_EXPR(pvncms->notifysender==NULL,"Create Notify Sender<netsender> Failed..")
        VNCMS_LOG_ERROR(pvncms->index,"Create Notify Sender Failed..");
        goto fail5;
    END_CHK_EXPR

    snprintf(path,sizeof path,"/tmp/vncms_binder%d",pvncms->index);
    pvncms->actbinder=rsm_netlbinder_new(path);
    CHK_EXPR(pvncms->actbinder==NULL,"Create Action Listener<netbinder> Failed.")
        VNCMS_LOG_ERROR(pvncms->index,"Create Action Listener Failed.");
        goto fail6;
    END_CHK_EXPR

    pvncms->keylistener=rsm_netbinder_new("0.0.0.0",pvncms->keyport);
    CHK_EXPR(pvncms->keylistener==NULL,"Create Key Listener<netbinder> Failed.")
        VNCMS_LOG_ERROR(pvncms->index,"Create Key Listener Failed.");
        goto fail7;
    END_CHK_EXPR



//For Dispatch operations asynchronously
    ret=eventworker_init(&pvncms->evtworker);
    CHK_EXPR(ret<0,"Create Operation Dispatcher Failed..")
        VNCMS_LOG_ERROR(pvncms->index,"Create Operation Dispatcher Failed..");
        goto fail8;
    END_CHK_EXPR


//print vncms's current configurations
    rsm_vncms_print_info(pvncms);


    return pvncms;


fail8:
    rsm_netbinder_free(pvncms->keylistener);
fail7:
    rsm_netlbinder_free(pvncms->actbinder);

fail6:
    rsm_netlsender_free(pvncms->notifysender);

fail5:
fail4:
    free(pvncms->url);
    free(pvncms->xvnc_path);
    free(pvncms->encoder_path);
    free(pvncms->audio_path);
    free(pvncms->webc_path);

fail3:
    rsm_conf_fini(&pvncms->vncms_conf);
fail2:
    rsm_log_fini(&pvncms->vncms_log);
fail1:
    free(pvncms);
fail0:
    return NULL;

}


static void reset_proc_counter(union sigval arg)
{
    SET_THREAD_NAME("timer_procount");
    int ret;
    rsm_vncms_t*vncms=(rsm_vncms_t*)arg.sival_ptr;
//    VNCMS_LOG_DEBUG(vncms->index,"Reset Proc-counter..");
//
//    vncms->nb_relaunch_xvnc=NUM_RELAUNCH;
    vncms->nb_relaunch_webc=NUM_RELAUNCH;
//    vncms->nb_relaunch_enc=NUM_RELAUNCH;
//    vncms->nb_relaunch_aud=NUM_RELAUNCH;

}

int rsm_vncms_start(rsm_vncms_t*pvncms)
{

    int ret=0;

#if 1
////BLOCK ALL SIGNALS
//All threads create here will inherit this sigmask
    sigset_t set,oset;
    sigfillset(&set);
    ret=pthread_sigmask(SIG_BLOCK,&set,&oset);
//    ret=sigprocmask(SIG_BLOCK,&set,&oset);
    CHK_RUNe(ret!=0,"SigMask Failed..",
            ret=-1;
            goto fail0);
#endif


//Register EventWorkers HERE...

    eventworker_register_event(&pvncms->evtworker,VNCMS_EVT_NOTIFY,ew_dispose_notify,pvncms);
    eventworker_register_event(&pvncms->evtworker,VNCMS_EVT_ACTION,ew_dispose_action,pvncms);
    eventworker_register_event(&pvncms->evtworker,VNCMS_EVT_SIGCHLD,ew_dispose_sigchld,pvncms);
    eventworker_register_event(&pvncms->evtworker,VNCMS_EVT_TERM,ew_dispose_term,pvncms);
    

///////Create Work Threads..

    pthread_attr_t tattr;
    pthread_attr_init(&tattr);
    pthread_attr_setdetachstate(&tattr,PTHREAD_CREATE_DETACHED);

    
    ret=pthread_create(&pvncms->sighnandle_tid,&tattr,_thread_signalhandler,pvncms);
    CHK_EXPR(ret!=0,"Create Signal-handle Thread Failed..")
        VNCMS_LOG_ERROR(pvncms->index,"Create Signal-handle Thread Failed..");
        ret=-2;
        goto fail1;
    END_CHK_EXPR

#if 0
    ret=pthread_create(&pvncms->notifysend_tid,&tattr,_thread_notify,pvncms);
    CHK_EXPR(ret!=0,"Create Notify-Sender Thread Failed..")
        VNCMS_LOG_ERROR(pvncms->index,"Create Notify-Sender Thread Failed..");
        ret=-3;
        goto fail2;
    END_CHK_EXPR
#endif
    ret=pthread_create(&pvncms->actbind_tid,&tattr,_thread_actbinder,pvncms);
    CHK_EXPR(ret!=0,"Create Action-bind Thread Failed..")
        VNCMS_LOG_ERROR(pvncms->index,"Create Action-bind Thread Failed..");
        ret=-4;
        goto fail3;
    END_CHK_EXPR


    ret=pthread_create(&pvncms->keylisten_tid,&tattr,_thread_keylistener,pvncms);
    CHK_EXPR(ret!=0,"Create Key-listen Thread Failed..")
        VNCMS_LOG_ERROR(pvncms->index,"Create Key-listen Thread Failed..");
        ret=-5;
        goto fail4;
    END_CHK_EXPR


//Always Start Xvnc(bvbcs) during Vncms' initialization
    ret=rsm_vncms_start_xvnc(pvncms);
    CHK_EXPR(ret<0,"Start Xvnc(BVBCS) Failed...")
        VNCMS_LOG_ERROR(pvncms->index,"Start Xvnc(BVBCS) Failed..");
        ret=-6;
        goto fail5;
    END_CHK_EXPR


    rsm_vncms_init_system(pvncms);

#if 1

    struct sigevent sigev;
    bzero(&sigev,sizeof sigev);
    struct itimerspec tmrsp;
    bzero(&tmrsp,sizeof tmrsp);
    

    sigev.sigev_notify=SIGEV_THREAD;
    sigev.sigev_notify_function=reset_proc_counter;
    sigev.sigev_notify_attributes=&tattr;
    sigev.sigev_value.sival_ptr=pvncms;


    ret=timer_create(CLOCK_REALTIME,&sigev,&pvncms->proctimer);
//    pthread_attr_destroy(&tattr);
    CHK_EXPRe(ret<0,"Create Timer Failed")
        VNCMS_LOG_WARN(pvncms->index,"Create Timer for proc-counter(relaunch)..");
        goto skipsettime;
    END_CHK_EXPRe


    tmrsp.it_interval.tv_sec=20;
    tmrsp.it_value.tv_sec=20;

    ret=timer_settime(pvncms->proctimer,0,&tmrsp,NULL);
    CHK_EXPRe(ret<0,"Set Timer Failed")
        VNCMS_LOG_WARN(pvncms->index,"Set Timer for proc-counter Failed..");
    END_CHK_EXPRe


skipsettime:


#endif


//Block Here
    ret=eventworker_start(&pvncms->evtworker);
    CHK_EXPR(ret<0,"Start Eventworker Failed..")
        VNCMS_LOG_ERROR(pvncms->index,"Start Eventworker Failed<ret:%d>..",ret);
        ret=-7;
        goto fail6;
    END_CHK_EXPR

    VNCMS_LOG_MSG(pvncms->index,"Eventworker Stopped...");

    rsm_vncms_fini_system(pvncms);

fail6:
    rsm_vncms_stop_xvnc(pvncms);
//    VNCMS_LOG_MSG(pvncms->index," fail6...");
fail5:
    pthread_cancel(pvncms->keylisten_tid);
//    VNCMS_LOG_MSG(pvncms->index," fail5...");

fail4:
    pthread_cancel(pvncms->actbind_tid);
//    VNCMS_LOG_MSG(pvncms->index," fail4...");

fail3:
#if 0   
    pthread_cancel(pvncms->notifysend_tid);
//    VNCMS_LOG_MSG(pvncms->index," fail3...");

fail2:
#endif
//    usleep(10000);
    pthread_cancel(pvncms->sighnandle_tid);

//    VNCMS_LOG_MSG(pvncms->index," fail2...");
fail1:
    pthread_attr_destroy(&tattr);
    eventworker_unregister_event(&pvncms->evtworker,VNCMS_EVT_NOTIFY);
    eventworker_unregister_event(&pvncms->evtworker,VNCMS_EVT_ACTION);
    eventworker_unregister_event(&pvncms->evtworker,VNCMS_EVT_SIGCHLD);
    eventworker_unregister_event(&pvncms->evtworker,VNCMS_EVT_TERM);
 
    pthread_sigmask(SIG_SETMASK,&oset,NULL);

fail0:

    VNCMS_LOG_MSG(pvncms->index,"Terminated...");
    return ret;
}










void rsm_vncms_free(rsm_vncms_t*vncms)
{
    return_if_fail(vncms!=NULL);

    int ret;
    int savid;

//////
    eventworker_fini(&vncms->evtworker);

//    pthread_cancel(vncms->keylisten_tid);
    rsm_netbinder_free(vncms->keylistener);

//    pthread_cancel(vncms->actbind_tid);
    rsm_netlbinder_free(vncms->actbinder);

#if 0
//    pthread_cancel(vncms->notifysend_tid);
    rsm_netlsender_free(vncms->notifysender);
#endif
//    pthread_cancel(vncms->sighnandle_tid);

    free(vncms->url);
    free(vncms->xvnc_path);
    free(vncms->encoder_path);
    free(vncms->audio_path);
    free(vncms->webc_path);



    rsm_conf_fini(&vncms->vncms_conf);

    rsm_log_fini(&vncms->vncms_log);

    free(vncms);


}


int rsm_vncms_start_xvnc(rsm_vncms_t*vncms)
{
    return_val_if_fail(vncms!=NULL,-1);

    VNCMS_LOG_MSG(vncms->index,"About to Start BVBCS.");
    if(vncms->xvncid){
        VNCMS_LOG_WARN(vncms->index,"Xvnc is already running.");
        return -8;
    }
    //Start Xvnc with root;
    //
    int ret;
    pid_t pid;
    pid=fork();
    CHK_RUNe(pid<0,"Fork Failed.",
            return -2);

    if(pid!=0){
        //Parent:

        //may failed..
        rm_x_lock(vncms);

        //keep a stub
        vncms->xvncid=pid;
        
        //wait until Xvnc works
//        usleep(500000);


//        vncms->vncclient=rfbGetClient(8,3,4);
/*        CHK_EXPR(!vncms->vncclient,"rfbGetClient() Failed..")
            VNCMS_LOG_ERROR(vncms->index,"Allocate VncClient for Keyforward Failed.."); 
            return -3;
        END_CHK_EXPR
 */       
#ifdef _HAVE_LIBVNC
        int argc=2;
        char*argv[2];
        char vncname[32];
        char vncdest[32];
        snprintf(vncdest,sizeof(vncdest),"%s:%d",vncms->vncmsip,vncms->xvncport);
        argv[0]="VNCClient<KeyForward>";
        argv[1] =vncdest;
        VNCMS_LOG_DEBUG(vncms->index,"VNC Server Listen Addr@[%s]",vncdest); 
        ret=0;
        int n_rfbinit=5;//max retry times
        while(n_rfbinit--&&!ret){
            usleep(100000);
            vncms->vncclient=rfbGetClient(8,3,4);
            ret=rfbInitClient(vncms->vncclient,&argc,argv);
            CHK_EXPR(!ret,"Init VncClient for Keyforward Failed..")
                VNCMS_LOG_WARN(vncms->index,"KeyForward Client Initialization Failed(cnt:%d).",n_rfbinit);
                //FIXME shall cheanup resource allocate by rfbGetClient...but call rfbClientCleanup will cause SIGSEGV here!!!
//                rfbClientCleanup(vncms->vncclient); 
            END_CHK_EXPR
        }

        if(!ret){//

//            rfbClientCleanup(vncms->vncclient); 
            vncms->vncclient=NULL;
            VNCMS_LOG_ERROR(vncms->index,"Could not Initialize VncClient for key-forward..");
            return -4;
        }
//move pointer to top-left 
        SendPointerEvent(vncms->vncclient,0,0,0);
#else

        send_pointer_event(&vncms->ka,0,0,0);

#endif

        VNCMS_LOG_MSG(vncms->index,"KeyForward Client Initialization Finished.");

        return 0;
    }

    SET_THREAD_NAME("xvnc");
    //reset sigmask 
    unblock_all_signals();

    char bf_display[8];
    char bf_binpath[128];
    char bf_geometry[16];
    char bf_rfbport[8];

    snprintf(bf_rfbport,sizeof(bf_rfbport),"%d",vncms->xvncport);
    snprintf(bf_display,sizeof(bf_display),":%d",vncms->index);
    snprintf(bf_binpath,sizeof(bf_binpath),"%s",vncms->xvnc_path);
    snprintf(bf_geometry,sizeof(bf_geometry),"%dx%d",vncms->width,vncms->height);

    char*args[]={bf_binpath,
        bf_display,
        "-rfbport",bf_rfbport,
        "-desktop","XVNC",
        "-depth","24",
        "-geometry",bf_geometry,
        (void*)0};

#ifndef _DEBUG
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);
#endif

    ret=execvp(bf_binpath,args);
    CHK_RUNe(ret<0,"Exec <Xvnc> Failed.",
            exit(EXEC_FAIL));
//never get here
    return -1;
}




int rsm_vncms_stop_xvnc(rsm_vncms_t*vncms)
{
    return_val_if_fail(vncms!=NULL,-1);

    VNCMS_LOG_MSG(vncms->index,"About to Stop BVBCS.");

    int ret;



    if(!vncms->xvncid){

        VNCMS_LOG_WARN(vncms->index,"Xvnc is not running.");
        return -8;

    }

    int savpid=vncms->xvncid;
    vncms->xvncid_sav=vncms->xvncid;
    vncms->xvncid=0;

#ifdef _HAVE_LIBVNC
    //To Release KeyClient.
    if(vncms->vncclient){
        rfbClientCleanup(vncms->vncclient);
        VNCMS_LOG_MSG(vncms->index,"Clean up KeyForward Client..");
        vncms->vncclient=NULL;
    }
#endif

    //To Kill BVBCS
//    vncms->emit_kill_xvnc=1;
    

    ret=kill(savpid,SIGTERM);
    CHK_RUNe(ret<0,"Kill(term) Failed.",
            return -2);
/*
    ret=kill(savpid,SIGKILL);
    CHK_RUNe(ret<0,"Kill(kill) Failed.",
            return -3);
*/

    rm_x_lock(vncms);

    return 0;

}



int rsm_vncms_reset(rsm_vncms_t*vncms)
{

    VNCMS_LOG_MSG(vncms->index,"Do Reset VNCMS Begin.");
    int ret;
    //close all but Xvnc 

    if(!vncms->encid){
        VNCMS_LOG_MSG(vncms->index,"Encoder not running..Skip");
    }else{
        ret=rsm_vncms_close_encoder(vncms);
    }

    if(vncms->b_audio){

        if(!vncms->audid){
            VNCMS_LOG_MSG(vncms->index,"AudioRecorder not running..Skip");
        }else{
            ret=rsm_vncms_close_audiorecorder(vncms);
        }
    }

    if(!vncms->webcid){
        VNCMS_LOG_MSG(vncms->index,"WebC(Chrome) not running..Skip");
    }else{
        ret=rsm_vncms_close_webc(vncms);
    }

/*
    if(reset_xvnc){
        ret=rsm_vncms_stop_xvnc(vncms);
        CHK_RUN(ret<0,"Stop Xvnc Failed.",);
        ret=rsm_vncms_start_xvnc(vncms);
        CHK_RUN(ret<0,"Resume Xvnc Failed.",);
    }
*/

    VNCMS_LOG_MSG(vncms->index,"Do Reset VNCMS End.");
//always return 0;
    return 0;
}

#ifdef _ENABLE_KEY_TIMEOUT

int rsm_vncms_set_timeout(rsm_vncms_t*vncms,int sec)
{

    if(sec<=0){
        VNCMS_LOG_MSG(vncms->index,"To Disable Key Timeout..");
        vncms->b_timeout=0;
        vncms->keytimeout_val=0;
        vncms_unset_timeout(vncms);
        return -1;
    }

    VNCMS_LOG_MSG(vncms->index,"To Enable Key Timeout..");
    vncms->b_timeout=1;
    vncms->keytimeout_val=sec;
    vncms_set_keytimeout(vncms);

    return 0;
}

#endif


int rsm_vncms_open_webc(rsm_vncms_t*vncms)
{
    return_val_if_fail(vncms!=NULL,-1);

    VNCMS_LOG_MSG(vncms->index,"About to Open Chrome.");
                
    //Check if already opened
    if(vncms->webcid){
        VNCMS_LOG_WARN(vncms->index,"Chrome is already running.");
        return -8;
    }



    int ret;
    pid_t pid;

    char bf_userdir[128];
    char bf_url[1024];
    char bf_dispa[32];

    snprintf(bf_dispa,sizeof(bf_dispa),"--display=:%d",vncms->index);

#ifdef  _ENABLE_CHROME_CHECK_SHOW 
    //for test
#if 0
    if(vncms->index==10) 
        snprintf(bf_dispa,sizeof(bf_dispa),"--display=:%d",0);
#endif
#endif


    snprintf(bf_userdir,sizeof(bf_userdir),"--user-data-dir=/tmp/chrome%d",vncms->index);
    
    snprintf(bf_url,sizeof(bf_url),"%s?&vncport=%d&vnckeyport=%d&vncip=%s" ,
            vncms->url,
            vncms->listenport,
            vncms->keyport,
            "127.0.0.1" //
            );



    VNCMS_LOG_DEBUG(vncms->index,"Browser's Preloaded URL[%s]",bf_url);

    char*args[]={"vglrun","-c","proxy",//VGL
        vncms->webc_path,
        bf_dispa,
        "--kiosk","--no-first-run","--in-process-gpu",
        "--disable-accelerated-video","--disable-hang-monitor",
        bf_userdir,
        bf_url,(void*)0 };


    char bf_disp[8];
    char bf_vgldisp[8];
    snprintf(bf_disp,sizeof(bf_disp),":%d",vncms->index);

#ifdef  _ENABLE_CHROME_CHECK_SHOW
//for Test
#if 0
    if(vncms->index==10) 
        snprintf(bf_disp,sizeof(bf_disp),":%d",8);
#endif
#endif

    char bf_sinkid[4];
    snprintf(bf_sinkid,sizeof(bf_sinkid),"%d",vncms->sinkid);

    char*path;
    char**pargs;

    if(vncms->b_vgl){

        //Choose a available VGL display 
        int vgldisp=get_next_core_for_vgl();

        CHK_EXPR(vgldisp<0,"Get VGL ID FAILED...")
            VNCMS_LOG_ERROR(vncms->index,"Can not Probe GPU Core?? Now Disable VGL!!!");
            vgldisp=0;
            goto novgl;
        }else{
            VNCMS_LOG_MSG(vncms->index,"Using GPU Core<%d> for VGL",vgldisp);
        END_CHK_EXPR
    
        snprintf(bf_vgldisp,sizeof(bf_vgldisp),":%d",vgldisp);
    

        path="/opt/VirtualGL/bin/vglrun";
        pargs=args;
    }else{
novgl:

        path=vncms->webc_path;
        pargs=&args[3];
    }

    //called within current thread..
    make_chrome_userdata(vncms);


    pid=fork();
    CHK_RUNe(pid<0,"Fork Failed.",
            return -2);
    if(pid!=0){
        vncms->webcid=pid;
        VNCMS_LOG_WARN(vncms->index,"Webc(Chrome) Actived<pid:%d>.",vncms->webcid);
//        VNCMS_LOG_MSG(vncms->index,"PROCESS GROUP ID:[%d]--Chrome",getpgid(pid));
#ifdef _ENABLE_KEY_TIMEOUT
        VNCMS_LOG_MSG(vncms->index,"To set key timeout");
        vncms_set_keytimeout(vncms);
#endif

#ifdef _ENABLE_CHROME_CHECK_SHOW
#ifdef _ENABLE_CHROME_CHECK
    vncms->webcchk_delay=atoi(vncms->vncms_conf.rsm_chrome_checkdelay)+1;
#else
    vncms->webcchk_delay=3;
#endif
    init_chrome_check_show(vncms);
    
    sche_chrome_check_show(vncms);

#endif


        return 0;
    }

    SET_THREAD_NAME("webBrowser");
    //reset sigmask 
    unblock_all_signals();

//Puts Chrome's process & subprocess into a new process group..
    setpgid(0,0);
//    int _pid=getpid();
//    VNCMS_LOG_DEBUG(vncms->index,"-->Browser::Process ID(%d), ProcessGroup ID(%d)",_pid,getpgid(_pid));

    switch_user_to(vncms);


    setenv("PULSE_SINK",bf_sinkid,1);
    setenv("PULSE_LATENCY_MSEC","0",1);
    setenv("DISPLAY",bf_disp,1);
    setenv("VGL_DISPLAY",bf_vgldisp,1);


    ret=execvp(path,pargs);

    CHK_RUNe(ret<0,"Exec <Chrome> Failed.",
            exit(EXEC_FAIL));

    return 0;

}




int rsm_vncms_close_webc(rsm_vncms_t*vncms)
{
    return_val_if_fail(vncms!=NULL,-1);

    VNCMS_LOG_MSG(vncms->index,"About to Close Chrome.");

    int ret=0;
    int savpid;

    if(!vncms->webcid){

        VNCMS_LOG_WARN(vncms->index,"Chrome is not running.");
        return -8;
    }

#ifdef _ENABLE_CHROME_CHECK_SHOW
    fini_chrome_check_show(vncms);
#endif


#ifdef _ENABLE_KEY_TIMEOUT
    vncms_unset_timeout(vncms);
#endif

    savpid=vncms->webcid;
    vncms->webcid_sav=savpid;
    vncms->webcid=0;
//    vncms->emit_kill_webc=1;



    ret=kill(savpid,SIGTERM);
    CHK_RUNe(ret<0,"Kill(term) Failed.",
            return -2);

    ret=kill(-savpid,SIGKILL);//kill all in process group
    CHK_RUNe(ret<0,"Kill(kill) Failed.",
            return -3);

//    rm_chrome_userdata(vncms);

    return 0;

}


int rsm_vncms_open_encoder(rsm_vncms_t*vncms)
{
    return_val_if_fail(vncms!=NULL,-1);

    VNCMS_LOG_MSG(vncms->index,"About to Open Encoder.");
    if(vncms->encid){
        VNCMS_LOG_WARN(vncms->index,"Encoder is already running.");
        return -8;
    }


    int ret;
    pid_t pid;
//Start Avencoder..
  
    pid=fork();
    CHK_RUNe(pid<0,"Fork Failed.",return -2);
    if(pid!=0){
        //Parent:

        vncms->encid=pid;
        VNCMS_LOG_WARN(vncms->index,"Encoder Actived<pid:%d>.",vncms->encid);
        return 0;

    }else{

    SET_THREAD_NAME("avencoder");
    //Child:
        char bf_encpath[64];
        char bf_index[8];
        char bf_width[8];
        char bf_height[8];
        char bf_bitrate[16];
        char bf_pkbitrate[16];

//load config..
        snprintf(bf_encpath,sizeof(bf_encpath),"%s",vncms->encoder_path);
        snprintf(bf_index,sizeof(bf_index),"%d",vncms->index);
        snprintf(bf_width,sizeof(bf_width),"%d",vncms->width);
        snprintf(bf_height,sizeof(bf_height),"%d",vncms->height);
        snprintf(bf_bitrate,sizeof(bf_bitrate),"%d ",vncms->av_bitrate);
        snprintf(bf_pkbitrate,sizeof(bf_pkbitrate),"%d ",vncms->av_peakbitrate);
        char bf_encinfo[512];
        strlcpy(bf_encinfo,"\n",sizeof bf_encinfo);
        rsm_snprintf_append(bf_encinfo,sizeof bf_encinfo,"\tAVENCODER(idx:%d)\n",vncms->index);
        rsm_snprintf_append(bf_encinfo,sizeof bf_encinfo,"\t\tavencoder_path:\t[%s]\n",bf_encpath);
        rsm_snprintf_append(bf_encinfo,sizeof bf_encinfo,"\t\tgeometry      :\t[%sx%s]\n",bf_width,bf_height);
        rsm_snprintf_append(bf_encinfo,sizeof bf_encinfo,"\t\tbitrate       :\t[%s]\n",bf_bitrate);
        rsm_snprintf_append(bf_encinfo,sizeof bf_encinfo,"\t\tpeakbitrate   :\t[%s]\n",bf_pkbitrate);
        rsm_snprintf_append(bf_encinfo,sizeof bf_encinfo,"\t\tpids          :\t[%s]\n",vncms->av_pids);
        rsm_snprintf_append(bf_encinfo,sizeof bf_encinfo,"\t\tgopsize       :\t[%s]\n",vncms->av_gopsiz);
        rsm_snprintf_append(bf_encinfo,sizeof bf_encinfo,"\t\tdestaddr      :\t[%s]\n\n",vncms->av_destaddr);

        char*args[]={bf_encpath,
                    "--index",bf_index,
                    "--width",bf_width,
                    "--height",bf_height,
                    "--bitrate",bf_bitrate,
                    "--sbitrate",bf_pkbitrate,
                    "--pids",vncms->av_pids,
                    "--gopsize",vncms->av_gopsiz,
                    "--destaddr",vncms->av_destaddr,(void*)0};

    //reset sigmask 
    unblock_all_signals();

        ret=execvp(bf_encpath,args);
        CHK_RUNe(ret<0,"Exec <AVENCODER> Failed.",
                exit(EXEC_FAIL));

        return 0;
    }
//   
    return -1;
}


int rsm_vncms_open_audiorecorder(rsm_vncms_t*vncms)
{
    return_val_if_fail(vncms!=NULL,-1);

    VNCMS_LOG_MSG(vncms->index,"About to Open audiorecorder.");


    if(vncms->audid){
        VNCMS_LOG_WARN(vncms->index,"Audiorecorder is already running.");
        return -8;
    }


    int ret;
    pid_t pid;
 
    pid=fork();
    CHK_RUNe(pid<0,"Fork Failed.",
            return -2);

    if(pid!=0){
        //Parent:

        vncms->audid=pid;
        VNCMS_LOG_WARN(vncms->index,"Audiorecorder Actived<pid:%d>.",vncms->audid);

        return 0;
    }

    SET_THREAD_NAME("audioRecorder");
    //reset sigmask 
    unblock_all_signals();


    switch_user_to(vncms);

        //Child:
    char bf_index[5];
    snprintf(bf_index,sizeof(bf_index),"%d",vncms->index);
    ret=execlp(vncms->audio_path,vncms->audio_path,bf_index,(void*)0);
    CHK_RUNe(ret<0,"Exec <AudioRec> Failed.",
            exit(EXEC_FAIL));

    return 0;
}


int rsm_vncms_close_encoder(rsm_vncms_t*vncms)
{
    return_val_if_fail(vncms!=NULL,-1);

    VNCMS_LOG_MSG(vncms->index,"About to Close Encoder.");

    int ret=0;

    if(!vncms->encid){
        VNCMS_LOG_WARN(vncms->index,"Encoder is not running.");
        return -8;
    }

    int savpid=vncms->encid;
    vncms->encid_sav=vncms->encid;
    vncms->encid=0;
//    vncms->emit_kill_enc=1;
//    VNCMS_LOG_MSG(vncms->index,"Kill Encoder.");
    ret=kill(savpid,SIGKILL);
    CHK_RUNe(ret<0,"Kill Avencoder Failed.",
            return -2);

    return 0;

}


int rsm_vncms_close_audiorecorder(rsm_vncms_t*vncms)
{
    return_val_if_fail(vncms!=NULL,-1);

    VNCMS_LOG_MSG(vncms->index,"About to Close audiorecorder.");

    int ret=0;

    if(!vncms->audid){

        VNCMS_LOG_WARN(vncms->index,"Audiorecorder is not running.");
        return -8;

    }

    int savpid=vncms->audid;
    vncms->audid_sav=vncms->audid;
    vncms->audid=0;
//    vncms->emit_kill_aud=1;

    ret=kill(savpid,SIGKILL);
    CHK_RUNe(ret<0,"Kill audiorecorder Failed.",
            return -2);


    return 0;

}


#if 0
//TODO
int rsm_vncms_open_avencoder(rsm_vncms_t*vncms)
{
    
    return_val_if_fail(vncms!=NULL,-1);

}


int rsm_vncms_close_avencoder(rsm_vncms_t*vncms)
{
    
    return_val_if_fail(vncms!=NULL,-1);

}

#endif



static int forward_key(rsm_netbinder_t*binder,char*buff,int len,void*data)
{

//    CHK_RUNe((!buff||!len),"Recv Keys Error..",return -1);
    
    int ret;
    rsm_vncms_t*pvncms=(rsm_vncms_t*)data;
    VNCMS_LOG_DEBUG(pvncms->index,"Forward Key..");

    int shift=0;//?????
    int keystat=0;
    int key=0;


#ifdef _ENABLE_KEY_TIMEOUT
    //reset timer..
    vncms_reset_keytimeout(pvncms);
#endif

#ifdef _HAVE_LIBVNC
    rfbClient*vnc_client=pvncms->vncclient;
#endif    

	BlcYunKeyMsgHead* msgheader=(BlcYunKeyMsgHead*)buff;
    char*mesg=buff; 

	switch (msgheader->dev_type){

		case NblTermKeyDevType_IrrControl :
		{	
			BlcYunKeyIrrMsg* irrmsg = (BlcYunKeyIrrMsg*)mesg;
			key=conv_key_type(irrmsg);
            if(0 == key){
				break;
            }else if(3==key){
#ifdef _HAVE_LIBVNC
            	SendKeyEvent(vnc_client,XK_Alt_L,1);
            	SendKeyEvent(vnc_client,key,1);
            	SendKeyEvent(vnc_client,key,0);
            	SendKeyEvent(vnc_client,XK_Alt_L,0);
#else

                send_key_event(&pvncms->ka,XK_Alt_L,1);
                send_key_event(&pvncms->ka,key,1);
                send_key_event(&pvncms->ka,key,0);
                send_key_event(&pvncms->ka,XK_Alt_L,0);

#endif
				break;
            }
			if(irrmsg->body.key_status==2)
			{
#ifdef _HAVE_LIBVNC
				keystat = SendKeyEvent(vnc_client,key,1);
			}else{
				keystat= SendKeyEvent(vnc_client,key,0);
#else
                keystat=send_key_event(&pvncms->ka,key,1);
            }else{
                keystat=send_key_event(&pvncms->ka,key,0);
#endif
            }
//			gettimeofday(&last_key_time,NULL); 
            VNCMS_LOG_DEBUG(pvncms->index,"Forward Key<IrrControl> val:%d..send[%s]",key,keystat==0?"fail":"ok");

			break;
		}
	
		case NblTermKeyDevType_Mouse :
		{
            //Not support
			if(pvncms->chrome_type==CHROME_Normal)
				break;

			BlcYunKeyMouseMsg* mousemsg = (BlcYunKeyMouseMsg*)mesg;
			switch(mousemsg->body.key_status)
			{
				case BlcMousePropertyStat_MOUSEDEFAULT:
					break;
				case BlcMousePropertyStat_MOUSEUP:
					break;
				case BlcMousePropertyStat_MOUSEDOWN:
				{
					key = conv_mouse_type(mousemsg);
					break;
				}
				case BlcMousePropertyStat_MOUSEWHEEL:
				{
					key=conv_wheel_type(mousemsg);
					break;
				}
			}
#ifdef _HAVE_LIBVNC
			keystat = SendPointerEvent(vnc_client,mousemsg->body.x,-mousemsg->body.y,key);
#else
			keystat = send_pointer_event(&pvncms->ka,mousemsg->body.x,-mousemsg->body.y,key);
#endif
            VNCMS_LOG_DEBUG(pvncms->index,"Forward Key<Mouse> val:%d(%d)..send[%s]",key,mousemsg->body.key_status,keystat==0?"fail":"ok");
//			LOG_DEBUG_FORMAT("DEBUG - [VNCMS]:send key :%d   mouse type :%d   mouse status :%d    \n",key,mousemsg->body.key_value,mousemsg->body.key_status);
			break;
		}
		case NblTermKeyDevType_Keyboard:
		{
#if 0
            //Not support
			if(pvncms->chrome_type==CHROME_Normal)
				break;
#endif
			BlcYunKeyKeyboardMsg* keyboardmsg=(BlcYunKeyKeyboardMsg*)mesg;
			key = conv_keyboard_value(keyboardmsg,shift);
//			LOG_DEBUG_FORMAT("DEBUG - [VNCMS]:recv keygw %d   \n",keyboardmsg->body.key_value);
			if(key<0)
				break;
			else if(XK_Shift_L == key && keyboardmsg->body.key_status == 2)
				shift=1;
			else if(XK_Shift_L == key  && keyboardmsg->body.key_status == 3)
				shift=0;
#ifdef _HAVE_LIBVNC
			keystat = SendKeyEvent(vnc_client,key,(keyboardmsg->body.key_status>2?0:1));
#else
            keystat=send_key_event(&pvncms->ka,key,(keyboardmsg->body.key_status>2?0:1));
#endif
            VNCMS_LOG_DEBUG(pvncms->index,"Forward Key<Keyboard> val:%d(%d)..send[%s]",key,keyboardmsg->body.key_status,keystat==0?"fail":"ok");
			break;
		}
		default :
			break;
    }

    return CONN_KEEP;
}





static void do_close(union sigval arg)
{
    int ret;
    rsm_vncms_t*vncms=(rsm_vncms_t*)arg.sival_ptr;
	
    VNCMS_LOG_MSG(vncms->index,"Do Key Timeout Close..");

    rsm_vncms_close_encoder(vncms);
    if(vncms->b_audio)
        rsm_vncms_close_audiorecorder(vncms);
    rsm_vncms_close_webc(vncms);

    struct ew_ntfinfo*info=(struct ew_ntfinfo*)calloc(1,sizeof *info);
    info->type=TYPE_NTF_EXIT;
    eventworker_emit_event(&vncms->evtworker,VNCMS_EVT_NOTIFY,info);

}

static void show_timeout(union sigval arg)
{

    int ret;
    rsm_vncms_t*vncms=(rsm_vncms_t*)arg.sival_ptr;
	struct timeval 	pr_timout;
#ifdef _HAVE_LIBVNC
    rfbClient*pvnc=vncms->vncclient;

#if 1
	/*发送组合键到chrome 显示超时预警信息*/
	//SendPointerEvent(vnc_client,0,0,1);
	//SendPointerEvent(vnc_client,0,0,0);	
	ret=SendKeyEvent(pvnc,XK_Control_L,1);
	ret=SendKeyEvent(pvnc,XK_bracketright,1);
	ret=SendKeyEvent(pvnc,XK_bracketright,0);
	ret=SendKeyEvent(pvnc,XK_Control_L,0);
	VNCMS_LOG_MSG(vncms->index,"Do Key Timeout Show.");
#endif

#else
    KeyAgent*ka=&vncms->ka;
    ret=0;
	ret+=send_key_event(ka,XK_Control_L,1);
	ret+=send_key_event(ka,XK_bracketright,1);
	ret+=send_key_event(ka,XK_bracketright,0);
	ret+=send_key_event(ka,XK_Control_L,0);
	VNCMS_LOG_MSG(vncms->index,"Do Key Timeout Show(ret:%d).",ret);

#endif   


#ifdef _ENABLE_KEY_TIMEOUT
    vncms_unset_timeout(vncms);
    vncms_set_closetimeout(vncms);
#endif

    struct ew_ntfinfo*info=(struct ew_ntfinfo*)calloc(1,sizeof *info);
    info->type=TYPE_NTF_TIMEOUT;
    eventworker_emit_event(&vncms->evtworker,VNCMS_EVT_NOTIFY,info);

}


#ifdef _ENABLE_KEY_TIMEOUT
static inline void vncms_set_keytimeout(rsm_vncms_t*vncms)
{
    int ret;    
    

    if(vncms->webcid&&vncms->b_timeout){
        VNCMS_LOG_DEBUG(vncms->index,"Add Key-timeout Timer.");

        vncms->keytimeout_cb=show_timeout;
        ret=timer_init(&vncms->keytimeout_timer,vncms->keytimeout_val,show_timeout,vncms);
        CHK_EXPR_ONLY(ret<0,"Add Key Timer Failed..");
    }

}


static inline void vncms_reset_keytimeout(rsm_vncms_t*vncms)
{
    if(vncms->webcid&&vncms->b_timeout){


        if(vncms->keytimeout_cb==show_timeout){
            timer_reset_time(&vncms->keytimeout_timer,vncms->keytimeout_val);
        }else{
            vncms_unset_timeout(vncms);
            vncms_set_keytimeout(vncms);
        }

        VNCMS_LOG_DEBUG(vncms->index,"Reset Key-timeout Timer.");
    }
}


static inline void vncms_set_closetimeout(rsm_vncms_t*vncms)
{
    int ret;    

    if(vncms->webcid&&vncms->b_timeout){

        VNCMS_LOG_DEBUG(vncms->index,"Add Timeout-close Timer.");
 
        ret=timer_init(&vncms->keytimeout_timer,CLOSE_TIMEOUT,do_close,vncms);
        vncms->keytimeout_cb=do_close;

        CHK_EXPR_ONLY(ret<0,"Add Close Timer Failed..");
    }
}

static inline void vncms_unset_timeout(rsm_vncms_t*vncms)
{

    if(vncms->webcid&&vncms->b_timeout){
        VNCMS_LOG_DEBUG(vncms->index,"To Delete Timer.");

        timer_fini(&vncms->keytimeout_timer);
        vncms->keytimeout_cb=NULL;

    }
}



#endif

