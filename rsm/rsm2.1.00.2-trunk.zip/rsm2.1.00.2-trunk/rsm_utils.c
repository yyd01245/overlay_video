
#include"rzut/chks.h"
#include"rzut/defs.h"
#include"rsm_utils.h"

#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<ifaddrs.h>
#include<string.h>
#include<netinet/in.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<pthread.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<stdarg.h>
#include<ctype.h>

#include<pwd.h>

#include<sys/mman.h>

#ifdef _ENABLE_CHROME_CHECK_SHOW

#include<sys/shm.h>


static videosource_instanse ginstance;


videosource_instanse* locate_video_source(int index,int width,int height)
{


	ginstance.width = width;
	ginstance.height = height;
	
	ginstance.key = (key_t)index;
	ginstance.shm_size = sizeof(bvbcs_shmhdr) + ginstance.width*ginstance.height*4;

	ginstance.shm_id = shmget(ginstance.key,ginstance.shm_size, 0666|IPC_CREAT);
	if(ginstance.shm_id == -1)
	{
		fprintf(stderr, "shmget failed{%s}<id:%d,key:%d,size:%d>...\n",strerror(errno),ginstance.shm_id,ginstance.key,ginstance.shm_size);
		return NULL;
	}

	ginstance.shm_addr = shmat(ginstance.shm_id,NULL, 0);
	if(ginstance.shm_addr == (void*)-1)
	{
		fprintf(stderr, "shmat failed...\n");
		return NULL;
	}

	ginstance.shm_header= (bvbcs_shmhdr*)ginstance.shm_addr;
    ginstance.shm_rgb=ginstance.shm_header+1;

//	printf("Locate Source:: index = %d width = %d height = %d key = 0x%x  shm_id = %d shm_addr = %p shm_size = %d\n",
//		index,ginstance.width,ginstance.height,ginstance.key,ginstance.shm_id,ginstance.shm_addr,ginstance.shm_size);

	return &ginstance;
}


static int check_line(const void*line,int width){

    uint32_t*punit=(uint32_t*)line;

    int i;
    int l=-1;
    for(i=0;i<width;i++){
        if(punit[i]==0x00000000)
            continue;
        if(punit[i]==0x00ffffff){
//            fprintf(stderr,"found ff0\n");
            l=i;
            break;
        }
    }
    if(l<0){
        //not find fff0
        fprintf(stderr,"not found ff0\n");
        return 0;
    }

    for(i=l;i<width-l;i++){
        if((i-l)%4==0 &&(punit[i]!=0x00ffffff)){//little endian
            fprintf(stderr,"assert `ff0' failed\n");
            break; 
        }
        if((i-l)%4!=0 &&(punit[i]!=0x00000000)){
            fprintf(stderr,"assert `000' failed\n");
            break; 
        }
    }

    //current line matchs gray 
    if(i==width-l)
        return 1;
    

    //not gray
    return 0;

}

int check_pattern(videosource_instanse*pinstance)
{
    if(!pinstance)
        return 0;
    int ret=0;

    srand(time(NULL));

    void* start_idx=pinstance->shm_rgb;
    int line_stride=pinstance->width*4;


    int startline=rand()%pinstance->height;
    fprintf(stderr,"Start line:=%d\n",startline);
    int v;


#if 0
    int i=0;
    int height=pinstance->height;
    for(i=startline;i<height;i++){

        v=check_line((char*)start_idx+line_stride*i,pinstance->width);
        if(v==0)
            break;
    }

    if(i!=height){
        ret=0;
        fprintf(stderr,"Not Match Pattern-%d.\n",i);
    }else{
        ret=1;
        fprintf(stderr,"Match Pattern-%d.\n",i);
    }
#else

    v=check_line((char*)start_idx+line_stride*startline,pinstance->width);
    if(v==0){
        ret=0;
//        fprintf(stderr,"Not Match Pattern-%d.\n",i);
    }
    else{
        ret=1;
//        fprintf(stderr,"Match Pattern-%d.\n",i);
    }

#endif

    return ret;
    
}


#endif


void unblock_sigterm(void){
    
    sigset_t sigtermset;
    sigemptyset(&sigtermset);
    sigaddset(&sigtermset,SIGTERM);
    pthread_sigmask(SIG_UNBLOCK,&sigtermset,NULL);

}



void unblock_all_signals(void){
    
    sigset_t sigall;
    sigfillset(&sigall);
    pthread_sigmask(SIG_UNBLOCK,&sigall,NULL);
}









int rsm_get_addr_by_iface(const char*iface,char*oip,int osiz)
{
    int ret;
    const char*pret=NULL;
    struct ifaddrs*pifap,*allifap;

    ret=getifaddrs(&allifap);
    if(ret<0)
        goto fail;

    int i;
    for(pifap=allifap;pifap;pifap=pifap->ifa_next){
        if(pifap->ifa_addr==NULL || pifap->ifa_addr->sa_family!=AF_INET)
            continue;
        
        if(!strcmp(iface,pifap->ifa_name)){
            break;
        }
    }

    if(!pifap){
        fprintf(stderr,"Can not Find Addrinfo by Iface<%s>\n",iface);
        goto fail;
    }
  
    pret=inet_ntop(AF_INET,&((struct sockaddr_in*)(pifap->ifa_addr))->sin_addr,oip,osiz);


fail:
    freeifaddrs(allifap);

    if(pret)
        return 0;
    
    return -1;
}


int rsm_get_peername_by_sock(int sock,char*buff,size_t buffsiz)
{
 
    struct sockaddr_in peeraddr;
    socklen_t slen=sizeof(peeraddr);
    int ret=getpeername(sock,(struct sockaddr*)&peeraddr,&slen);
    CHK_RUNe(ret<0,"Can not obtain peer addr..",return -1);

    const char*ipstr=inet_ntop(AF_INET,&peeraddr.sin_addr,buff,buffsiz);
    CHK_RUNe(!ipstr,"Can not make ipstr..",return -2);


    return strlen(buff);
}





///////////////////////////////////////
///////////////////////////////////////
/*Callback Prototype
static void show_timeout(union sigval arg)
{
    int ret;
    void*userdata=arg.sival_ptr;
}
*/


static rsmtimer_t ztimert={0,};

int timer_is_null(rsmtimer_t*t){

    return (t->flags==0);
#if 0
    if(!memcmp(&ztimert,t,sizeof(rsmtimer_t)))
        return 1;

    return 0;
#endif
}


int timer_init(rsmtimer_t* timer,int sec,void(*callback)(union sigval),void*userdata)
{
    if(!timer_is_null(timer)){
        timer_fini(timer);
    }

    int ret;

    struct sigevent sigev;
    bzero(&sigev,sizeof sigev);
    struct itimerspec tmrsp;
    bzero(&tmrsp,sizeof tmrsp);

    pthread_attr_init(&timer->tattr);
    pthread_attr_setdetachstate(&timer->tattr,PTHREAD_CREATE_DETACHED);

    sigev.sigev_notify=SIGEV_THREAD;
    sigev.sigev_notify_function=callback;
    sigev.sigev_notify_attributes=&timer->tattr;
    sigev.sigev_value.sival_ptr=userdata;


    ret=timer_create(CLOCK_REALTIME,&sigev,&timer->timer);
    CHK_RUNe(ret<0,"Create Timer Failed.",goto fail0);


    tmrsp.it_interval.tv_sec=sec;
    tmrsp.it_value.tv_sec=sec;

    ret=timer_settime(timer->timer,0,&tmrsp,NULL);
    CHK_RUNe(ret<0,"Timer Settime Failed..",goto fail1);

    timer->flags=1;

    return 0;


fail1:
    timer_delete(timer->timer);
    CHK_EXPR_ONLY(1,"Timer Deleted..");

    pthread_attr_destroy(&timer->tattr);
    bzero(timer,sizeof(rsmtimer_t));

fail0:
    return -1;

}



void timer_fini(rsmtimer_t*timer)
{
    if(timer->flags){
        
        timer_delete(timer->timer);
        pthread_attr_destroy(&timer->tattr);
        timer->flags=0;
    }
//    bzero(timer,sizeof(rsmtimer_t));
}



int timer_reset_time(rsmtimer_t*timer,int sec)
{
    int ret; 
    struct itimerspec tmrsp;
    bzero(&tmrsp,sizeof tmrsp);

    tmrsp.it_interval.tv_sec=sec;
    tmrsp.it_value.tv_sec=sec;

    ret=timer_settime(timer->timer,0,&tmrsp,NULL);
    CHK_RUNe(ret<0,"Timer Settime Failed..",return -1);

    return 0;
}



int become_daemon(void)
{
    

    switch(fork()){
        case -1:
            return -1;
        case 0:
            break;
        default:
            _exit(EXIT_SUCCESS);
    }


    if(setsid()==-1)
        return -1;


    switch(fork()){
        case -1:
            return -1;
        case 0:
            break;
        default:
            _exit(EXIT_SUCCESS);
    }

    umask(0);
   
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
//    close(STDERR_FILENO);

    int fd=open("/dev/null",O_RDWR);
    if(fd!=STDIN_FILENO)
        return -1;

    if(STDOUT_FILENO!=dup2(STDIN_FILENO,STDOUT_FILENO))
        return -1;

//    if(STDERR_FILENO!=dup2(STDIN_FILENO,STDERR_FILENO))
//        return -1;


    return 0;
}



void init_signals(void){

    signal(SIGHUP,SIG_IGN);
    
    signal(SIGPIPE,SIG_IGN);
    signal(SIGINT,SIG_IGN);

}


int is_launch_with_root(void)
{

    int ret=geteuid();

    return !ret;

}

void get_time(char*buff,int siz)
{
    char lbuf[32];
    struct tm tmnow;
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME,&ts);
    localtime_r(&ts.tv_sec,&tmnow);
    strftime(lbuf,31,"%Y/%m/%d-%H:%M:%S",&tmnow);
    snprintf(buff,siz,"%s.%03ld",lbuf,(ts.tv_nsec+500000)/1000000);

}

void get_realtime(struct timespec*ts){

    clock_gettime(CLOCK_REALTIME,ts);
}

//ts1-ts2
void ts_minus(struct timespec*ts1,struct timespec* ts2){

    int carry=0;
    long nsec=ts1->tv_nsec-ts2->tv_nsec;
    if(nsec<0){
        nsec+=1000000000;
        carry++;
    }
    ts1->tv_sec=ts1->tv_sec-ts2->tv_sec-carry;
    ts1->tv_nsec=nsec;
}





int open_file(const char*path,int flags,mode_t mode)
{

    int ret;
    int plen=strlen(path);

    int fd;

    char* ppath=calloc(1,plen+1);
    memcpy(ppath,path,plen+1);

    char*str,*curit;

    if(ppath[0]=='/'){
        str=&ppath[1];
    }else{
        str=&ppath[0];
    }

    while(*str && (curit=strstr(str,"/"))){

        *curit=0;
        ret=mkdir(ppath,0777);
        CHK_RUNe(ret<0&&errno!=EEXIST,"MakeDirectory.",
                ret=-2;
                goto fail);

        *curit='/';
        str=curit+1;
    }

    if(*str){
//        fprintf(stderr,"___________________________:::[%s]<%s>\n",ppath,str);
        fd=open(ppath,flags,mode);
        CHK_RUNe(fd<0,"OpenFile.",
                ret=-3;
                goto fail);
    }else{
        fd=0;
    }
    free(ppath);

    return fd;

fail:
    free(ppath);
    return ret;

}


int recvtoeof(int fd,char*buff,int bufsiz,int flags)
{
    int nret,nr;

    nret=0;
    nr=0;
    while((nr=recv(fd,buff+nret,bufsiz-nret,flags))>0){
        nret+=nr;
    }

    if(nr<0&& errno!=EAGAIN)
        nret=nr;

    return nret;
}

//to XXEE
int recvXXEE(int fd,char*buff,int buffsiz,int flags)
{
    int lret,nret,nr;
    lret=nret=0;
    
    while((nr=recv(fd,buff+nret,buffsiz-nret,flags))>0){
        nret+=nr;
        buff[nret]=0;
        if(strstr(buff+lret,"XXEE"))
            break;
        lret=nret;
    }
    //timeout
    if(nr<0&& errno!=EAGAIN)
        nret=nr;

    return nret;
}


int recvXXEE_v2(int fd,char*buff,int buffsiz)
{
    int nret,nr;
    nret=0;
    char*pxxee;
    
    while((nr=recv(fd,buff+nret,buffsiz-nret,MSG_PEEK))>0){
        buff[nret+nr]=0;
        if(pxxee=strstr(buff+nret,"XXEE")){
            int off=pxxee-(buff+nret);
            //got trailing XXEE
            nr=recv(fd,buff+nret,off+4,0);//drain data from queue
            buff[nret+nr-4]=0;//remove XXEE
        }
        nr=recv(fd,buff+nret,buffsiz-nret,0);//drain data from queue

        nret+=nr;

    }

    //timeout
    if(nr<0&& errno!=EAGAIN)
        nret=nr;

    return nret;
}







int rsm_snprintf_append(char*buff,size_t buffsiz,const char*fmt,...)
{
    va_list va;
    int ret;

    int pos=strlen(buff);

    if(pos>=buffsiz-1){
        return -1;
    }

    va_start(va,fmt);

    ret=vsnprintf(buff+pos,buffsiz-pos,fmt,va);

    va_end(va);

    return ret;
}


int convert_size(const char*sizestr)
{
    int mul=1;
    int v=atoi(sizestr);
    if(v==0)
        return 0;
//get unit M/MB/K/KB/B

    int c;
    const char*pc=sizestr;
    while(*pc){
        //test the first ALPHA 
        if(isalpha(*pc)){
            switch(*pc){
                case 'K':
                case 'k': mul=1024;break;
                case 'M':
                case 'm': mul=1024*1024;break;
                case 'B':
                case 'b':
                default:  mul=1;
                          break;
            }
            break;
        }
        pc++;
    }
    
    return v*mul;
    
}








void get_memstat(mem_stat *mem) //对无类型get函数含有一个形参结构体类弄的指针O
{
    FILE *fp; 
    int n;             
    char buff[256];   
    char nam0[32];
    char nam1[32];
    fp = fopen ("/proc/meminfo", "r"); 
      
    fgets (buff, sizeof(buff), fp); 
    sscanf (buff, "%s %lu %s", nam0, &mem->total, nam1); 
    fgets (buff, sizeof(buff), fp);
    sscanf (buff, "%s %lu %s", nam0, &mem->free, nam1); 
    fgets (buff, sizeof(buff), fp);
    sscanf (buff, "%s %lu %s", nam0, &mem->available, nam1); 
//    fprintf(stderr,"Total:%lu,Free:%lu,Avail:%lu\n",mem->total,mem->free,mem->available) ;
    fclose(fp);
}

int calc_memoccupy (mem_stat *m) 
{
    if(m->total==0)
        return 0;

    int val=(int)(((m->total-m->available)*100/m->total));
    return val;
}


int calc_cpuoccupy (cpu_stat *o, cpu_stat *n) 
{   
    unsigned long od, nd;    
    unsigned long id, sd;
    int cpu_use = 0;   
    
    od = (unsigned long) (o->user + o->nice + o->system +o->idle);//第一次(用户+优先级+系统+空闲)的时间再赋给od
    nd = (unsigned long) (n->user + n->nice + n->system +n->idle);//第二次(用户+优先级+系统+空闲)的时间再赋给nd
      
    id = (unsigned long) (n->user - o->user);    //用户第一次和第二次的时间之差再赋给id
    sd = (unsigned long) (n->system - o->system);//系统第一次和第二次的时间之差再赋给sd
    if((nd-od) != 0)
        cpu_use = (int)(((sd+id)*10000)/(nd-od)); //((用户+系统)乖100)除(第一次和第二次的时间差)再赋给g_cpu_used
    else 
        cpu_use = 0;
    //printf("cpu: %u/n",cpu_use);
    return cpu_use;
}

void get_cpustat(cpu_stat *cpust) //对无类型get函数含有一个形参结构体类弄的指针O
{   
    FILE *fp;
    int n;
    char buff[256]; 
    char cpunam[10];

    fp = fopen ("/proc/stat", "r"); 
    fgets (buff, sizeof(buff), fp);
    sscanf (buff, "%s %lu %lu %lu %lu", cpunam, &cpust->user, &cpust->nice,&cpust->system, &cpust->idle);
    
    fclose(fp);
}


#ifdef _HAVE_NVML
#include<nvml.h>


static int check_nvml_error(nvmlReturn_t nvret,const char*msg,int line)
{

    if(nvret!=NVML_SUCCESS){
        fprintf(stderr,"NVML:@%d::%s:{%s}\n",line,msg,nvmlErrorString(nvret));
        return -1;
    }
    return 0;

}

#define CHK_NVML(ret,message) \
    if(check_nvml_error(ret,message,__LINE__)<0)return -1;



typedef struct _stats{
   
    nvmlDevice_t handler;
    nvmlUtilization_t utils;
    nvmlMemory_t meminfo;

    unsigned int encutil;
    unsigned int decutil;


}devstat;


/*
int get_gpu_core_num(void){

    int n_dev;
    nvmlReturn_t nvret;


    nvret=nvmlInit();
    CHK_NVML(nvret,"Init NVML");


    nvret=nvmlDeviceGetCount(&n_dev);
    CHK_NVML(nvret,"getCount");

    nvret=nvmlShutdown();
    CHK_NVML(nvret,"Shutdown NVML");


    return n_dev;

}
*/

int probe_gpustats(devstat**stats)
{

    int n_dev;
    nvmlReturn_t nvret;


    nvret=nvmlInit();
    CHK_NVML(nvret,"Init NVML");


    nvret=nvmlDeviceGetCount(&n_dev);
    CHK_NVML(nvret,"getCount");


    *stats=(devstat*)calloc(n_dev,sizeof(devstat));
    devstat*pstats=*stats;


    int i;
    for(i=0;i<n_dev;i++)
        nvmlDeviceGetHandleByIndex(i,&pstats[i].handler);

    
    for(i=0;i<n_dev;i++)
        nvmlDeviceGetMemoryInfo(pstats[i].handler,&pstats[i].meminfo);
    
    for(i=0;i<n_dev;i++)
        nvmlDeviceGetUtilizationRates(pstats[i].handler,&pstats[i].utils);
//Depend upon Driver's VERSION
#if 1
    unsigned int sampp;
    for(i=0;i<n_dev;i++)
        nvmlDeviceGetEncoderUtilization(pstats[i].handler,&pstats[i].encutil,&sampp);

    for(i=0;i<n_dev;i++)
        nvmlDeviceGetDecoderUtilization(pstats[i].handler,&pstats[i].decutil,&sampp);
#endif

    nvret=nvmlShutdown();
    CHK_NVML(nvret,"Shutdown NVML");


    return n_dev;
}



static int get_core_by_mem(devstat*ps,int n_dev)
{
    int maxfreeind=0;
    long long maxfree=0;
    int i;
    for(i=0;i<n_dev;i++){
        long long free=ps[i].meminfo.free; 
        if(free>maxfree){
            maxfree=free;
            maxfreeind=i;
        }
    }
  
    return maxfreeind;

}


int get_next_core(void)
{
    
    devstat*ds;
    int n;
    n=probe_gpustats(&ds);
    if(n<0)
        return -1;

    n=get_core_by_mem(ds,n);  

    free(ds);

    return n;
}
#else


int get_next_core(void)
{
    return 0;
}

#endif



int get_gpu_num(void){

#ifdef _HAVE_NVML
    int n_dev;
    nvmlReturn_t nvret;


    nvret=nvmlInit();
    CHK_NVML(nvret,"Init NVML");


    nvret=nvmlDeviceGetCount(&n_dev);
    CHK_NVML(nvret,"getCount");

    nvret=nvmlShutdown();
    CHK_NVML(nvret,"Shutdown NVML");

    return n_dev;

#else
    return 1;

#endif
}




int get_gpustats(gpu_stats *gpust)
{
#ifdef _HAVE_NVML
    devstat*devlists=NULL;
    int ngpu=probe_gpustats(&devlists);

    gpust->n=ngpu;
    int i=0;
    for(i=0;i<ngpu;i++){
        gpust->gpus[i].gpu=devlists[i].utils.gpu;
        gpust->gpus[i].mem=devlists[i].meminfo.used*100/devlists[i].meminfo.total;
        gpust->gpus[i].enc=devlists[i].encutil;
        gpust->gpus[i].dec=devlists[i].decutil;
    }
    free(devlists);
    return ngpu;
#else
    gpust->n=1;
    return 1;
#endif
}

int calc_gpuoccupy(gpu_stats*gpust,int*ogpu,int*omem,int*oenc,int*odec){


    int tgpu=0; 
    int tmem=0;
    int tenc=0;
    int tdec=0;
    int i;
    for(i=0;i<gpust->n;i++){
       tgpu+=gpust->gpus[i].gpu; 
       tmem+=gpust->gpus[i].mem; 
       tenc+=gpust->gpus[i].enc; 
       tdec+=gpust->gpus[i].dec; 
    }

    *ogpu=tgpu/gpust->n;
    *omem=tmem/gpust->n;
    *oenc=tenc/gpust->n;
    *odec=tdec/gpust->n;

    return 0;
}

//never release shm
int prepare_shm_for_vgl(void){
#ifdef _HAVE_NVML
    int shmfd;
    void* shmaddr;

    time_t*pt0=NULL;
    int *flag=NULL;
    int *idx=NULL;
    int* ngpu=NULL;

    shmfd=shm_open("/vgldisp.id",O_CREAT|O_RDWR,0666);
    ftruncate(shmfd,64);
    shmaddr=mmap(NULL,64,PROT_READ|PROT_WRITE,MAP_SHARED,shmfd,0);
    if(shmaddr==(void*)-1){
//        fprintf(stderr,"mmap failed........................\n");
        return -1;
    }


    flag=(int*)shmaddr;
    ngpu=(int*)(shmaddr+sizeof(int));
    idx=(int*)(shmaddr+sizeof(int)+sizeof(int));
    pt0=(time_t*)(shmaddr+sizeof(int)+sizeof(int)+sizeof(int));
    *flag=1;
    *idx=0;
    *pt0=0;
    *ngpu=get_gpu_num();

#else
    return 0;
#endif
}

int get_next_core_for_vgl(void)
{
#ifdef _HAVE_NVML

    static int ngpu;
    static int shmfd;
    static void* shmaddr;
    int nc;
    time_t t1;
    time_t*pt0=NULL;
    int *flag=NULL;
    int *idx=NULL;
    int* pngpu=NULL;
    time(&t1);

    // shmaddr layout [flag,idx,timestamp]

    if(!shmfd||!shmaddr){
        shmfd=shm_open("/vgldisp.id",O_RDWR,0666);
 //       ftruncate(shmfd,64);
        shmaddr=mmap(NULL,64,PROT_READ|PROT_WRITE,MAP_SHARED,shmfd,0);
        if(shmaddr==(void*)-1){
//            fprintf(stderr,"mmap failed........................\n");
            shmaddr=NULL; 
            return 0;
        }
    }

    flag=(int*)shmaddr;
    pngpu=(int*)(shmaddr+sizeof(int));
    idx=(int*)(shmaddr+sizeof(int)+sizeof(int));
    pt0=(time_t*)(shmaddr+sizeof(int)+sizeof(int)+sizeof(int));

    while(!__sync_bool_compare_and_swap(flag,1,0)){
//        fprintf(stderr,"?\n");
        usleep(10);
    }
    

//    fprintf(stderr,"TimeStamp:(%d-%d=%d)\n",t1,*pt0,t1-*pt0);
    if(t1-(*pt0)>1){ 

//       fprintf(stderr,"Num of Core:%d(%d-%d=%d)\n",*pngpu,t1,*pt0,t1-*pt0);

        devstat*devlists=NULL;
        ngpu=probe_gpustats(&devlists);
        int gpuu,memu;
        int i=0;
        int gpumin=100,gpumin_idx;
    
        for(i=0;i<ngpu;i++){
            gpuu=devlists[i].utils.gpu;
    //        memu=devlists[i].meminfo.used*100/devlists[i].meminfo.total;
            if(gpuu<gpumin){
                gpumin=gpuu;
                gpumin_idx=i; 
            }
        }
        free(devlists);
        nc=gpumin_idx;
        *idx=gpumin_idx;
//        __sync_synchronize();
//        fprintf(stderr,"=============\n");
    }else{
       
        nc=__sync_add_and_fetch(idx,1);
        if(!pngpu||!*pngpu)
            *pngpu=1;
        nc%=(*pngpu);
//        fprintf(stderr,"++++++++++(%d:%d)\n",nc,*pngpu);
    }

    *pt0=t1;
    *flag=1;
     __sync_synchronize();
    
    return nc;


#else

    return 0;
#endif


}






cJSON*rsm_parse_json_file(const char*jsonfile)
{

    int fd=open(jsonfile,O_RDONLY);
    if(fd<0)
        return NULL;

    char buff[2048];
    int nr=0;
    int len=0;

    while((nr=read(fd,buff+len,(sizeof buff)-len))>0){
        len+=nr;
    }

    if(nr<0){
        close(fd);
        return NULL;
    }

    close(fd);

    cJSON*json=cJSON_Parse(buff);

    return json;

}







#if 0

int main(){
    

    cpu_stat o={0,};
    cpu_stat n={0,};
    mem_stat m={0,};

    while(1){
        
        get_memstat(&m);
        get_cpustat(&n);
        int val=calc_cpuoccupy(&o,&n);
        int mval=calc_memoccupy(&m);
        o=n;
        printf("CPU status:%d .mem:%d\n",val,mval);

        sleep(1);
    }



    return 0;

}
#endif
