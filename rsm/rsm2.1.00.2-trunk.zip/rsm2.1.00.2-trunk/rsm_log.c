
#include"rsm_log.h"

#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

#include"rzut/chks.h"
#include"rzut/defs.h"
#include"rzut/sysutils.h"
#include"rsm_utils.h"

#include<unistd.h>



#if 1
#define LOCK(var) \
    pthread_mutex_lock(&((var)->lock))

#define UNLOCK(var) \
    pthread_mutex_unlock(&((var)->lock))
#else

#define LOCK(var) 
#define UNLOCK(var) 

#endif

static rsm_log_t the_log;



static struct {

    int level;
    const char* lv_str;
}level2str[]={
    {0,"[NNNN]"},
    {LOG_LEVEL_INFO,"[INFO]"},
    {LOG_LEVEL_DEBUG,"[DEBUG]"},
    {LOG_LEVEL_MSG,"[MESSAGE]"},
    {LOG_LEVEL_WARN,"[WARN]"},
    {LOG_LEVEL_ERROR,"[ERROR]"},
    {LOG_LEVEL_UNKNOW,"[UNKNOW]"}

};


#define BUFFLEN 8192

#define LOG_FMT "<COL_TS><TIMESTAMP><COL_Reset> <COL_LV><LEVEL><COL_Reset> <COL_MOD><<MODULE>><COL_Reset>:: <COL_MSG><MESSAGE><COL_Reset>"

#define COL_TS     "\033[31m"
#define COL_LV     "\033[32m"
#define COL_MOD    "\033[34;1m"
#define COL_MSG    " " // "\033[33m"
#define COL_Reset  "\033[0m"




static struct _logdata{
  
    char logfile_prefix[MAX_FILELEN];
    char logfilename[MAX_FILELEN];
    FILE* logfp;

}my_logdata;




static void my_log_output(char*msg,void*data)
{   

    struct _logdata*logdata=(struct _logdata*)data;

    fprintf(logdata->logfp,"%s\n",msg);
    fflush(logdata->logfp);

}








static void* log_queue_thr(rsm_log_t*log)
{
    pthread_setname_np(pthread_self(),"log-thread");

    int ret;
    sigset_t set,oset;
    sigfillset(&set);
    ret=pthread_sigmask(SIG_BLOCK,&set,&oset);


    char*pmsg;

//    ret=pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
//    CHK_EXPRe_ONLY(ret!=0,"Set Thread Cancelstate.");

    while(1){

        ret=async_que_deque(&log->msgq,(void**)&pmsg);
        int msiz=strlen(pmsg);

        time_t now;
        struct tm tmnow;
        time(&now);
        localtime_r(&now,&tmnow);
        
        LOCK(log);
        if(log->log_siz+msiz>=log->log_maxsiz||tmnow.tm_yday!=log->date){
            //reset_logfunc
            rsm_log_reset_func(log,NULL);
            log->log_siz=msiz;

        }else{
            log->log_siz+=msiz;
        }
        UNLOCK(log);

        if(log->log_func)
            log->log_func(pmsg,log->log_data);
 //        printf("\nXXX[%s\n",pmsg);
        free(pmsg);

    }

}





int rsm_log_init(rsm_log_t*log)
{
    int ret;
    return_val_if_fail(log!=NULL,-1);
    bzero(log,sizeof(rsm_log_t));

    log->log_siz=0;
    log->log_maxsiz=5*1024*1024;//default size
    log->b_stderr=1;
    log->log_filter=LOG_LEVEL_INFO;


    ret=async_que_init(&log->msgq);
    CHK_RUNe(ret<0,"Init AsyncQueue Failed.",return -2);


    pthread_attr_t tattr;
    pthread_attr_init(&tattr);
    pthread_attr_setdetachstate(&tattr,PTHREAD_CREATE_DETACHED);

    ret=pthread_create(&log->logthr,&tattr,(void*(*)(void*))log_queue_thr,log);
    pthread_attr_destroy(&tattr);
    CHK_RUNe(ret!=0,"Create Logging Thread Failed..",goto fail0);

    pthread_mutex_init(&log->lock,NULL);

    return 0;

fail0:
    async_que_fini(&log->msgq);

    return -3;
}



void rsm_log_reset_func(rsm_log_t*log,const char*filename)
{
//    fprintf(stderr,"======\n");
    return_if_fail(log!=NULL);
    

    time_t now;
    struct tm tmnow;
    time(&now);
    localtime_r(&now,&tmnow);
    
    log->date=tmnow.tm_yday;

    //save file's prefix for later uses;
    if(filename)
        strlcpy(my_logdata.logfile_prefix,filename,sizeof(my_logdata.logfile_prefix));
    else
        filename=my_logdata.logfile_prefix;

    char timestr[32];
    strftime(timestr,sizeof(timestr),"%m%d.%H%M%S",&tmnow);
    char realfile[64];
    snprintf(realfile,sizeof realfile,"%s.%s",filename,timestr);

    strlcpy(my_logdata.logfilename,realfile,sizeof(my_logdata.logfilename));
    char *p;
    p=strrchr(my_logdata.logfilename,'/');
    if(!p){
        p=my_logdata.logfilename;
    }else{
        p+=1;
    }

    if(!access(my_logdata.logfile_prefix,F_OK)){
        unlink(my_logdata.logfile_prefix);
    }
    symlink(p,my_logdata.logfile_prefix);

    if(my_logdata.logfp){
        fclose(my_logdata.logfp);
//        my_logdata.logfp=0;
    }
    int fd=open_file(my_logdata.logfilename,O_CREAT|O_WRONLY|O_APPEND,0666);
    CHK_EXPRe_ONLY(fd<0,"Open Log Failed..");
 
    my_logdata.logfp=fdopen(fd,"a");
    CHK_EXPRe_ONLY(my_logdata.logfp==NULL,"Open Logfile Failed.");


    rsm_log_set_logging_func(log,my_log_output,&my_logdata);

}

void rsm_log_set_maxsize(rsm_log_t*log,int maxsize)
{
//    fprintf(stderr,"MAXSIZE::%d\n",maxsize);
    return_if_fail(log!=NULL);
    if(maxsize<1*1024){
        maxsize=1024*5;
    }

    LOCK(log);
    log->log_maxsiz=maxsize;
    UNLOCK(log);
}


#ifdef _DEFAULT_


int rsm_log_init_default(const char*filename)
{
    int ret;
    bzero(&the_log,sizeof(the_log));
    ret=rsm_log_init(&the_log);
    rsm_log_reset_func(&the_log,filename);

    return ret;
}


void rsm_log_fini_default()
{
    rsm_log_fini(&the_log);
    if(my_logdata.logfp){
        fclose(my_logdata.logfp);
        my_logdata.logfp=NULL; 
    }
}



void rsm_log_default(int lv,const char*mod,const char*fmt,...)
{
    va_list ap;
    va_start(ap,fmt);

    rsm_logv(&the_log,lv,mod,fmt,ap);

    va_end(ap);
}


rsm_log_t*rsm_get_log(){
    return &the_log;
}


#endif

void rsm_log_fini(rsm_log_t*log)
{
    return_if_fail(NULL!=log);

    pthread_cancel(log->logthr);
    async_que_fini(&log->msgq);

    if(log->log_data==&my_logdata && my_logdata.logfp ){
        fclose(my_logdata.logfp);
    }
    pthread_mutex_destroy(&log->lock);

}




void rsm_log_set_filter(rsm_log_t*log,int lv)
{
    return_if_fail(NULL!=log);

    LOCK(log);
    log->log_filter=lv;
    UNLOCK(log);
}



void rsm_log_set_logging_func(rsm_log_t*log,logging_func func,void* data)
{
    return_if_fail(NULL!=log);

    if(func){
//        LOCK(log);
        log->log_func=func;
        log->log_data=data;
//        UNLOCK(log);
    }
}



static void format_output2(char*buffout,char*bufferr,char*msg,size_t siz,int level,const char*modstr)
{
     
    int ret;
    time_t now;
    struct tm tmnow;
    time(&now);
    localtime_r(&now,&tmnow);

    char timestr[48];
//    ret=strftime(timestr,sizeof(timestr),"%Y/%m/%d-%H:%M:%S",&tmnow);
    get_time(timestr,48);

    char levelstr[16];
    ret=snprintf(levelstr,sizeof(levelstr),"%s",level2str[level].lv_str);

//    char modstr[24];
//    ret=get_current_module_name(modstr,sizeof(modstr));

    strlcpy(buffout,LOG_FMT,siz);
    strlcpy(bufferr,LOG_FMT,siz);

    strrepl(buffout,"<TIMESTAMP>",timestr);
    strrepl(bufferr,"<TIMESTAMP>",timestr);

    strrepl(buffout,"<LEVEL>",levelstr);
    strrepl(bufferr,"<LEVEL>",levelstr);

    strrepl(buffout,"<MODULE>",modstr);
    strrepl(bufferr,"<MODULE>",modstr);


    strrepl(buffout,"<COL_LV>","");
    strrepl(buffout,"<COL_MOD>","");
    strrepl(buffout,"<COL_TS>","");
    strrepl(buffout,"<COL_MSG>","");
    strrepl(buffout,"<COL_Reset>","");
  

    strrepl(bufferr,"<COL_LV>",COL_LV);
    strrepl(bufferr,"<COL_MOD>",COL_MOD);
    strrepl(bufferr,"<COL_TS>",COL_TS);
    strrepl(bufferr,"<COL_MSG>",COL_MSG);
    strrepl(bufferr,"<COL_Reset>",COL_Reset);
  
    strrepl(buffout,"<MESSAGE>",msg);
    strrepl(bufferr,"<MESSAGE>",msg);

}





void rsm_logv(rsm_log_t*log,int lv,const char*mod,const char*fmt,va_list ap)
{
    if(lv<log->log_filter)
        return;

    static char msg[BUFFLEN]={0,};
    static char buff[BUFFLEN]={0,};
    static char bufferr[BUFFLEN]={0,};

    LOCK(log);
    vsnprintf(msg,sizeof(msg),fmt,ap);

    format_output2(buff,bufferr,msg,BUFFLEN,lv,mod);

    if(log->b_stderr){
        fprintf(stderr,"%s\n",bufferr);
        fflush(stderr);
    }

    async_que_enque(&log->msgq,strdup(buff));
    UNLOCK(log);

}



void rsm_log(rsm_log_t*log,int lv,const char*mod,const char*fmt,...)
{
    va_list ap;
    va_start(ap,fmt);

    rsm_logv(log,lv,mod,fmt,ap);

    va_end(ap);
}





#if 0






int main(int argc,char**argv)
{


#ifdef _DEFAULT_

    rsm_log_init_default("fff.log");
#else
    rsm_log_t log;
    rsm_log_init(&log);
    rsm_log_reset_func(&log,"logg.log");
#endif

    int c=0;

    while(1){
        
#ifdef _DEFAULT_
//        rsm_log_default(LOG_LEVEL_DEBUG,"SbSb%s0-0","hello,world");
        RSM_LOG_ERROR("Hello,M<<%s]]","joker");
#else
        rsm_log(&log,LOG_LEVEL_DEBUG,"MMOODD","SbSb%s0-0","hello,world");
#endif
        sleep(1);
        c++;
        if(c==5)
            break;
    }

#ifdef _DEFAULT_
    rsm_log_fini_default();
#else
    rsm_log_fini(&log);
    fclose(my_logdata.logfp);
#endif
    return 0;
}

#endif
