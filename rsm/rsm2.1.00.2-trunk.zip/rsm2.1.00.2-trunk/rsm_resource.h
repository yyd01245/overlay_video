#ifndef _H_RESOURCE_RSM_
#define _H_RESOURCE_RSM_

#include"rzut/zlist.h"
#include"rsm_config.h"
#include"rsm_log.h"
#include"rsm_net.h"
#include"eventworker.h"


#include<pthread.h>
#include"cJSON/cJSON.h"


#ifdef _ENABLE_CHROME_CHECK
#define HB_MAXDELAY 3
#define HB_MAXRETRY 3
#endif


typedef struct _resource rsm_resource_t;

typedef struct _rsm_struct rsm_service_t;

typedef struct res_pool{
   
    rsm_resource_t**revindex;

    rsm_service_t*rsmserv;//

    //4类资源的链表头节点
    struct list_head freehead;
    struct list_head prehead;
    struct list_head busyhead;
    struct list_head failhead;//vncms failed

    int num_fail;//vncms进程失败的数目
    int num_free;//空闲数
    int num_pre;//当前预启动完成数
    int num_busy;//使用中的数目(avon+avoff)
    int num_setpre;//配置的预启动数

    //资源index范围
    int maxidx;
    int startidx;


    rsm_conf_t* config;
    char rsmipstr[INET_ADDRSTRLEN];
    pthread_mutex_t reslock;//not used
}rsm_resource_pool;



//Resource 的三种状态
enum{
    RES_FAIL=0,//vncms挂了或起不来
    RES_PRE=1,//预启动成功
    RES_BUSY=3,//已登录
    RES_FREE=4//init
};

//avencoder进程的状态
enum{
    AVSTATUS_ON=0,//turn on
    AVSTATUS_OFF //turn off
};


struct ew_vncmsinfo{
    int type;
#define TYPE_VNCMS_TIMEOUT 1 
#define TYPE_VNCMS_EXIT 2
#define TYPE_VNCMS_ALIVE 3 
#define TYPE_VNCMS_ACT_REPLY 4 
#define TYPE_VNCMS_RESET_WEBC 5 
    rsm_resource_t*res;//
    cJSON*json;
};





struct _resource{

    int index;
    rsm_resource_pool*ref_pool;//引用rsm_resource_pool的config
#define rrsmipstr ref_pool->rsmipstr
#define rref_conf ref_pool->config
#define rserv ref_pool->rsmserv

    eventworker_t* ref_worker;//reference to rsm_service_t's main eventworker..

////////////////
//below variables are volatile during operation
    int status;//RES_BUSY RES_PRE RES_FREE RES_FAIL
    int avstatus;//AVSTATUS_ON AVSTATUS_OFF
    time_t start_ts;//timestamp for avencoder on
#ifdef _ENABLE_CHROME_CHECK
    time_t hb_ts;//heartbeat timestamp of chrome
    int n_hbdelay;//delay check
    int n_hbretry;//check times
#endif

#ifdef _ENABLE_CHROME_CHECK_SHOW
    int webcchk_show;
#endif
    char*resid;
    char*url;
    char*serialno;
    char iip[INET_ADDRSTRLEN];
    int iport;
    int rate;
    int peakrate;

    int keytimeout;//键值超时seconds
////////////////
///

    int avencfd;//avencoder.pid file fd;

    pid_t vncmspid;

    //connect to vncms
    rsm_netlsender_t* sender;
    int sendport;//


    //connect to crsm
    rsm_netconn_t* crsmconn;
    int connport;//


    //connect from vncms
    pthread_t binder_tid;
    rsm_netlbinder_t* binder;
    int bindport;//


    //linked node
    struct list_head list;

};



rsm_resource_pool*rsm_resource_pool_init(rsm_resource_pool*respool,rsm_conf_t *conf,rsm_service_t*serv,int size);
void rsm_resource_pool_fini(rsm_resource_pool*respool);


rsm_resource_t*rsm_resource_pool_new_resource(rsm_resource_pool*respool,int idx);
void rsm_resource_pool_free(rsm_resource_pool*respool,rsm_resource_t*ps);

rsm_resource_t*rsm_resource_pool_get_resource_by_index(rsm_resource_pool*respool,int index);

/*
 * RSM报文相关
 *
 */
int rsm_resource_pool_preload(rsm_resource_pool*respool);

int rsm_resource_reset_webc(rsm_resource_t*res);

rsm_resource_t*rsm_resource_pool_login(rsm_resource_pool*respool,const cJSON*pjson,cJSON**retjson);//const char*jsonstr);

rsm_resource_t*rsm_resource_pool_logout(rsm_resource_pool*respool,const cJSON*pjson,cJSON**retjson);//const char*jsonstr);

rsm_resource_t*rsm_resource_pool_pause(rsm_resource_pool*respool,const cJSON*pjson,cJSON**retjson);

int rsm_resource_pool_sync(rsm_resource_pool*respool,const cJSON*pjson,cJSON**retjson);

int rsm_resource_pool_getserverinfo(rsm_resource_pool*respool,const cJSON*pjson,cJSON**retjson);

cJSON*rsm_resource_pool_get_reslists(rsm_resource_pool*respool,int *nlist);

/*
 * 获取资源状态
 */
inline int rsm_resource_pool_check_index(rsm_resource_pool*respool,int index,rsm_resource_t**ps);

inline int rsm_resource_pool_get_free_num(rsm_resource_pool*respool);

inline int rsm_resource_pool_get_busy_num(rsm_resource_pool*respool);

inline int rsm_resource_pool_get_num(rsm_resource_pool*pool,int*freenum,int*busynum,int*prenum);

inline int rsm_resource_pool_get_stream_num(rsm_resource_pool*pool);

inline int rsm_resource_pool_statistic_busy(rsm_resource_pool*pool,char*numarray,int arraysiz);

void rsm_resource_pool_get_resource_info(rsm_resource_pool*respool,int*noconf,int*nook);

/*
 * move resource between Fail and Free..
 */
int rsm_resource_pool_mark_resource_fail(rsm_resource_t*ps);

int rsm_resource_pool_mark_resource_free(rsm_resource_t*ps);

#endif
