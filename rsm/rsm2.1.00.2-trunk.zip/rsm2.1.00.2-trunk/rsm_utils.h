#ifndef _H_UTILS_RSM_
#define _H_UTILS_RSM_


#include<time.h>
#include<signal.h>

#include<sys/types.h>
#include<fcntl.h>

#include"cJSON/cJSON.h"

#define EXEC_FAIL 188



#define iffreez(val) if(val){free(val);val=NULL;}

#define iffree(val) if(val)free(val);


void get_time(char*buff,int siz);

int become_daemon(void);

void init_signals(void);

void unblock_all_signals(void);
void unblock_sigterm(void);

int rsm_get_addr_by_iface(const char*iface,char*oip,int osiz);

int rsm_get_peername_by_sock(int sock,char*buff,size_t buffsiz);


void get_realtime(struct timespec*ts);

//ts1-ts2
void ts_minus(struct timespec*ts1,struct timespec* ts2);





typedef struct _mytimer_t{
    int flags;//null
    timer_t timer;
    pthread_attr_t tattr;

}rsmtimer_t;



int timer_init(rsmtimer_t* timer,int sec,void(*callback)(union sigval),void*userdata);
void timer_fini(rsmtimer_t*timer);
int timer_reset_time(rsmtimer_t*timer,int sec);
int timer_is_null(rsmtimer_t*t);


cJSON*rsm_parse_json_file(const char*jsonfile);

int open_file(const char*path,int flags,mode_t mode);

int rsm_snprintf_append(char*buff,size_t buffsiz,const char*fmt,...);

int convert_size(const char*sizestr);

int is_launch_with_root(void);



int recvtoeof(int fd,char*buff,int bsiz,int flags);

int recvXXEE(int fd,char*buff,int buffsiz,int flags);

int recvXXEE_v2(int fd,char*buff,int buffsiz);


int get_next_core(void);

int prepare_shm_for_vgl(void);
int get_next_core_for_vgl(void);


typedef struct _cpu//定义一个cpu occupy的结构体
{
    unsigned long user; //定义一个无符号的int类型的user
    unsigned long nice; //定义一个无符号的int类型的nice
    unsigned long system;//定义一个无符号的int类型的system
    unsigned long idle; //定义一个无符号的int类型的idle
}cpu_stat;

typedef struct mPACKED         //定义一个mem occupy的结构体
{
    unsigned long total; 
    unsigned long free;                       
    unsigned long available;                       
}mem_stat;

typedef struct _gpu{
    unsigned long gpu;
    unsigned long mem;
    unsigned long enc;
    unsigned long dec;
    
}gpu_stat;

typedef struct _gpus{
    int n;
    gpu_stat gpus[24];
}gpu_stats;





void get_memstat(mem_stat *mem);
void get_cpustat(cpu_stat *cpust);
int get_gpustats(gpu_stats *gpust);

int calc_cpuoccupy (cpu_stat *o, cpu_stat *n) ;
int calc_memoccupy (mem_stat *m) ;
int calc_gpuoccupy(gpu_stats*gpust,int*ogpu,int*ogmem,int *oenc,int*odec);


int get_gpu_num(void);




#ifdef _ENABLE_CHROME_CHECK_SHOW

#include"bvbcs.h"

typedef struct
{
	int width;
	int height;

	
	key_t key;
	int shm_id;
	void *shm_addr;
	unsigned int shm_size;
    bvbcs_shmhdr*shm_header;
    void*shm_rgb;

}videosource_instanse;

static videosource_instanse ginstance;


videosource_instanse* locate_video_source(int index,int width,int height);

int check_pattern(videosource_instanse*pinstance);

#endif





#endif
