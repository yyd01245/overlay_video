#ifndef _H_CONFIG_RSM_
#define _H_CONFIG_RSM_


#include"confile.h"
#include"netinet/in.h"



struct _rsm_conf{

    confile_t*config;

/////////////////////////////////////////////
/////////////////////////////////////////////

    char rsmipstr[INET_ADDRSTRLEN];

    const char* rsm_area_id;// = 0571
    const char* rsm_ctype;// = portal
    const char* rsm_vendor;// = nvidia

    const char* rsm_net_iface;// = eth0
    const char* rsm_listen_port;// = 25000

    const char* crsm_ip;// = 192.168.188.188
    const char* crsm_port;// = 15117


    const char*rsm_limit_cpu;
    const char*rsm_limit_mem;
    const char*rsm_limit_gpumem;

    const char* vncms_serverport;// = 5900
    const char* vncms_keyport;// = 62000
    const char* vncms_listenport;// = 63000
    const char*rsm_vncms_listenport;//=61000
    const char* vncms_keytimeout;// 

    const char* vncms_enable_vgl;
    const char* rsm_chrome_type;
#ifdef _ENABLE_PLUGIN_CHECK
    const char* rsm_chrome_plugin_url;
    const char* rsm_chrome_plugin_chkperiod;
#endif
#ifdef _ENABLE_CHROME_CHECK
    const char* rsm_chrome_checkport;
    const char* rsm_chrome_checkdelay;
#endif

    const char* rsm_vid_type;// = hd
    const char* rsm_vid_width;// = 1280
    const char* rsm_vid_height;// = 720

    const char* rsm_vid_num;// = 80
    const char* rsm_vid_startidx;// = 4//[0..3] for vgl display;
    const char* rsm_vid_pa_num;// = 8
    const char* rsm_vid_pa_prefix;// = x

 
    const char* rsm_pre_url;// = file:///opt/init.html
    const char* rsm_pre_amount;// = 8 
    const char* rsm_pre_httpport;  
   
    const char* rsm_enc_audio;// = 1
    const char* rsm_enc_path;// = /usr/local/bin/avencoder
    const char* rsm_enc_audiopath;// = audiorecoder

    const char* rsm_enc_gop;// = 5:100
    const char* rsm_enc_video_rate;// = 3000
    const char* rsm_enc_video_peakrate;// = 3000
    const char* rsm_enc_gpu_amount;// = 4
    const char* rsm_enc_service_id;// = 124
    const char* rsm_enc_pmt_pid;// = 2307
    const char* rsm_enc_pmt_vid;// = 515
    const char* rsm_enc_pmt_aid;// = 680


    const char* rsm_log_path;// = log/rsm.log
    const char* rsm_log_level;// = 1
    const char* rsm_log_size;// =



};

typedef struct _rsm_conf rsm_conf_t;



int rsm_conf_init(rsm_conf_t*conf,const char*filename);
void rsm_conf_fini(rsm_conf_t*conf);

int rsm_conf_reset(rsm_conf_t*conf,const char*filename);


const char*rsm_conf_get_value(rsm_conf_t*conf,const char*key);




rsm_conf_t*rsm_conf_obtain_default();
int rsm_conf_init_default(const char*filename);
rsm_conf_t*rsm_conf_default(void);
void rsm_conf_fini_default();
const char*rsm_conf_get_value_default(const char*key);











#endif
