
#include"rsm_config.h"
#include"rsm_utils.h"
#include"rsm.h"
#include"confile.h"
#include"rzut/defs.h"
#include"rzut/chks.h"

#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<stdlib.h>


static rsm_conf_t the_conf;




int rsm_conf_init(rsm_conf_t*conf,const char*filename)
{
   
    conf->config=confile_parse_file(filename);
    CHK_RUN(!conf->config,"Parse file",return -1) ;

/* Assign variables from config file
 */
    conf-> rsm_area_id=rsm_conf_get_value(conf,"RSM.AREA_ID");
    conf-> rsm_ctype=rsm_conf_get_value(conf,"RSM.C_TYPE");
    conf-> rsm_vendor=rsm_conf_get_value(conf,"RSM.VENDOR");

    conf-> rsm_net_iface=rsm_conf_get_value(conf,"RSM.NET_IFACE");
    conf-> rsm_listen_port=rsm_conf_get_value(conf,"RSM.LISTEN_PORT");

    rsm_get_addr_by_iface(conf->rsm_net_iface,conf->rsmipstr,sizeof(conf->rsmipstr));

    conf-> crsm_ip=rsm_conf_get_value(conf,"CRSM.IP");
    conf-> crsm_port=rsm_conf_get_value(conf,"CRSM.PORT");

    conf-> vncms_serverport=rsm_conf_get_value(conf,"VNCMS.VNCSERVER_PORT");
    conf-> vncms_keyport=rsm_conf_get_value(conf,"VNCMS.KEYPORT");
    conf-> vncms_listenport=rsm_conf_get_value(conf,"VNCMS.LISTENPORT");
    conf-> rsm_vncms_listenport=rsm_conf_get_value(conf,"RSM.VNCMS.LISTENPORT");
    conf-> vncms_keytimeout=rsm_conf_get_value(conf,"VNCMS.KEY_TIMEOUT");

    conf-> vncms_enable_vgl=rsm_conf_get_value(conf,"VNCMS.ENABLE_VGL");
    conf-> rsm_chrome_type=rsm_conf_get_value(conf,"RSM.CHROME.TYPE");

#ifdef _ENABLE_PLUGIN_CHECK
    conf-> rsm_chrome_plugin_url=rsm_conf_get_value(conf,"RSM.CHROME.PLUGIN_URL");
    conf-> rsm_chrome_plugin_chkperiod=rsm_conf_get_value(conf,"RSM.CHROME.PLUGIN_CHECK_PERIOD");
#endif

#ifdef _ENABLE_CHROME_CHECK
    conf-> rsm_chrome_checkport=rsm_conf_get_value(conf,"RSM.CHROME.CHECKPORT");
    conf-> rsm_chrome_checkdelay=rsm_conf_get_value(conf,"RSM.CHROME.CHECKDELAY");
#endif

    conf-> rsm_limit_cpu=rsm_conf_get_value(conf,"RSM.LIMIT.CPU");
    conf-> rsm_limit_mem=rsm_conf_get_value(conf,"RSM.LIMIT.MEM");
    conf-> rsm_limit_gpumem=rsm_conf_get_value(conf,"RSM.LIMIT.GPUMEM");

    conf-> rsm_vid_type=rsm_conf_get_value(conf,"RSM.VID.TYPE");
    conf-> rsm_vid_width=rsm_conf_get_value(conf,"RSM.VID.WIDTH");
    conf-> rsm_vid_height=rsm_conf_get_value(conf,"RSM.VID.HEIGHT");

    conf-> rsm_vid_num=rsm_conf_get_value(conf,"RSM.VID.NUM");
    conf-> rsm_vid_startidx=rsm_conf_get_value(conf,"RSM.VID.START_IDX");
    conf-> rsm_vid_pa_num=rsm_conf_get_value(conf,"RSM.VID.PA_NUM");
    conf-> rsm_vid_pa_prefix=rsm_conf_get_value(conf,"RSM.VID.PA_PREFIX");

 
    conf-> rsm_pre_url=rsm_conf_get_value(conf,"RSM.PRE.URL");
    conf-> rsm_pre_amount=rsm_conf_get_value(conf,"RSM.PRE.AMOUNT");
    conf-> rsm_pre_httpport=rsm_conf_get_value(conf,"RSM.PRE.HTTPPORT");
  
   
    conf-> rsm_enc_audio=rsm_conf_get_value(conf,"RSM.ENC.AUDIO");
    conf-> rsm_enc_path=rsm_conf_get_value(conf,"RSM.ENC.PATH");
    conf-> rsm_enc_audiopath=rsm_conf_get_value(conf,"RSM.ENC.AUDIOPATH");
    
    conf-> rsm_enc_gop=rsm_conf_get_value(conf,"RSM.ENC.GOP");
    conf-> rsm_enc_video_rate=rsm_conf_get_value(conf,"RSM.ENC.VIDEO_RATE");
    conf-> rsm_enc_video_peakrate=rsm_conf_get_value(conf,"RSM.ENC.VIDEO_PEAKRATE");
    conf-> rsm_enc_gpu_amount=rsm_conf_get_value(conf,"RSM.ENC.GPU_AMOUNT");
    conf-> rsm_enc_service_id=rsm_conf_get_value(conf,"RSM.ENC.SERVICE_ID");
    conf-> rsm_enc_pmt_pid=rsm_conf_get_value(conf,"RSM.ENC.PMT_PID");
    conf-> rsm_enc_pmt_vid=rsm_conf_get_value(conf,"RSM.ENC.PMT_VID");
    conf-> rsm_enc_pmt_aid=rsm_conf_get_value(conf,"RSM.ENC.PMT_AID");


    conf-> rsm_log_path=rsm_conf_get_value(conf,"RSM.LOG.PATH");
    conf-> rsm_log_level=rsm_conf_get_value(conf,"RSM.LOG.LEVEL");
    conf-> rsm_log_size=rsm_conf_get_value(conf,"RSM.LOG.SIZE");

   

    return 0;    
}



int rsm_conf_reset(rsm_conf_t*conf,const char*filename)
{

    return_val_if_fail(NULL!=conf,-1);
    confile_free(conf->config);
//    conf->config=NULL;
    bzero(conf,sizeof(rsm_conf_t));

    return rsm_conf_init(conf,filename);
}


void rsm_conf_fini(rsm_conf_t*conf)
{
    return_if_fail(conf);

    confile_free(conf->config);

}


const char*rsm_conf_get_value(rsm_conf_t*conf,const char*key)
{
    return_val_if_fail(conf,NULL);
    
    cf_node_t*node=confile_get_config(conf->config,key,NULL);
    if(node)
        return node->cfn_val;
    else
        return "";
}







int rsm_conf_reset_default(const char*filename)
{

    confile_free(the_conf.config);
//    conf->config=NULL;
    bzero(&the_conf,sizeof(rsm_conf_t));

    return rsm_conf_init_default(filename);
}





int rsm_conf_init_default(const char*filename)
{
    bzero(&the_conf,sizeof(rsm_conf_t));
    return rsm_conf_init(&the_conf,filename);
}



rsm_conf_t*rsm_conf_default(void)
{
//    if(region_is_zero(&the_conf,sizeof(rsm_conf_t)))
    return &the_conf;
}




void rsm_conf_fini_default(void)
{
    rsm_conf_fini(&the_conf);
}

const char*rsm_conf_get_value_default(const char*key)
{
    return rsm_conf_get_value(&the_conf,key);
}



rsm_conf_t*rsm_conf_obtain_default()
{

    return &the_conf;

}
#if 0


int main(int argc,char**argv)
{

//    int fd=open(argv[1],O_RDONLY);


    rsm_conf_t rsm_conf;

    rsm_conf_init(&rsm_conf,argv[1]);

//    rsm_conf_init_default(argv[1]);


    print_all(&rsm_conf);
//    print_all(rsm_conf_default());

//    char*val=rsm_conf_get(&rsm_conf,argv[2]);
//    char*val=rsm_conf_get_value_default(argv[2]);

//    if(val)
//        printf("{%s:%s}\n",argv[2],val);

    rsm_conf_fini(&rsm_conf);
//    rsm_conf_fini_default();

//    close(fd);
    return 0;
}

#endif


