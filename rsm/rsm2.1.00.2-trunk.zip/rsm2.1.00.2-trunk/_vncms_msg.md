RSM VNCMS Exchange messages.
===========================



###SEND TO VNCMS::::

```
{"action":<action>,...}

<action>::
            "start-vnc";
            "stop-vnc";
            "open-webc";
            "open-enc";  (destaddr="dest address", rate="bitrate")
            "open-avenc"; == "open-enc" + "open-audio"
            "open-audio";
            "close-webc";
            "close-enc";
            "close-avenc",
            "close-audio";
            "set-timeout"; ( val="timeout-value" )
            "reset"; == "close-webc" + "close-avenc" //always return 0;
   
```




##SEND TO RSM::::

```
{"notify":<notify>,...}

<notify>::
        "timeout"; (time="201500521")
        "exit";(time="201500521")
        "alive";(time="201500521")
        "action-reply";(action="open-webc",retcode="-8",details="running already")
        "proc-relaunch"
        "chrome-not-show"
 
```


