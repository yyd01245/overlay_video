#include"rsm.h"
#include"rsm_msg.h"
#include"vncms_msg.h"
#include"rsm_resource.h"
#include"rsm_service.h"

#include"rzut/chks.h"
#include"rzut/defs.h"
#include"rzut/zlist.h"
#include"cJSON/cJSON.h"
#include"rsm_utils.h"

#include<unistd.h>
#include<string.h>
#include<wait.h>
#include<sys/types.h>
#include<sys/stat.h>

#ifdef _ENABLE_PLUGIN_CHECK
//for plugin check&update
#include <curl/curl.h>
#endif 



/////////////////////////////////////////

static int do_logout(rsm_service_t*serv,cJSON*proot,cJSON**pret);//,int sockfd);
static int do_login(rsm_service_t*serv,cJSON*proot,cJSON**pret);//int fd);
static int do_exist(rsm_service_t*serv,cJSON*proot,cJSON**pret);//int fd);
static int do_pause(rsm_service_t*serv,cJSON*proot,cJSON**pret);//int fd);

//New Added,for interactive with 'crsm_check'
static int do_sync(rsm_service_t*serv,cJSON*proot,cJSON**pret);//int fd);

static int do_getserverinfo(rsm_service_t*serv,cJSON*proot,cJSON**pretjson);
static int do_getreslist(rsm_service_t*serv,cJSON*proot,cJSON**pretjson);

static int _rsm_service_report_register(rsm_service_t*serv);
static int _rsm_service_report_alive(rsm_service_t*serv);
static int _rsm_service_report_alarmevent(rsm_service_t*serv,rsm_resource_t*ps,int lv,const char*desc);

static int rsmhttp_worker(int fd,void*data);
static int cmdlisten_worker(int fd,void*data);


int emit_alarmevent(rsm_resource_t*res,int level,const char*desc);



static void rsm_init_system(rsm_service_t*serv)
{
    pthread_mutex_init(&serv->syslock,NULL);
    pthread_cond_init(&serv->syscond,NULL);
}


static void rsm_fini_system(rsm_service_t*serv)
{
    pthread_mutex_destroy(&serv->syslock);
    pthread_cond_destroy(&serv->syscond);
}




//must called within main-thread(eventworker),otherwise will cause deadlock
static int rsm_system(rsm_service_t*serv,const char*cmd)
{
    int ret;

    int pid=fork();
    if(pid<0){
        RSM_LOG_ERROR("rsm_system Failed(fork)..");
        return -1;
    }
    if(pid!=0){
        serv->sysid=pid; 
        pthread_mutex_lock(&serv->syslock);

        while(serv->sysid!=0){
//            fprintf(stderr,"\033[31mXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\033[0m");
            pthread_cond_wait(&serv->syscond,&serv->syslock);
        }

        pthread_mutex_unlock(&serv->syslock);

        return 0;
    }

    ret=execlp("/bin/sh","sh","-c",cmd,NULL);

    return EXEC_FAIL;
}






inline int rsm_service_conn_to_crsm(rsm_service_t*serv,void*buff,size_t len,void*obuff,size_t osiz)
{
    int nr;
    nr=rsm_netconn_shot(serv->reporter,buff,len,obuff,osiz);
    if(nr>=0)
        ((char*)obuff)[nr]=0;
    return nr;

}

//send this when received msg is not valid json format;
static int write_null_msg(int fd){
    const static char retmsg[]="{}XXEE";
    return write(fd,retmsg,sizeof(retmsg));
}

#ifdef _ENABLE_PLUGIN_CHECK

static int ew_dispose_plucheck(void*data,void*udata)
{
    
    int ret;
    rsm_service_t*serv=(rsm_service_t*)data;
    struct ew_pluinfo*info=(struct ew_pluinfo*)udata;

    char*path=info->plugin_path;
    char*savpath=info->save_path;
    free(info);
//    path need not to be free..
    //uncompress downloaded plugin and chrome's configuration..
   
    char cmd[256];

#if 0
    snprintf(cmd,sizeof cmd, "rm -rf /opt/%s/*",PLUGIN_DIR);
    ret=system(cmd);
    CHK_EXPRe(ret<0,"System Call")
        RSM_LOG_WARN("Execute [%s] Failed<%d>..",cmd,ret);
    END_CHK_EXPRe
#endif


    if(strstr(path,".zip"))
        snprintf(cmd,sizeof cmd, "unzip -o %s -d /opt",savpath);
    else
        snprintf(cmd,sizeof cmd, "tar xf %s -C /opt",savpath);


    RSM_LOG_MSG("To Execute [%s] ",cmd);
    ret=rsm_system(serv,cmd);
    CHK_EXPRe(ret!=0,"System Call")
        RSM_LOG_WARN("Execute [%s] Failed<%d>..",cmd,ret);
    END_CHK_EXPRe

    RSM_LOG_MSG("Execute [%s] Finished.",cmd);

    snprintf(cmd,sizeof cmd, "chmod 777 -R /opt/%s",PLUGIN_DIR);
    ret=rsm_system(serv,cmd);
    CHK_EXPRe(ret!=0,"System Call")
        RSM_LOG_WARN("Execute [%s] Failed<%d>..",cmd,ret);
    END_CHK_EXPRe


    //get version of plugin

    return EVW_PRESIS;
}

#endif


static int ew_dispose_cmd(void*data,void*udata)
{
    
    
    int ret;
    rsm_service_t*serv=(rsm_service_t*)data;
    struct ew_cmdinfo*cmd=(struct ew_cmdinfo*)udata;

    int fd=cmd->fd;
    free(cmd);

    char buff[8192];
    char retbuff[4096];

//    ret=recv(fd,buff,sizeof buff,0);
    ret=recvXXEE(fd,buff,sizeof buff,0);//not return until find XXEE..
    CHK_EXPRe(ret<=0,"Invalid Read From Client..")
        RSM_LOG_DEBUG("CMD Read Failed..");
        goto skip;
    END_CHK_EXPRe
    
    buff[ret]=0;

//    RSM_LOG_DEBUG("Start Dispose CMD size(%d/%d)[%s]..",ret,strlen(buff),buff);
    RSM_LOG_DEBUG("Start Dispose CMD(len:%d)[%s]..",strlen(buff),buff);

    cmd_t cmdtp;
    cJSON*proot=NULL;//=rsm_msg_to_json(buff);
    cmdtp=rsm_parse_json_cmd(buff,&proot);
    CHK_EXPR(!proot,"Make Json Failed...")
        RSM_LOG_WARN("Can not Parse[%s] to JSON..",buff);
        goto fail;

    END_CHK_EXPR

    cJSON*pretjson=NULL;

/////////
    switch(cmdtp){

        case RSM_CMD_LOGIN:{

		    do_login(serv,proot,&pretjson);
            break;
            }

        case RSM_CMD_LOGOUT:{

		    do_logout(serv,proot,&pretjson);
            break;
            }

        case RSM_CMD_PAUSE:{

            do_pause(serv,proot,&pretjson);
            break;
            }
                       
        case RSM_CMD_EXIST:{

            do_exist(serv,proot,&pretjson);
            break;
            }

        case RSM_CMD_SYNC:{
            
            do_sync(serv,proot,&pretjson);
            break;
            }

        case RSM_CMD_GETSERVERINFO:{
            
            do_getserverinfo(serv,proot,&pretjson);
            break;
            }

        case RSM_CMD_GETRESLIST:{
            
            do_getreslist(serv,proot,&pretjson);
            break;
            }

        default:{

            RSM_LOG_WARN("CMD[%s] Not Implemented...",rsm_cmd_to_str(cmdtp));
            cJSON_Delete(proot);
            goto fail;
            }

    }
/////////////////////

    rsm_make_json_cmd(pretjson,retbuff,sizeof(retbuff));
    RSM_LOG_MSG("To Reply CMD[%s] to CRSM..",retbuff);

    ret=send(fd,retbuff,strlen(retbuff),MSG_NOSIGNAL);
    CHK_EXPRe(ret<=0,"Send to CRSM Failed..")
        RSM_LOG_WARN("Send Reply to CRSM Failed..");
    END_CHK_EXPRe

    cJSON_Delete(proot);
    cJSON_Delete(pretjson);

    close(fd);
    
    RSM_LOG_DEBUG("CMD[%s] Processed OK....",rsm_cmd_to_str(cmdtp));

    return EVW_PRESIS;



fail:

    write_null_msg(fd);
    RSM_LOG_WARN("InValid CRSM Requestion[%s]",buff);//"(No Delimiter`XXEE` Found or not Wellformed Json Format)..");
skip:
//    shutdown(fd,SHUT_RDWR);
    close(fd);
//    usleep(20000);

    return EVW_PRESIS;
}


static int ew_dispose_rep(void*data,void*udata)
{
    
    int ret;
    rsm_service_t*serv=(rsm_service_t*)data;
    struct ew_repinfo*rep=(struct ew_repinfo*)udata;

    int type=rep->type;
    rsm_resource_t*res=rep->info.alarm.res;
    int level=rep->info.alarm.level;
//    cJSON*json=rep->info.alarm.json;
    const char*desc=rep->info.alarm.desc;

    free(rep);

    switch(type)
    {
        
        case TYPE_REP_REGISTER:
        _rsm_service_report_register(serv);
        break;

        case TYPE_REP_ALIVE:
        _rsm_service_report_alive(serv);
        break;


        case TYPE_REP_ALARMEVENT:

        _rsm_service_report_alarmevent(serv,res,level,desc);
        if(!res && level==3)//no resid specified caused && level ==3
            _rsm_service_report_alive(serv);

        break;


        default:
        break;
    }

    return EVW_PRESIS;
}

static int ew_dispose_vncms(void*data,void*udata)
{
    
    int ret;
    rsm_service_t*serv=(rsm_service_t*)data;
    struct ew_vncmsinfo*rep=(struct ew_vncmsinfo*)udata;

    int type=rep->type;
    rsm_resource_t*res=rep->res;

    free(rep);

    switch(type)
    {
         
#ifdef _ENABLE_CHROME_CHECK
        case TYPE_VNCMS_RESET_WEBC:{
            res->n_hbdelay=HB_MAXDELAY;
            res->n_hbretry=HB_MAXRETRY;
            res->hb_ts=0;
            __sync_synchronize();
//            RSM_LOG_DEBUG("To Restart Chrome<idx:%d> (cnt:%d)",res->index,res->webc_recnt);
            RSM_LOG_DEBUG("To Reset Chrome<idx:%d>",res->index);
            //FIXME reset only when chrome is on,to reduce vncms' complaint.
//            if(res->webc_recnt>=0)
#if 1
            rsm_resource_reset_webc(res);
#endif
//
        break;
                           }
#endif
        case TYPE_VNCMS_TIMEOUT:{
//
        break;
                           }

        case TYPE_VNCMS_EXIT:{
//
        break;
                        }

        case TYPE_VNCMS_ALIVE:{

//
        break;

                         }
        case TYPE_VNCMS_ACT_REPLY:{
//
        break;
        }

        default:
        break;
    }

    return EVW_PRESIS;
}



static int ew_dispose_signal(void*data,void*udata)
{
    
    int ret;
    rsm_service_t*serv=(rsm_service_t*)data;
    struct ew_siginfo*sigi=(struct ew_siginfo*)udata;

    int pid=sigi->pid;
    int signo=sigi->signo;
    int fl_exit=sigi->fl_exit;
    int fl_kill=sigi->fl_kill;
    int isvncms=0;//whether the pid belongs to avncms

    free(sigi);

    if(signo==SIGCHLD){//always true

        rsm_resource_t*res;
        rsm_resource_pool *pool=&serv->respool;

        int i;
        for(i=pool->startidx;i<=pool->maxidx;i++){
            
            res=pool->revindex[i];
            if(res&&res->vncmspid==pid){
                RSM_LOG_WARN("A VNCMS<pid:%d> has been terminated..",pid);
                isvncms=1;
                res->vncmspid=0;
        //        move vncms from other status to fail
                rsm_resource_pool_mark_resource_fail(res);
                //preload resource
                rsm_resource_pool_preload(pool);
                break; 
            }
        }

        
        if(isvncms 
                && fl_exit!=EXEC_FAIL 
                ){
#if 0
            //RELAUNCH
            RSM_LOG_WARN("To Relaunch VNCMS<idx:%d>..",res->index);


            pid_t pid;
        
            pid=fork();
        
            if(pid==0){
             //CHILD PROCESS
                 char idx[8];
                 snprintf(idx,sizeof(idx),"%d",res->index);
           
                 ret=execlp("./vncms","vncms",idx,(void*)0);
                 CHK_RUNe(ret<0,"Launch VNCMS Failed..",
                       exit(EXEC_FAIL));
                
            }else{
                //Parent
                res->vncmspid=pid;
                RSM_LOG_WARN("new VNCMS with PID:%d..",pid);
                rsm_resource_pool_mark_resource_free(res);
                res->vncms_cnt=3;//reset

            }
#else
            RSM_LOG_WARN("VNCMS<idx:%d> Gone..",res->index);

#endif
        }

/*
        if(!isvncms){
            RSM_LOG_MSG("SIGCHLD may raised by System()..") ;   
        }
 */       

    }
#if 0
    else     
    if(signo==SIGTERM){

        RSM_LOG_MSG("To Terminate RSM..Wait Break Eventworker");

    }
#endif


    return EVW_PRESIS;
}




//GLOBAL
rsm_log_t*global_rsmlog;

void rsm_print_conf(rsm_conf_t*conf);

int rsm_service_init(rsm_service_t*serv,const char*confname)
{
    int ret;
    return_val_if_fail(serv!=NULL,-1);
//    fprintf(stderr,"Init Serv[%p]\n",serv);

    bzero(serv,sizeof(rsm_service_t));
//First thing (Init logger)
    ret=rsm_log_init(&serv->rsmlog);
    CHK_RUN(ret<0,"Init RSM log Failed.",
            goto fail0);

    //for global reference
    global_rsmlog=&serv->rsmlog;

    ret=rsm_conf_init(&serv->rsmconf,confname);
    CHK_RUN(ret<0,"Init RSM conf Failed.",
            goto fail1);

    serv->cpulimit=atoi(serv->rsmconf.rsm_limit_cpu);
    serv->memlimit=atoi(serv->rsmconf.rsm_limit_mem);
    serv->gpumemlimit=atoi(serv->rsmconf.rsm_limit_gpumem);


    char logfile[128];
    snprintf(logfile,sizeof(logfile),"%s/rsm.log",serv->rsmconf.rsm_log_path);

    rsm_log_set_maxsize(&serv->rsmlog,convert_size(serv->rsmconf.rsm_log_size));
    rsm_log_reset_func(&serv->rsmlog,logfile);

    ret=is_launch_with_root();
    CHK_EXPRe(ret==0,"`root' privilege required!!")
        RSM_LOG_ERROR("`root' privilege required!! Aborting...")
        goto fail2;
    END_CHK_EXPRe

    RSM_LOG_MSG("\n\n\t\tBBCVision\n\t\tRSM Version: "RSM_VERSION"(%s)\n",__DATE__);
    rsm_print_conf(&serv->rsmconf);
    
    ret=rsm_get_addr_by_iface(serv->rsmconf.rsm_net_iface,serv->rsmipstr,sizeof(serv->rsmipstr));
    CHK_RUN(ret<0,"Can not Detect Net Interface that specified in rsm.conf...",
            goto fail2);


    /****Net Stuff******/
//    fprintf(stderr,"Init Serv[%p]\n",serv);
    serv->cmdlistener=rsm_netlistener_new(serv->rsmipstr,atoi(serv->rsmconf.rsm_listen_port));
    CHK_EXPR(!serv->cmdlistener,"Init CMD Listener Failed..")

        RSM_LOG_ERROR("Init CMD Listener Failed..");
        goto fail3;
    END_CHK_EXPR


//    serv->httplistener=rsm_netlistener_new("0.0.0.0",atoi(serv->rsmconf.rsm_pre_httpport));
    serv->httplistener=rsm_httplistener_new("0.0.0.0",atoi(serv->rsmconf.rsm_pre_httpport));
    CHK_EXPR(!serv->httplistener,"Init HTTP Listener Failed..")

        RSM_LOG_ERROR("Init HTTP Listener Failed..");
        goto fail4;
    END_CHK_EXPR


    serv->reporter=rsm_netconn_new(serv->rsmconf.crsm_ip,atoi(serv->rsmconf.crsm_port));
    CHK_EXPR(!serv->reporter,"Init Reporter Failed.")
        
        RSM_LOG_ERROR("Init Reporter Failed..");
        goto fail5;
    END_CHK_EXPR


    int num=atoi(serv->rsmconf.rsm_vid_num);
    CHK_RUN(num<=0,"Invalid num of resources.. using 1 instead",
            num=1);
    


    sigset_t set,oset;
    sigfillset(&set);
    ret=pthread_sigmask(SIG_BLOCK,&set,&oset);

    rsm_resource_pool* pool;
    pool=rsm_resource_pool_init(&serv->respool,&serv->rsmconf,serv,num);
    CHK_EXPR(!pool,"Init RSM ResourcePool Failed..")
        
        RSM_LOG_ERROR("Init RSM ResourcePool Failed..");
        goto fail6;
    END_CHK_EXPR
        
    RSM_LOG_MSG("Init RSM Service Success, %d vncms created",num);

//FIXME
//    pthread_sigmask(SIG_SETMASK,&oset,NULL);

    ret=eventworker_init(&serv->evtworker);
    CHK_EXPR(ret<0,"Init EventWorker Failed..")
        
        RSM_LOG_ERROR("Init EventWorker Failed..");
        goto fail7;
    END_CHK_EXPR


//	pthread_mutex_init(&serv->wait_exit,NULL);
//	pthread_cond_init(&serv->notify_exit,NULL);

    serv->rpt_hearttime=5;//DEFAULT
    serv->rpt_overtime=60;//DEFAULT
    serv->registered=0;//Not registered;

#ifdef _HAVE_NVML
    prepare_shm_for_vgl();
#endif
    rsm_init_system(serv);

    return 0;

fail7:
    rsm_resource_pool_fini(&serv->respool);
    goto fail60;
fail6:
    pthread_sigmask(SIG_SETMASK,&oset,NULL);
fail60:
    rsm_netconn_free(serv->reporter);

fail5:
    rsm_httplistener_free(serv->httplistener);
fail4:
    rsm_netlistener_free(serv->cmdlistener);
fail3:

fail2:
    rsm_conf_fini(&serv->rsmconf);
fail1:
    rsm_log_fini(&serv->rsmlog);
fail0:

    return -2;

}




void rsm_service_fini(rsm_service_t*serv)
{
    RSM_LOG_MSG("TO Finalize RSM Service..");

    int ret;
    return_if_fail(serv!=NULL);

    rsm_resource_pool_fini(&serv->respool);


    rsm_netconn_free(serv->reporter);
    rsm_httplistener_free(serv->httplistener);
    rsm_netlistener_free(serv->cmdlistener);


    rsm_conf_fini(&serv->rsmconf);
    rsm_log_fini(&serv->rsmlog);

    rsm_fini_system(serv);

    eventworker_fini(&serv->evtworker);

}


static void*thread_dispatchcmd(void*data)
{
    RSM_LOG_MSG("Enter CMD Listen Thread..");
    SET_THREAD_NAME("rsm-cmdlistener");

    rsm_service_t*serv=(rsm_service_t*)data;
    rsm_netlistener_t*listener=serv->cmdlistener;

    rsm_netlistener_listen(listener);


    return NULL;
}



static int rsm_service_start_dispatch(rsm_service_t*serv)
{
    RSM_LOG_MSG("To Start CRSM CMD Dispatcher..");

    return_val_if_fail(NULL!=serv,-1);
    
    rsm_netlistener_set_worker(serv->cmdlistener,cmdlisten_worker,serv);

    eventworker_register_event(&serv->evtworker,RSM_EVT_CMD,ew_dispose_cmd,serv);

    int ret;

    pthread_attr_t tattr;
    pthread_attr_init(&tattr);
    pthread_attr_setdetachstate(&tattr,PTHREAD_CREATE_DETACHED);

    ret=pthread_create(&serv->cmdlisten_tid,&tattr,thread_dispatchcmd,serv);
    pthread_attr_destroy(&tattr);
    CHK_RUNe(ret!=0,"Create CRSM CMD Dispatch Thread.",
            return -2);

    return 0;
}

static void rsm_service_stop_dispatch(rsm_service_t*serv)
{
    RSM_LOG_MSG("To Stop CRSM CMD Dispatcher..");
    
    eventworker_unregister_event(&serv->evtworker,RSM_EVT_CMD);
    pthread_cancel(serv->cmdlisten_tid);

}

static void*thread_http(void*data)
{
    RSM_LOG_MSG("Enter HTTP Listen Thread..");

    SET_THREAD_NAME("rsm-httpserv");

    rsm_service_t*serv=(rsm_service_t*)data;
    rsm_httplistener_t*listener=serv->httplistener;
//    rsm_listener_t*listener=(rsm_netlistener_t*)data;
    rsm_httplistener_listen(listener);


    return NULL;
}



static int rsm_service_start_httpserver(rsm_service_t*serv)
{
    RSM_LOG_MSG("To Start HTTP Listener..");

    
    return_val_if_fail(NULL!=serv,-1);
    int ret;
    rsm_httplistener_set_worker(serv->httplistener,rsmhttp_worker,serv);

    pthread_attr_t tattr;
    pthread_attr_init(&tattr);
    pthread_attr_setdetachstate(&tattr,PTHREAD_CREATE_DETACHED);

    ret=pthread_create(&serv->httplisten_tid,&tattr,thread_http,serv);
    pthread_attr_destroy(&tattr);
    CHK_RUNe(ret!=0,"Create Http Listen Thread.",
            return -2);


    return 0;
}

static void rsm_service_stop_httpserver(rsm_service_t*serv)
{
    RSM_LOG_MSG("To Stop HTTP Listener..");

    pthread_cancel(serv->httplisten_tid);

}




static int _rsm_service_report_alive(rsm_service_t*serv)
{

    rsm_netconn_t*conn=serv->reporter;

    cJSON*pjson=NULL;

#define servconf serv->rsmconf
    int num_free=rsm_resource_pool_get_free_num(&serv->respool);
    int num_busy=rsm_resource_pool_get_busy_num(&serv->respool);

    char pnumfree[16];
    char pnumuse[16];
    char kbitrate[16];//RATE

    snprintf(pnumfree,sizeof(pnumfree),"%d",num_free);
    snprintf(pnumuse,sizeof(pnumuse),"%d",num_busy);
    snprintf(kbitrate,sizeof(kbitrate),"%d",atoi(servconf.rsm_enc_video_rate)*1024);
    char pmgmtport[8];
    snprintf(pmgmtport,sizeof(pmgmtport),"%d",atoi(servconf.rsm_listen_port)+1);


    static int cnt=1;
    static int acnt=1;
    char serialno[32];
    snprintf(serialno,sizeof serialno,"90909090909090909090%04d",cnt++);

    if(serv->in_overloaded){
        snprintf(serialno,sizeof serialno,"2333333333333333333%04d",acnt++);
        snprintf(pnumfree,sizeof(pnumfree),"%d",0);
    }

    pjson=rsm_get_json_cmd(RSM_CMD_ALIVE,"areaid",servconf.rsm_area_id,"videotype",servconf.rsm_vid_type,
        "vnctype",servconf.rsm_ctype,"vendor",servconf.rsm_vendor,
        "totalnum",servconf.rsm_vid_num,"freenum",pnumfree,"streamnum",pnumuse,
        "rate",kbitrate,//servconf.rsm_enc_video_rate,
        "vncip",serv->rsmipstr,"vncport",servconf.rsm_listen_port,
        "mgmtport",pmgmtport,"serialno",serialno,NULL); 

#undef servconf

    char sbuff[512];
    char rbuff[256]={0,};

    rsm_make_json_cmd(pjson,sbuff,sizeof(sbuff));

    RSM_LOG_MSG("Send To CRSM VNCALIVE:[%s]\n",sbuff);

    int ret=rsm_service_conn_to_crsm(serv,sbuff,strlen(sbuff),rbuff,sizeof(rbuff));
    CHK_EXPR(ret<0,"Connect to CRSM")

        RSM_LOG_WARN("Can not Connect to CRSM");
        goto fail;
    END_CHK_EXPR

    RSM_LOG_MSG("Recv From CRSM VNCALIVE:[%s]\n",rbuff);

    cmd_t rcmd=rsm_parse_json_cmd(rbuff,&pjson);
    CHK_EXPR(rcmd!=RSM_CMD_ALIVE,"Error CMD Type(not vncalive)..")

        RSM_LOG_WARN("Invalid Json Format(Not vncalive)");
        goto fail;
    END_CHK_EXPR

    ////////
    char*pcmd=NULL,*pretcode=NULL,*povertime=NULL;

    ret=rsm_json_fill(pjson,"cmd",&pcmd,"retcode",&pretcode,"overtime",&povertime,NULL);    
    CHK_EXPR(ret!=3,"Parse Json Failed..")

        iffree(pcmd);
        iffree(pretcode);
        iffree(povertime);

        RSM_LOG_WARN("Invalid Json Format(Missing Fields)");
        goto fail;
    END_CHK_EXPR

    if(pretcode[0]!='0'){
        RSM_LOG_WARN("VNCALIVE return Failed..");
    }else{
        serv->rpt_overtime=atoi(povertime); 
        RSM_LOG_MSG("Set VNCALIVE's Overtime to <%d> seconds",serv->rpt_overtime);
    }

    
    free(povertime);
    free(pcmd);
    free(pretcode);

    cJSON_Delete(pjson);


    return 0;

fail:

    if(pjson)
        cJSON_Delete(pjson);

    return -1;

}




static int _rsm_service_report_register(rsm_service_t*serv)
{

    rsm_netconn_t*conn=serv->reporter;

    cJSON*pjson=NULL;
    char kbitrate[16];

#define servconf serv->rsmconf

    char pmgmtport[8];
    snprintf(pmgmtport,sizeof(pmgmtport),"%d",atoi(servconf.rsm_listen_port)+1);
    snprintf(kbitrate,sizeof(kbitrate),"%d",atoi(servconf.rsm_enc_video_rate)*1024);
    static int cnt=1;
    char serialno[32];
    snprintf(serialno,sizeof serialno,"80808080808080808080%04d",cnt++);

        //vncregister;
    pjson=rsm_get_json_cmd(RSM_CMD_REG,"areaid",servconf.rsm_area_id,"videotype",servconf.rsm_vid_type,
                "vnctype",servconf.rsm_ctype,"vendor",servconf.rsm_vendor,
                "totalnum",serv->rsmconf.rsm_vid_num,"rate",kbitrate,//servconf.rsm_enc_video_rate,
                "vncip",serv->rsmipstr,"vncport",servconf.rsm_listen_port,
                "mgmtport",pmgmtport,"serialno",serialno,NULL); 
#undef servconf


    char sbuff[256];
    char rbuff[256]={0,};

    rsm_make_json_cmd(pjson,sbuff,sizeof(sbuff));
    cJSON_Delete(pjson);
    pjson=NULL;

    RSM_LOG_MSG("Send To CRSM VNCREGISTER:[%s]\n",sbuff);

    int ret=rsm_service_conn_to_crsm(serv,sbuff,strlen(sbuff),rbuff,sizeof(rbuff));
    CHK_EXPR(ret<0,"Connect to CRSM")

        RSM_LOG_WARN("Can not Connect to CRSM");
        goto fail;
    END_CHK_EXPR


    RSM_LOG_MSG("Recv From CRSM VNCREGISTER:[%s]\n",rbuff);

    cmd_t rcmd=rsm_parse_json_cmd(rbuff,&pjson);
    CHK_EXPR(rcmd!=RSM_CMD_REG,"Error CMD Type(Not vncregister)..")

        RSM_LOG_WARN("Invalid Json Format(Not vncregister)");
        goto fail;
    END_CHK_EXPR
    ////////
    char*pcmd=NULL,*pretcode=NULL,*povertime=NULL,*phearttime=NULL;

    ///
    ret=rsm_json_fill(pjson,"cmd",&pcmd,"retcode",&pretcode,"hearttime",&phearttime,"overtime",&povertime,NULL);
    CHK_EXPR(ret!=4,"Parse Json Failed..")

        iffree(pcmd);
        iffree(pretcode);
        iffree(povertime);
        iffree(phearttime);
        /*
        if(pcmd) free(pcmd);
        if(pretcode) free(pretcode);
        if(povertime) free(povertime);
        if(phearttime) free(phearttime);
        */
        RSM_LOG_WARN("Invalid Json Format(Missing Fields)");
        goto fail;
    END_CHK_EXPR


    serv->rpt_hearttime=atoi(phearttime);
    serv->rpt_overtime=atoi(povertime);

    if(pretcode[0]=='0'){
        //set flag
        serv->registered=1;
    }else{
        RSM_LOG_WARN("vncregister return Failed..");
    }

    serv->rpt_overtime=atoi(povertime);

    
    free(pcmd);
    free(pretcode);
    free(phearttime);
    free(povertime);

    cJSON_Delete(pjson);


    return 0;

fail:

    if(pjson)
        cJSON_Delete(pjson);


    return -1;
}



static int _rsm_service_report_alarmevent(rsm_service_t*serv,rsm_resource_t*ps,int lv,const char*desc)
{

    rsm_netconn_t*conn=serv->reporter;

    cJSON*pjson=NULL;
    char date_str[16];
    char level_str[4];

    if(!desc)
        desc=strdup("No Description for this event");

    RSM_LOG_DEBUG("Desc for Alarmevent :[%s]",desc);

    time_t now;
    time(&now);
    strftime(date_str,sizeof date_str,"%Y%m%d%H%M%S",localtime(&now));

    snprintf(level_str,sizeof level_str,"%d",lv);

    char*resid="<None>";
    if(ps&&ps->resid)
        resid=ps->resid;
    char index[8];
    snprintf(index,sizeof index,"0");
    if(ps&&ps->index)
        snprintf(index,sizeof index,"%d",ps->index);


#define servconf serv->rsmconf

    pjson=rsm_get_json_cmd(RSM_CMD_ALARMEVENT,"addr",serv->rsmipstr,"date",date_str,"level",level_str,
            "resid",resid,"index",index,"data",desc,NULL);
#undef servconf

    iffree((char*)desc);

    char sbuff[256];
    char rbuff[256]={0,};

    rsm_make_json_cmd(pjson,sbuff,sizeof(sbuff));
    cJSON_Delete(pjson);
    pjson=NULL;

    RSM_LOG_MSG("Send To CRSM ALARMEVENT:[%s]\n",sbuff);

    int ret=rsm_service_conn_to_crsm(serv,sbuff,strlen(sbuff),rbuff,sizeof(rbuff));
    CHK_EXPR(ret<0,"Connect to CRSM")

        RSM_LOG_WARN("Can not Connect to CRSM");
        goto fail;
    END_CHK_EXPR


    RSM_LOG_MSG("Recv From CRSM ALARMEVENT:[%s]\n",rbuff);
#if 0
    cmd_t rcmd=rsm_parse_json_cmd(rbuff,&pjson);
    CHK_EXPR(rcmd!=RSM_CMD_ALARMEVENT,"Error CMD Type(Not alarmevent)..")

        RSM_LOG_WARN("Invalid Json Format(Not alarmevent)");
        goto fail;
    END_CHK_EXPR
    ////////

    if(pretcode[0]=='0'){
        //set flag
        serv->registered=1;
    }else{
        RSM_LOG_WARN("vncregister return Failed..");
    }

    serv->rpt_overtime=atoi(povertime);

    
    free(pcmd);
    free(pretcode);
    free(phearttime);
    free(povertime);

#endif
    cJSON_Delete(pjson);


    return 0;

fail:

    if(pjson)
        cJSON_Delete(pjson);


    return -1;


}






static void*thread_report(void*data)
{
    RSM_LOG_MSG("Enter Report Thread..");


    SET_THREAD_NAME("rsm-reporter");
    
    rsm_service_t*serv=(rsm_service_t*)data;

#if 0
    serv->reporter=rsm_netconn_new(serv->rsmconf.crsm_ip,atoi(serv->rsmconf.crsm_port));
    CHK_EXPR(!serv->reporter,"Init Report Failed.")
        RSM_LOG_ERROR("Can not make NetConn for reporter.."); 
        return NULL;
    END_CHK_EXPR
#endif

    
    struct ew_repinfo*rep;

    while(1){

        RSM_LOG_MSG("REPORT To CRSM..(%d)",serv->rpt_hearttime);
        rep=(struct ew_repinfo*)calloc(1,sizeof *rep);

        if(serv->registered){
        //vncalive 
//            _rsm_service_report_alive(serv);
            rep->type=TYPE_REP_ALIVE;
        }else{
        //vncregister
//           _rsm_service_report_register(serv); 
            rep->type=TYPE_REP_REGISTER;
        }
        eventworker_emit_event(&serv->evtworker,RSM_EVT_REP,rep);
   
        sleep(serv->rpt_hearttime);
    }


    return NULL;
}


#ifdef _ENABLE_CHROME_CHECK
static int chromehb_worker(int fd,void*data)
{

    int vncport;
   
    int ret;

    rsm_service_t*serv=(rsm_service_t*)data;
    rsm_resource_pool*pool=&serv->respool;

    char buff[1024];

    ret=read(fd,buff,sizeof(buff));
    if(ret<=0)
        return CONN_CLOSE;
    
//    RSM_LOG_MSG("\n[:\033[32m\n%s\033[0m:]\n",buff);


//    int index=0; 
//    int kport=0;
    char indexstr[16];
    char kportstr[16];
    ret=sscanf(buff,"GET /?vncPort=%[^&]&vncKeyPort=%[^ ]",indexstr,kportstr);
    CHK_EXPR(ret!=2,"Parse HTTP Request Failed")
        RSM_LOG_WARN("Malformed HTTP Request from bbcvplugin<index:(%d)|keyport:(%d)>.",indexstr,kportstr);
        goto end;
    END_CHK_EXPR

    int index=atoi(indexstr);
    int kport=atoi(kportstr);
    if((index+atoi(serv->rsmconf.vncms_keyport))!=kport){
        RSM_LOG_WARN("Malformed HTTP Request from bbcvplugin<index:%d|keyport:%d>.",index,kport);
        goto end;
    }

    rsm_resource_t*res=rsm_resource_pool_get_resource_by_index(pool,index);
    CHK_EXPR(!res,"Invalid index")
        RSM_LOG_WARN("No such Resource with index %d.",index);
        goto end;
    END_CHK_EXPR

//    RSM_LOG_DEBUG("Heartbeat from chrome<idx:%d>",index);

    time_t now;
    time(&now);
    res->hb_ts=now;
//    serv->hbon=1;
//    __sync_synchronize();
end:
    return CONN_CLOSE;
}



static void*thread_monchrome(void*data)
{

    rsm_service_t*serv=(rsm_service_t*)data;
    rsm_resource_pool*pool=&serv->respool;

    RSM_LOG_MSG("Enter Chrome Monitor Thread..");
    SET_THREAD_NAME("rsm-webcmon");

    rsm_httplistener_t*listener=serv->hblistener;
    rsm_httplistener_set_worker(listener,chromehb_worker,serv);

    rsm_httplistener_listen(listener);


    return NULL;
}


static void*thread_chkchrome(void*data)
{
    RSM_LOG_MSG("Enter Chrome Check Thread..");
    SET_THREAD_NAME("rsm-webcchker");

    rsm_service_t*serv=(rsm_service_t*)data;
    rsm_resource_pool*pool=&serv->respool;

    int hbdelay=atoi(serv->rsmconf.rsm_chrome_checkdelay);
    time_t ts;
    char hbstat[2048];
    char hbdlay[1024];
    char hbdis[1024];
    char hbval[1024];

    while(1){
        sleep(hbdelay);

        int i=pool->startidx;

        time_t now;
        time(&now);
        hbstat[0]='\0';
        hbdlay[0]='\0';
        hbdis[0]='\0';
        hbval[0]='\0';

        for(;i<=pool->maxidx;i++){
            rsm_resource_t*res=pool->revindex[i];

            //RES_FREE or RES_FAIL
            if(0==(res->status&1))
                continue;
            //delay n times
            int ntry=__sync_fetch_and_sub(&res->n_hbdelay,1);
            if(ntry>0){
                rsm_snprintf_append(hbdlay,sizeof hbdlay,"%d<%d> ",i,ntry);
                continue;
            }
 
            ts=res->hb_ts;
#if 0
            //no heartbeats recvd but chrome rendered
            if(ts==0 && res->webcchk_show){

                RSM_LOG_WARN("Disable Chrome Check(idx:%d)..",res->index); 
                rsm_snprintf_append(hbdis,sizeof hbdis,"%d ",i);
                continue;
            }
#else
            //no heartbeats received during preload..
//            res->n_hbretry--;
            if(ts==0 && res->webcchk_show && res->n_hbretry--<=0 ){
//                RSM_LOG_WARN("Could not Launch Chrome<idx:%d> retry(%d)..",res->index,res->n_hbretry); 
                RSM_LOG_WARN("Disable Chrome Check(idx:%d)..",res->index); 
                rsm_snprintf_append(hbdis,sizeof hbdis,"%d ",i);
                continue;
            }

#endif
                
            rsm_snprintf_append(hbval,sizeof hbval,"%d(%d) ",i,now-ts);

            if(now-ts>(hbdelay*2)){//reduce probablity
                //restart chrome...
                RSM_LOG_WARN("Chrome<idx:%d> Heartbeats Timeout(%ds),Should Reset Chrome..",i,now-ts); 
//TODO Disable Reset chrome now
#if 0
                struct ew_vncmsinfo*info=(struct ew_vncmsinfo*)calloc(1,sizeof *info);
                info->type=TYPE_VNCMS_RESET_WEBC;
                info->res=res;
                emit_event_for_vncms(serv,info);
#endif
            }

        }

        rsm_snprintf_append(hbstat,sizeof hbstat,"\033[33m\n");
        rsm_snprintf_append(hbstat,sizeof hbstat,"PreCheck : %s\n",hbdlay);
        rsm_snprintf_append(hbstat,sizeof hbstat,"Checking : %s\n",hbval);
        rsm_snprintf_append(hbstat,sizeof hbstat,"Disabled : %s\n",hbdis);
        rsm_snprintf_append(hbstat,sizeof hbstat,"\033[0m\n");
        
        RSM_LOG_DEBUG("Chrome HeartBeats Status :%s",hbstat);
    }



    return NULL;
}



#endif

static int rsm_service_start_vncms_monitor(rsm_service_t*serv)
{

    int ret;
    RSM_LOG_MSG("Enable VNCMS Monitor Event.");
    return_val_if_fail(NULL!=serv,-1);


    eventworker_register_event(&serv->evtworker,RSM_EVT_VNCMS,ew_dispose_vncms,serv);

    return 0;
}


static void rsm_service_stop_vncms_monitor(rsm_service_t*serv)
{

    RSM_LOG_MSG("Disable VNCMS Monitor.");
    eventworker_unregister_event(&serv->evtworker,RSM_EVT_VNCMS);
}





#ifdef _ENABLE_CHROME_CHECK
static int rsm_service_start_chrome_monitor(rsm_service_t*serv)
{

    int ret;
    RSM_LOG_MSG("Enable Chrome Monitor.");
    return_val_if_fail(NULL!=serv,-1);

    serv->hblistener=rsm_httplistener_new("0.0.0.0",atoi(serv->rsmconf.rsm_chrome_checkport));
    CHK_EXPR(!serv->hblistener,"Init Chrome Heartbeat Listener Failed..")
        RSM_LOG_ERROR("Init Chrome Heartbeat Listener Failed..");
        ret=-2;
        goto fail0;
    END_CHK_EXPR



    pthread_attr_t tattr;
    pthread_attr_init(&tattr);
    pthread_attr_setdetachstate(&tattr,PTHREAD_CREATE_DETACHED);

    ret=pthread_create(&serv->webclisten_tid,&tattr,thread_monchrome,serv);
    CHK_EXPR(ret!=0,"Create Chrome Monitor Thread Failed.")
        RSM_LOG_ERROR("Create Chrome Monitor Thread Failed.");
        ret=-3;
        goto fail1;
    END_CHK_EXPR


    ret=pthread_create(&serv->webccheck_tid,&tattr,thread_chkchrome,serv);
    CHK_EXPR(ret!=0,"Create CHROME Period Check Thread Failed.")
        RSM_LOG_ERROR("Create CHROME Period Check Thread Failed.");
        ret=-4;
        goto fail2;
    END_CHK_EXPR



    return 0;

fail2:
    pthread_cancel(serv->webclisten_tid);

fail1:

    eventworker_unregister_event(&serv->evtworker,RSM_EVT_VNCMS);

    pthread_attr_destroy(&tattr);
fail0:

    return -1;

}


static void rsm_service_stop_chrome_monitor(rsm_service_t*serv)
{

    RSM_LOG_MSG("Disable Chrome Monitor.");

    pthread_cancel(serv->webclisten_tid);
    pthread_cancel(serv->webccheck_tid);
}


#endif






static int rsm_service_start_report(rsm_service_t*serv)
{

    RSM_LOG_MSG("To Start Report Thread(Register&alive).");
//    fprintf(stderr,"Serv[%p]\n",serv);
    
    int ret;

    eventworker_register_event(&serv->evtworker,RSM_EVT_REP,ew_dispose_rep,serv);

    pthread_attr_t tattr;
    pthread_attr_init(&tattr);
    pthread_attr_setdetachstate(&tattr,PTHREAD_CREATE_DETACHED);
    ret=pthread_create(&serv->notify_tid,&tattr,thread_report,serv);
    pthread_attr_destroy(&tattr);
    CHK_RUNe(ret!=0,"Create Report Thread.",
            return -2);

    return 0;
}

static void rsm_service_stop_report(rsm_service_t*serv)
{

    RSM_LOG_MSG("To Stop Report Thread(Register&alive).");

    eventworker_unregister_event(&serv->evtworker,RSM_EVT_REP);
    pthread_cancel(serv->notify_tid);

}
 


#ifdef _ENABLE_PLUGIN_CHECK

struct URLFile {
  const char *filename;
  FILE *stream;
};
 




static size_t my_fwrite(void *buffer, size_t size, size_t nmemb, void *stream)
{
  struct URLFile *out=(struct URLFile *)stream;
  if(out && !out->stream) {
    /* open file for writing */ 
    out->stream=fopen(out->filename, "wb");
    if(!out->stream)
      return -1; /* failure, can't open file to write */ 
  }
  return fwrite(buffer, size, nmemb, out->stream);
}
 



static void thr_plugin_cleanup(void*p){

//    rsm_service_t*serv=(rsm_service_t*)p;

    RSM_LOG_MSG("Plugin Thread Cancelled..");
    
    curl_global_cleanup();

}


static void*thread_plugin(void*data)
{
    RSM_LOG_MSG("Enter Plugin Thread..");


    SET_THREAD_NAME("rsm-plucheck");
    
    rsm_service_t*serv=(rsm_service_t*)data;

    
    unsigned long count=0;
    char savpath[128];
    struct ew_pluinfo*pinfo;
///////////////////////////////////////////////////////////////////////
//1.check remote plugin's timestamp,if it's newer than local's
//
//2.then down new plugin,otherwise do nothing.
///////////////////////////////////////////////////////////////////////


    const char*pluurl=(char*)serv->rsmconf.rsm_chrome_plugin_url;

    const char*savfile,*_file;
  
    _file=strrchr(pluurl,'/');
    if(NULL==_file){
        RSM_LOG_WARN("Invalid Plugin Path[%s]",pluurl);
        goto nopluginconfiged;
    }


    pthread_cleanup_push(thr_plugin_cleanup,NULL);


    //download plugin and save to below path
    snprintf(savpath,sizeof savpath,"/opt/%s",_file+1);

    //keep a copy
    serv->plu_localpath=strdup(savpath);
    serv->plu_remotepath=strdup(pluurl);

    serv->plu_name=strdup(_file+1);


    curl_global_init(CURL_GLOBAL_DEFAULT);

    while(1){

        count++;

        RSM_LOG_MSG("Plugin Check Period:%d..<cnt:%d>..",serv->plu_chkperiod,count);

//
//use Libcurl to fetch pluin
//
        CURL *curl;
        CURLcode res;
        long filetime = -1;
        double filesize = 0.0;
        struct URLFile ftpfile={savpath,NULL};

//        curl_global_init(CURL_GLOBAL_DEFAULT);
 
    //fetch header 
        curl = curl_easy_init();
        if(!curl)
            goto fail;
        
        curl_easy_setopt(curl, CURLOPT_URL, serv->plu_remotepath);
        curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);
        curl_easy_setopt(curl, CURLOPT_FILETIME, 1L);
    /* Switch on full protocol/debug output */ 
    /* curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L); */ 
 
        res = curl_easy_perform(curl);
        curl_easy_cleanup(curl);
 
        if(CURLE_OK != res) {
        
            RSM_LOG_WARN("Fetch Plugin Failed<%d>..",res);
            goto fail;
        }

        res = curl_easy_getinfo(curl, CURLINFO_FILETIME, &filetime);
        if((CURLE_OK == res) && (filetime >= 0)) {

            RSM_LOG_MSG("Plugin File:%s ,MTIME:%ld(%s)",serv->plu_name,filetime,ctime(&filetime));
        }


        RSM_LOG_MSG("Remote plugin TimeStamp:%ld ,Local plugin TimeStamp:%ld",filetime,serv->plu_ts);

        if(serv->plu_ts>=filetime){//????
            RSM_LOG_MSG("Need not to update Plugin..");
            goto skip;
        }

        //filetime>plu_ts
        serv->plu_ts=filetime;

        //////////////////////////////
        //Real fetch plugin
        //
        curl = curl_easy_init();
        if(!curl)
            goto fail;

        curl_easy_setopt(curl, CURLOPT_URL, serv->plu_remotepath);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, my_fwrite);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &ftpfile);
    /* Switch on full protocol/debug output */ 
//    curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
 
        res = curl_easy_perform(curl);
    /* always cleanup */ 
        curl_easy_cleanup(curl);
        if(CURLE_OK != res) {
            RSM_LOG_WARN("Can not download plugin[%s] and LibCURL return<%d>..",serv->plu_remotepath,res);
            goto fail;
        }
 
        if(ftpfile.stream)
            fclose(ftpfile.stream); /* close the local file */ 
 
        RSM_LOG_MSG("Download plugin at[%s] and Save as[%s]..",serv->plu_remotepath,savpath);

/////////////////////////////////////////////////
        pinfo=(struct ew_pluinfo*)malloc(sizeof *pinfo);
        pinfo->plugin_path=serv->plu_remotepath;
        pinfo->save_path=serv->plu_localpath;

        eventworker_emit_event(&serv->evtworker,RSM_EVT_PLU,pinfo);

        sleep(serv->plu_chkperiod);

        continue;

skip:
fail:
//        curl_global_cleanup();
#if 1
        if(count==1)//第一次插件获取失败，则退出RSM
        {
            RSM_LOG_ERROR("Due to Fetch Plugin Failed,To Terminate RSM..");
            eventworker_stop(&serv->evtworker);
        }
#endif
        sleep(serv->plu_chkperiod);
    }


//    curl_global_cleanup();
    pthread_cleanup_pop(0);

nopluginconfiged:
#if 1
    RSM_LOG_ERROR("Invalid 'RSM.CHROME.PLUGIN_URL' in `rsm.conf',To Terminate RSM..");
    eventworker_stop(&serv->evtworker);
#endif
    return NULL;
}


static int rsm_service_start_checkplugin(rsm_service_t*serv)
{

    int ret;
    RSM_LOG_MSG("To Start Plugin-Check Thread..");

    if(strcasecmp(serv->rsmconf.rsm_chrome_plugin_url,"None")){

        char cmd[256];
        snprintf(cmd,sizeof cmd, "rm -rf /opt/%s/*",PLUGIN_DIR);
//    ret=system(cmd);
        ret=rsm_system(serv,cmd);
        CHK_EXPRe(ret!=0,"System Call")
            RSM_LOG_WARN("Execute [%s] Failed<%d>..",cmd,ret);
        END_CHK_EXPRe

        serv->plu_default=0;
    }else{
        
        RSM_LOG_MSG("Use Default BBCVPlugin[/opt/%s],disable plugin-check",PLUGIN_DIR);
        serv->plu_default=1;
    }

   
    if(serv->plu_default)
        return 0;

//Enable plugin fetch
    serv->plu_chkperiod=atoi(serv->rsmconf.rsm_chrome_plugin_chkperiod);
    if(serv->plu_chkperiod<=0){
        RSM_LOG_WARN("Invalid Check-period using %dsec for Default",PLU_DEFAULT_PERIOD);   
        serv->plu_chkperiod=PLU_DEFAULT_PERIOD;
    }

    RSM_LOG_MSG("Plugin Check Period is %d Secs .",serv->plu_chkperiod);

    eventworker_register_event(&serv->evtworker,RSM_EVT_PLU,ew_dispose_plucheck,serv);

    pthread_attr_t tattr;
    pthread_attr_init(&tattr);
    pthread_attr_setdetachstate(&tattr,PTHREAD_CREATE_DETACHED);
    ret=pthread_create(&serv->plucheck_tid,&tattr,thread_plugin,serv);
    pthread_attr_destroy(&tattr);
    CHK_RUNe(ret!=0,"Create Plugin-Check Thread.",
            return -2);

    return 0;
}


static void rsm_service_stop_checkplugin(rsm_service_t*serv)
{

    RSM_LOG_MSG("To Stop Plugin-Check Thread..");

    eventworker_unregister_event(&serv->evtworker,RSM_EVT_PLU);
    if(serv->plu_default)
        return;
    pthread_cancel(serv->plucheck_tid);

    iffree(serv->plu_remotepath);
    iffree(serv->plu_localpath);
    iffree(serv->plu_name);
    
}


#endif


static void* thread_sighandler(void*arg)
{
    RSM_LOG_MSG("Enter SigHandle Thread..");

    SET_THREAD_NAME("rsm-sigHandler");
    
    rsm_service_t*serv=(rsm_service_t*)arg;

    int ret;
    sigset_t set;
    sigemptyset(&set);
    
    sigaddset(&set,SIGCHLD);
    sigaddset(&set,SIGTERM);

    int signo;

    while(1){
        
        ret=sigwait(&set,&signo);
        CHK_RUNe(ret!=0,"SigWait Failed",break);


        struct ew_siginfo*info=NULL;

        int status;
        int pid;
        int fl_exit;
        int fl_kill;
        switch(signo){
            
            case SIGCHLD:
                //When vncms exited..!!!! 
                while((pid=waitpid(-1,&status,WNOHANG))>0){
                    
                    info=(struct ew_siginfo*)calloc(1,sizeof *info);

                    info->pid=pid;
                    info->signo=signo;
                    RSM_LOG_MSG("Enter WaitPid(%d)..",pid);
                    fl_kill=0;
                    fl_exit=0;

                    if(WIFEXITED(status)){
                        fl_exit=WEXITSTATUS(status);
//                        fprintf(stderr,"[Exited](%d)",fl_exit);

                        if(fl_exit==EXEC_FAIL){
                            RSM_LOG_ERROR("EXEC program Failed(No such file)..");
                        }else{
                            RSM_LOG_ERROR("A Subprocess has Exited..");

                        }

                    }else if(WIFSIGNALED(status)){
                        fl_kill=WTERMSIG(status) ;
//                        fprintf(stderr,"[Signaled](%u)",fl_kill);
                        RSM_LOG_ERROR("A SubProcess has Signaled By <SIG:%d>..",fl_kill);

                    }else{
                        
                        RSM_LOG_ERROR("RSM Got SIGCHLD with other reason..");

                    }

                    info->fl_exit=fl_exit;
                    info->fl_kill=fl_kill;

                    if(pid==serv->sysid){
                        
                        RSM_LOG_MSG("rsm_system(ret:%d) Finished..",fl_exit);
                        serv->sysid=0;//no lock required;
                        pthread_cond_signal(&serv->syscond);
                        free(info);
                    }else{
                        
                        eventworker_emit_event(&serv->evtworker,RSM_EVT_SIG,info);

                    }

                }

                break;
            case SIGTERM:

                RSM_LOG_MSG("Caught SIGTERM...");
                RSM_LOG_MSG("To Terminate RSM..Wait Break Eventworker");
                eventworker_stop(&serv->evtworker);

                break;
            default:
                RSM_LOG_WARN("Other Signal Caught(signo:%d)..",signo);

                break;
        }


    }

    RSM_LOG_ERROR("RSM SigHandler Thread Exited..")

    return NULL;
}



static int rsm_service_start_sighandler(rsm_service_t*serv)
{

    RSM_LOG_MSG("To Start SigHandle Thread(sigchld&sigterm).");
    
    int ret;

    eventworker_register_event(&serv->evtworker,RSM_EVT_SIG,ew_dispose_signal,serv);

    pthread_attr_t tattr;
    pthread_attr_init(&tattr);
    pthread_attr_setdetachstate(&tattr,PTHREAD_CREATE_DETACHED);
    ret=pthread_create(&serv->sighandle_tid,&tattr,thread_sighandler,serv);
    pthread_attr_destroy(&tattr);
    CHK_RUNe(ret!=0,"Create SigHandler Thread.",
            return -2);

    return 0;
}


static void rsm_service_stop_sighandler(rsm_service_t*serv)
{

    RSM_LOG_MSG("To Stop SigHandle Thread(sigchld&sigterm).");

    eventworker_unregister_event(&serv->evtworker,RSM_EVT_SIG);
    pthread_cancel(serv->sighandle_tid);

}



#ifdef _ENABLE_HOST_STATING

static void* thread_stating(void*arg)
{
    RSM_LOG_MSG("Enter Stating Thread..");

    SET_THREAD_NAME("rsm-Stating");
    
    rsm_service_t*serv=(rsm_service_t*)arg;

    int ret;
    


    while(1){
        
        get_cpustat(&serv->cpustat);
        int val=calc_cpuoccupy(&serv->cpustat0,&serv->cpustat);
        serv->cpuoccupy=(val+50)/100;//remove trailing draction
        serv->cpustat0=serv->cpustat;

        get_memstat(&serv->memstat);
        val=calc_memoccupy(&serv->memstat);
        serv->memoccupy=val;

        get_gpustats(&serv->gpustats);

        if(!serv->in_overloaded){

            if((serv->cpuoccupy>=serv->cpulimit&&serv->cpulimit!=0)||(serv->memoccupy>=serv->memlimit&&serv->memlimit!=0)){
    
                RSM_LOG_MSG("Stating ++ CPU:%d(%d), MEM:%d(%d),GPU(num:%d)",serv->cpuoccupy,serv->cpulimit,serv->memoccupy,serv->memlimit,serv->gpustats.n);
    
    
                struct ew_repinfo*repinfo=(struct ew_repinfo*)calloc(1,sizeof*repinfo);
                repinfo->type=TYPE_REP_ALARMEVENT;
                repinfo->info.alarm.res=NULL;
                repinfo->info.alarm.level=3;
                repinfo->info.alarm.desc=strdup("host is overloaded,should not assign more tasks for it...");
                eventworker_emit_event(&serv->evtworker,RSM_EVT_REP,repinfo);
    
                RSM_LOG_DEBUG("Enter Overloaded Protected Mode.");

                serv->in_overloaded=1;
    
            }

        }else{
            

            if(serv->cpuoccupy<serv->cpulimit&&serv->memoccupy<serv->memlimit){

                RSM_LOG_MSG("Stating -- CPU:%d(%d), MEM:%d(%d),GPU(num:%d)",serv->cpuoccupy,serv->cpulimit,serv->memoccupy,serv->memlimit,serv->gpustats.n);

                struct ew_repinfo*repinfo=(struct ew_repinfo*)calloc(1,sizeof*repinfo);
                repinfo->type=TYPE_REP_ALIVE;
                eventworker_emit_event(&serv->evtworker,RSM_EVT_REP,repinfo);

                RSM_LOG_DEBUG("Enter Overloaded Protected Mode.");
                serv->in_overloaded=0;
            }

        }
        sleep(5);//5 secs sampling period
    }

    RSM_LOG_ERROR("RSM Host-Stating Thread Exited Abnormally")

    return NULL;
}





static int rsm_service_start_stating(rsm_service_t*serv)
{

    RSM_LOG_MSG("To Start Host-Stating Thread..");
//    fprintf(stderr,"Serv[%p]\n",serv);
    
    return_val_if_fail(NULL!=serv,-1);
    int ret;

//    eventworker_register_event(&serv->evtworker,RSM_EVT_STT,ew_dispose_statupdate,serv);

    pthread_attr_t tattr;
    pthread_attr_init(&tattr);
    pthread_attr_setdetachstate(&tattr,PTHREAD_CREATE_DETACHED);
    ret=pthread_create(&serv->stating_tid,&tattr,thread_stating,serv);
    pthread_attr_destroy(&tattr);
    CHK_RUNe(ret!=0,"Create Host-Stating Thread.",
            return -2);

    return 0;
}


static void rsm_service_stop_stating(rsm_service_t*serv)
{

    RSM_LOG_MSG("To Stop Host-Stating Thread.");

//    eventworker_unregister_event(&serv->evtworker,RSM_EVT_STT);
    pthread_cancel(serv->stating_tid);

}


#endif


enum _avst{

    AST_FPS_F=1<<1

};

struct _avencstat{

    char version[16];//=1.0.00.12
    int index;//=1
    char destaddr[32];//=127.0.0.1:61000
    char destaddr_local[32];//=127.0.0.1:55753
    int realbitrate;//=1371648
    int realfps;//=25                                                                                                                                                              
    int encode_bitrate;//=3072000
    int smooth_bitrate;//=18874368
    int fps;//=25
    int pmt_pid;//=2307
    int service_id;//=124
    int video_pid;//=515
    int audio_pid;//=680
    int gopsize;//=5:100
    int width;//=1280
    int height;//=720

};


static int parse_avencstat(struct _avencstat*s,int fd)
{
    int ni; 
    char info[512];
    lseek(fd,SEEK_SET,0);
    int nr=read(fd,info,sizeof info);
    CHK_EXPRe(nr<=0,"read avencoder.index fail")
        RSM_LOG_MSG("read return %d",nr);
        return -1;
    END_CHK_EXPRe
    info[nr]=0;

    char*sp,*spp;
    char*pinfo;
    char*l;

//    fprintf(stderr,"Parse Avencoder.index -BEG(%d)..\n",nr);
    for(pinfo=info;;pinfo=NULL){
        l=strtok_r(pinfo,"\n", &sp);
        if(!l)
            break;
//        fprintf(stderr,"line  [%s]\n",l);
        char*k,*v;
//        k=v="unknown";

        k=strtok_r(l,"=",&spp);
        v=strtok_r(NULL,"=",&spp);

        if(!k||!v)
            continue;

//        fprintf(stderr,"[%s]:[%s]\n",k,v);

        if(!strcmp("index",k)){
            s->index=atoi(v); 
            ni++;
        }else
        if(!strcmp("realfps",k)){
            s->realfps=atoi(v);
            ni++;
        }
        else
        if(!strcmp("realbitrate",k)){
            s->realbitrate=atoi(v); 
            ni++;
        }
        else
        if(!strcmp("encode_bitrate",k)){
            s->encode_bitrate=atoi(v); 
            ni++;
        }
        else
        if(!strcmp("smooth_bitrate",k)){
            s->smooth_bitrate=atoi(v); 
            ni++;
        }

    }
//    fprintf(stderr,"Parse Avencoder.index -END..\n");

    return ni;

}


static void* thread_streaminfo(void*arg)
{
    RSM_LOG_MSG("Enter Stream-Info Thread..");

    SET_THREAD_NAME("rsm-streaminfo");
    
    rsm_service_t*serv=(rsm_service_t*)arg;

    int ret;

    int avencfds[256];
    int avenccnt[256];
    unsigned int avencstat[256];
    memset(avencfds,0,sizeof avencfds);
    memset(avenccnt,0,sizeof avenccnt);
    memset(avencstat,0,sizeof avencstat);

    char info[512];
    char desc[128];

    int peakrate=atoi(serv->rsmconf.rsm_enc_video_rate)*1024*1024;//B to M

    while(1){

//        fprintf(stderr,"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
        rsm_resource_t*res;
        rsm_resource_pool *pool=&serv->respool;

        struct _avencstat avs;
        time_t now,modts;
        time(&now);
        char filename[32];
        int i;
        for(i=pool->startidx;i<=pool->maxidx;i++){
            int ret=0; 
            snprintf(filename,sizeof filename,"/tmp/avencoder.%d",i);

            res=pool->revindex[i];
            if(res &&
                res->status==RES_BUSY &&
                res->avstatus==AVSTATUS_ON){

                struct stat fs;
                ret=stat(filename,&fs);
                CHK_EXPRe(ret<0,"Stat avencoder.index fail")
                    RSM_LOG_ERROR("Could not Stat [%s]..",filename);
                    continue;
                END_CHK_EXPRe

                modts=fs.st_mtime;
                if(now-modts>2){
                    //TODO avencoder Stopped..

                    continue; 
                }
//                RSM_LOG_MSG("Mtime of[%s] is %zu..",filename,modts);
//                RSM_LOG_MSG("Size of[%s] is %zu..",filename,fs.st_size);
                //1.get timestamp of avencoder.idx file
                avencfds[i]=open(filename,O_RDONLY);
                if(avencfds[i]<0){
                    RSM_LOG_MSG("Can not open[%s]",filename);
                }

                //2.get information of avencoder
                ret=parse_avencstat(&avs,avencfds[i]);
                CHK_EXPRe(ret<0,"parse avencoder.index fail")
                    RSM_LOG_MSG("Parse [%s] Failed",filename);
                END_CHK_EXPRe
                close(avencfds[i]);
                
                if(avs.realfps<20){
                    if(!(avencstat[i]&AST_FPS_F)){
                        snprintf(desc,sizeof desc,"realfps(%d) of Avencoder is too low..",avs.realfps);
                        emit_alarmevent(res,3,desc);
                    }
                    avencstat[i]|=AST_FPS_F;
                }else{
                    if((avencstat[i]&AST_FPS_F)){
                        snprintf(desc,sizeof desc,"realfps(%d) of Avencoder has recovered..",avs.realfps);
                        emit_alarmevent(res,3,desc);
                    }
                    avencstat[i]&=~AST_FPS_F;
                }

                if(avs.realbitrate>=peakrate){
                    snprintf(desc,sizeof desc,"realbitrate(%d>=%d) of Avencoder has overflowed..",avs.realbitrate,peakrate);
                    emit_alarmevent(res,3,desc);
                }



            }
        }
        sleep(2);
    }
} 




static int rsm_service_start_streaminfo(rsm_service_t*serv)
{

    RSM_LOG_MSG("To Start Stream-Info Thread..");
    
    return_val_if_fail(NULL!=serv,-1);
    int ret;


    pthread_attr_t tattr;
    pthread_attr_init(&tattr);
    pthread_attr_setdetachstate(&tattr,PTHREAD_CREATE_DETACHED);
    ret=pthread_create(&serv->streami_tid,&tattr,thread_streaminfo,serv);
    pthread_attr_destroy(&tattr);
    CHK_RUNe(ret!=0,"Create Stream-Info Thread.",
            return -2);

    return 0;
}


static void rsm_service_stop_streaminfo(rsm_service_t*serv)
{

    RSM_LOG_MSG("To Stop Stream-Info Thread.");

    pthread_cancel(serv->streami_tid);

}




////////////////////////////////////////
////////////////////////////////////////


static int cmdlisten_worker(int fd,void*data)
{
    RSM_LOG_MSG("Start New CRSM worker..");
    int ret;

    char ipbuff[40];

    rsm_get_peername_by_sock(fd,ipbuff,sizeof(ipbuff));
    RSM_LOG_MSG("New Command From Address:[%s]:",ipbuff);

    rsm_service_t*serv=(rsm_service_t*)data;
#if 0
//#ifndef _DEBUG
    //If Current RSM not registered to CRSM, Refuse all cmds..
    if(!serv->registered){
        
        RSM_LOG_WARN("Current RSM has not register to CRSM yet!!!..");

        write_null_msg(fd);
        return CONN_CLOSE;
    }
#endif


    struct ew_cmdinfo*cmd=(struct ew_cmdinfo*)malloc(sizeof *cmd);
    cmd->fd=fd;

    eventworker_emit_event(&serv->evtworker,RSM_EVT_CMD,cmd);
    RSM_LOG_DEBUG("Event Emited..");

//    usleep(10000);

	return CONN_KEEP;

}





static int rsmhttp_worker(int fd,void*data)
{

    int vncport;
   
    int ret;

    rsm_service_t*serv=(rsm_service_t*)data;

    char buff[8192];

    ret=read(fd,buff,sizeof(buff));

    char*delim=strstr(buff,"XXEE");
    if(!delim){
        RSM_LOG_WARN("Bad Request Format!!");

        return CONN_CLOSE;
    }


    *delim='\0';
//Method    'GET' 
    char* args=strstr(buff,"/");

    char callback[128];
    bzero(callback,sizeof(callback));

    ret=sscanf(args,"/%d?callback=%128s",&vncport,callback);
    CHK_RUN(ret<0,"Parse vncport & callback..",return CONN_FAIL);
	//Carefully
//	int index=vncport;
    int index=vncport-atoi(serv->rsmconf.vncms_listenport);
//    RSM_LOG_DEBUG("------------------Vncport:(%d),callback:(%s),Index:(%d)",vncport,callback,index);
    rsm_resource_t*ps=NULL;

    if(rsm_resource_pool_check_index(&serv->respool,index,&ps)){
       //////////////////////

        int returncode=0;
        char*web_url=ps->url;

        static char body[8192];
        static char buffer[8192];

        snprintf(body,sizeof(body),"%s({\"returncode\":\"%d\",\"vncport\":\"%d\",\"url\":\"%s\"})\r\n",callback,returncode,vncport,web_url);


        int len=snprintf(buffer,sizeof(buffer),"HTTP/1.0 200 OK\r\nContent-Type: text/javascript\r\ncontent-length: %d\r\n\r\n%s\r\n",(int)strlen(body),body);
        
        RSM_LOG_DEBUG("Write To Client<VNCMS:%d>:size(%d)\n\033[32m%s\033[0m\n",index,strlen(buffer),buffer);

        write(fd,buffer,len);
    
    }


    return CONN_CLOSE;
}



static int do_exist(rsm_service_t*serv,cJSON*proot,cJSON**pretjson)
{

    RSM_LOG_MSG("Process Exist Event..");
   
    cJSON*retjson;
    rsm_conf_t*conf=&serv->rsmconf;


    retjson=rsm_get_json_cmd(RSM_CMD_EXIST,"retcode","0",NULL);

    if(pretjson)
        *pretjson=retjson;
    else
        cJSON_Delete(retjson);


    return 0;

}

static int do_login(rsm_service_t*serv,cJSON*proot,cJSON**pretjson)
{

    RSM_LOG_MSG("Process Login Event..");
   
    cJSON*retjson;
    rsm_conf_t*conf=&serv->rsmconf;

    rsm_resource_t*ps;
    
    ps=rsm_resource_pool_login(&serv->respool,proot,&retjson);


    if(pretjson)
        *pretjson=retjson;
    else
        cJSON_Delete(retjson);

    return 0;
}


static int do_logout(rsm_service_t*serv,cJSON*proot,cJSON**pretjson)
{
    
    int ret;
    RSM_LOG_MSG("Process Logout Event..");

	cJSON*retjson;

    rsm_resource_t*ps;
    ps=rsm_resource_pool_logout(&serv->respool,proot,&retjson);
    CHK_RUN(!ps,"Can Not Locate Resource.",);
    
    if(pretjson)
        *pretjson=retjson;
    else
        cJSON_Delete(retjson);
//    char retbuff[256];


	return 0;
}

static int do_pause(rsm_service_t*serv,cJSON*proot,cJSON**pretjson)
{
    
    int ret;
    RSM_LOG_MSG("Process Pause Event..");

	cJSON*retjson;

    rsm_resource_t*ps;
    ps=rsm_resource_pool_pause(&serv->respool,proot,&retjson);
    CHK_RUN(!ps,"Can Not Pause Resource.",);

    if(pretjson)
        *pretjson=retjson;
    else
        cJSON_Delete(retjson);


	return 0;

}


static int do_sync(rsm_service_t*serv,cJSON*proot,cJSON**pretjson)
{
    
    int ret;
    RSM_LOG_MSG("Process Sync Event..");

	cJSON*retjson;

    int num;
    num=rsm_resource_pool_sync(&serv->respool,proot,&retjson);
    CHK_EXPR(num<0,"Can Not Statistic RSM Resources.")
        ////
    END_CHK_EXPR

    if(pretjson)
        *pretjson=retjson;
    else
        cJSON_Delete(retjson);

    RSM_LOG_MSG("RESPOOL: No of INUSE(%d)",num);


	return 0;

}



static int do_getserverinfo(rsm_service_t*serv,cJSON*proot,cJSON**pretjson)
{
 
    int ret;
    RSM_LOG_MSG("Process GetServerinfo Event..");

	cJSON*retjson;

    ret=rsm_resource_pool_getserverinfo(&serv->respool,proot,&retjson);
    CHK_EXPR(ret<0,"Can Not Get ServerInfo.")
        ////
    END_CHK_EXPR

    if(pretjson)
        *pretjson=retjson;
    else
        cJSON_Delete(retjson);

    return 0;

}

static int do_getreslist(rsm_service_t*serv,cJSON*proot,cJSON**pretjson)
{
 
    int ret;
    int num;
    RSM_LOG_MSG("Process GetReslist Event..");

	cJSON*retjson;

    retjson=rsm_resource_pool_get_reslists(&serv->respool,&num);
    CHK_EXPR(retjson==NULL,"Can Not Get Reslists.")
        ////
    END_CHK_EXPR

    if(pretjson)
        *pretjson=retjson;
    else
        cJSON_Delete(retjson);

    return 0;
}




void rsm_service_start(rsm_service_t*serv)
{

    return_if_fail(serv!=NULL);

    RSM_LOG_MSG("Start RSM Service");
    int ret;


   
    sigset_t set,oset;
    sigfillset(&set);
    ret=pthread_sigmask(SIG_BLOCK,&set,&oset);
    CHK_RUNe(ret!=0,"SigMask Failed..",
            return);


    rsm_service_start_sighandler(serv);//信号处理
    rsm_service_start_dispatch(serv);//命令处理
    rsm_service_start_httpserver(serv);//用于chrome预启动
    rsm_service_start_report(serv);//周期性


#ifdef _ENABLE_HOST_STATING
    rsm_service_start_stating(serv);//获取承载资源使用率
    rsm_service_start_streaminfo(serv);
#endif
#ifdef _ENABLE_PLUGIN_CHECK
    rsm_service_start_checkplugin(serv);//chrome插件检查
#endif

    rsm_service_start_vncms_monitor(serv);//处理vncms notify报文
#ifdef _ENABLE_CHROME_CHECK    
    rsm_service_start_chrome_monitor(serv);
#endif
    //block here
    eventworker_start(&serv->evtworker);
    RSM_LOG_ERROR("RSM EventWorker Stopped...");


#ifdef _ENABLE_CHROME_CHECK    
    rsm_service_stop_chrome_monitor(serv);
#endif
    rsm_service_stop_vncms_monitor(serv);

#ifdef _ENABLE_PLUGIN_CHECK
    rsm_service_stop_checkplugin(serv);
#endif
#ifdef _ENABLE_HOST_STATING
    rsm_service_stop_streaminfo(serv);
    rsm_service_stop_stating(serv);
#endif


    rsm_service_stop_report(serv);
    rsm_service_stop_httpserver(serv);
    rsm_service_stop_dispatch(serv);
    rsm_service_stop_sighandler(serv);



    ret=pthread_sigmask(SIG_SETMASK,&oset,NULL);


}







void rsm_print_conf(rsm_conf_t*conf)
{
#define PRBUFFSIZ (8*1024)

#define PR_CONF_ITEM(field) \
    rsm_snprintf_append(obuff,PRBUFFSIZ,"\t\t" #field "\t\t\t[ %s ]  \n",field);


    char*obuff=calloc(1,PRBUFFSIZ);

    sprintf(obuff,"\n\t>>>>RSM Configuration<<<<\n");


    PR_CONF_ITEM(conf->rsmipstr);

    PR_CONF_ITEM(conf->rsm_area_id);// = 0571
    PR_CONF_ITEM(conf->rsm_ctype);// = portal
    PR_CONF_ITEM(conf->rsm_vendor);// = nvidia

    PR_CONF_ITEM(conf->rsm_net_iface);// = eth0
    PR_CONF_ITEM(conf->rsm_listen_port);// = 25000

    PR_CONF_ITEM(conf->crsm_ip);// = 192.168.188.188
    PR_CONF_ITEM(conf->crsm_port);// = 15117

    PR_CONF_ITEM(conf->vncms_serverport);// = 5900
    PR_CONF_ITEM(conf->vncms_keyport);// = 62000
//    PR_CONF_ITEM(conf->vncms_listenport);// = 63000
//    PR_CONF_ITEM(conf->rsm_vncms_listenport);//=61000
    PR_CONF_ITEM(conf->vncms_keytimeout);// 

    PR_CONF_ITEM(conf->vncms_enable_vgl);
    PR_CONF_ITEM(conf->rsm_chrome_type);

#ifdef _ENABLE_PLUGIN_CHECK
    PR_CONF_ITEM(conf->rsm_chrome_plugin_url);
    PR_CONF_ITEM(conf->rsm_chrome_plugin_chkperiod);
#endif

    PR_CONF_ITEM(conf->rsm_vid_type);// = hd
    PR_CONF_ITEM(conf->rsm_vid_width);// = 1280
    PR_CONF_ITEM(conf->rsm_vid_height);// = 720

    PR_CONF_ITEM(conf->rsm_vid_num);// = 80
    PR_CONF_ITEM(conf->rsm_vid_pa_num);// = 8
    PR_CONF_ITEM(conf->rsm_vid_pa_prefix);// = x

#ifdef _ENABLE_HOST_STATING
    PR_CONF_ITEM(conf->rsm_limit_cpu);  
    PR_CONF_ITEM(conf->rsm_limit_mem);  
    PR_CONF_ITEM(conf->rsm_limit_gpumem);  
#endif

    PR_CONF_ITEM(conf->rsm_pre_url);// = file:///opt/init.html
    PR_CONF_ITEM(conf->rsm_pre_amount);// = 8 
    PR_CONF_ITEM(conf->rsm_pre_httpport);  
       
    PR_CONF_ITEM(conf->rsm_enc_audio);// = 1
    PR_CONF_ITEM(conf->rsm_enc_path);// = /usr/local/bin/avencoder
    PR_CONF_ITEM(conf->rsm_enc_audiopath);// = audiorecoder
    
    PR_CONF_ITEM(conf->rsm_enc_gop);// = 5:100
    PR_CONF_ITEM(conf->rsm_enc_video_rate);// = 3000
    PR_CONF_ITEM(conf->rsm_enc_video_peakrate);// = 3000
    PR_CONF_ITEM(conf->rsm_enc_gpu_amount);// = 4
    PR_CONF_ITEM(conf->rsm_enc_service_id);// = 124
    PR_CONF_ITEM(conf->rsm_enc_pmt_pid);// = 2307
    PR_CONF_ITEM(conf->rsm_enc_pmt_vid);// = 515
    PR_CONF_ITEM(conf->rsm_enc_pmt_aid);// = 680
    
   
    PR_CONF_ITEM(conf->rsm_log_path);// = log/rsm.log
    PR_CONF_ITEM(conf->rsm_log_level);// = 1
    PR_CONF_ITEM(conf->rsm_log_size);// =
    
    RSM_LOG_INFO("%s\n",obuff);
    //    fprintf(stderr,"%s",obuff);
    
    free(obuff);
    
}



int rsm_service_is_overload(rsm_service_t*serv)
{
    

    RSM_LOG_DEBUG("Utilization:: CPU:%d(%d), MEM:%d(%d),GPUMEM:(%d)\n",
            serv->cpuoccupy,serv->cpulimit,
            serv->memoccupy,serv->memlimit,
            serv->gpumemlimit
            );

    if(serv->cpuoccupy>=serv->cpulimit && serv->cpulimit!=0)
        return 1;

    if(serv->memoccupy>=serv->memlimit && serv->memlimit!=0)
        return 2;

//    if(serv->gpumemoccupy>=serv->gpumemlimit && serv->gpumemlimit!=0)
//        return 3;


    return 0;
}


int rsm_service_get_host_utilization(rsm_service_t*serv,int*cpu,int*mem){
    

    if(cpu)
        *cpu=serv->cpuoccupy;
    if(mem)
        *mem=serv->memoccupy;

    if(serv->cpuoccupy>=serv->cpulimit && serv->cpulimit!=0)
        return 1;

    if(serv->memoccupy>=serv->memlimit && serv->memlimit!=0)
        return 2;

//    if(serv->gpumemoccupy>=serv->gpumemlimit && serv->gpumemlimit!=0)
//        return 3;


    return 0;
}




const char*rsm_service_get_addr(rsm_service_t*serv)
{
    return serv->rsmipstr;
}

const char*rsm_service_get_pluginversion(rsm_service_t*serv)
{

    static char version[32];
    char*pversion;
    cJSON*pjson=NULL;

    char manifest[128];
    

    snprintf(manifest,sizeof manifest,"/opt/%s/manifest.json",PLUGIN_DIR);

    cJSON*json=rsm_parse_json_file(manifest);
    if(!json){
        RSM_LOG_WARN("Could not parse manifest.json");
    }else{
        pjson=cJSON_GetObjectItem(json,"version");
    }
    

    if(pjson)
        pversion=pjson->valuestring;
    else
        pversion="0.0.0";

    strlcpy(version,pversion,sizeof version);

    if(json)
        cJSON_Delete(json);
    
        
    RSM_LOG_WARN("Plugin Version [%s]",version);

    return version;
}

/*
int register_event_for_vncms(rsm_service_t*serv){
    return eventworker_register_event(&serv->evtworker,RSM_EVT_VNCMS,ew_dispose_vncms,serv);
}
*/

int emit_event_for_vncms(rsm_service_t*serv,void*data){
    return eventworker_emit_event(&serv->evtworker,RSM_EVT_VNCMS,data);
}

int emit_alarmevent(rsm_resource_t*res,int level,const char*desc){
   
    struct ew_repinfo*p=(struct ew_repinfo*)calloc(1,sizeof*p);
    p->type=TYPE_REP_ALARMEVENT;
    p->info.alarm.res=res;
    p->info.alarm.level=level;
    p->info.alarm.desc=strdup(desc);

    return eventworker_emit_event(&res->rserv->evtworker,RSM_EVT_REP,p);

}


