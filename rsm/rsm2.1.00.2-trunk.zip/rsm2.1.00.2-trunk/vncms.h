#ifndef _H_VNCMS_
#define _H_VNCMS_

#include"rsm_log.h"


#define VNCMS_VERSION "2.2"
#define MODULE "VNCMS"

extern rsm_log_t* global_vncmslog;


#ifdef VNCMS_LOG_DEBUG
#undef VNCMS_LOG_DEBUG
#endif
#define VNCMS_LOG_DEBUG(id,fmt,args...)\
        rsm_log(global_vncmslog,LOG_LEVEL_DEBUG,MODULE,"VNCMS(idx:%d):"fmt,id,##args);


#ifdef VNCMS_LOG_INFO
#undef VNCMS_LOG_INFO
#endif
#define VNCMS_LOG_INFO(id,fmt,args...)\
        rsm_log(global_vncmslog,LOG_LEVEL_INFO,MODULE,"VNCMS(idx:%d):"fmt,id,##args);


#ifdef VNCMS_LOG_MSG
#undef VNCMS_LOG_MSG
#endif
#define VNCMS_LOG_MSG(id,fmt,args...)\
        rsm_log(global_vncmslog,LOG_LEVEL_MSG,MODULE,"VNCMS(idx:%d):"fmt,id,##args);


#ifdef VNCMS_LOG_WARN
#undef VNCMS_LOG_WARN
#endif
#define VNCMS_LOG_WARN(id,fmt,args...)\
        rsm_log(global_vncmslog,LOG_LEVEL_WARN,MODULE,"VNCMS(idx:%d):"fmt,id,##args);


#ifdef VNCMS_LOG_ERROR
#undef VNCMS_LOG_ERROR
#endif
#define VNCMS_LOG_ERROR(id,fmt,args...)\
        rsm_log(global_vncmslog,LOG_LEVEL_ERROR,MODULE,"VNCMS(idx:%d):"fmt,id,##args);



#ifndef SET_THREAD_NAME
#define SET_THREAD_NAME(name) \
    pthread_setname_np(pthread_self(),name)

#endif


#endif
