
#ifndef _H_CHECK_CALL_
#define _H_CHECK_CALL_

#ifdef _ENABLE_LOG_

#endif

#include"colors.h"
#include<stdio.h>
#include<string.h>
#include<errno.h>
#include"defs.h"


#define OUTPUT_FMT0  "!! "  "Check::((" _FG_CYAN _BOLD"%s"_RESET "))<< "_FG_BROWN "%s"_RESET ":\n"

#define OUTPUT_FMT1  "!! "  "Check::((" _FG_CYAN _BOLD"%s"_RESET "))<< "_FG_BROWN "%s"_RESET ":{"_FG_RED _BOLD"%s" _RESET "}\n"

#define OUTPUT_FMT11  "!! "  "Check::(" _FG_MAGENTA _BOLD"%s"_RESET ")<< "_FG_BROWN "%s"_RESET ":{"_FG_RED _BOLD"%s" _RESET "}\n"
//#define OUTPUT_FMT2  "Nooo!! "  "((" _FG_CYAN _UNDER_SCORE _BOLD"%s"_RESET "))<< "_FG_BROWN "%s"_RESET ":{"_FG_RED _BOLD"%s" _RESET "}\n"

#define OUTPUT_FMT2  "!!! "  "Assert::((" _FG_RED _BOLD"%s"_RESET "))<< ""\n"
#define OUTPUT_FMT3  "!!! "  "Reach::((" _FG_RED _BOLD"%s"_RESET "))<< ""\n"


#define CHK_EXPRe(expr,msg) if UNLIKELY(expr){\
    fprintf(stderr,OUTPUT_FMT1,#expr ,msg,strerror(errno));\

#define END_CHK_EXPRe }

#define CHK_EXPRt(ret,msg) if UNLIKELY(ret!=0){\
    fprintf(stderr,OUTPUT_FMT11,#ret ,msg,strerror(ret));\

#define END_CHK_EXPRt }


#define CHK_EXPR(expr,msg) if UNLIKELY(expr){\
    fprintf(stderr,OUTPUT_FMT0,#expr ,msg);\

#define END_CHK_EXPR }


#define CHK_EXPR_ONLY(expr,msg) if UNLIKELY(expr) fprintf(stderr,OUTPUT_FMT0,#expr ,msg);

#define CHK_EXPRe_ONLY(expr,msg) if UNLIKELY(expr) fprintf(stderr,OUTPUT_FMT1,#expr ,msg,strerror(errno));


#define CHK_RUNe(expr,msg,stmt) if UNLIKELY(expr){\
    fprintf(stderr,OUTPUT_FMT1,#expr ,msg,strerror(errno));\
    stmt;}

#define CHK_RUNt(ret,msg,stmt) if UNLIKELY(ret!=0){\
    fprintf(stderr,OUTPUT_FMT11,#ret,msg,strerror(ret));\
    stmt;}

#define CHK_RUN(expr,msg,stmt) if UNLIKELY(expr){\
    fprintf(stderr,OUTPUT_FMT0,#expr ,msg);\
    stmt;}



#define CHK_EXIT(expr,msg) CHK_RUN(expr,msg,exit(-1))

//#define CHK_EXITe(expr,msg) CHK_RUNe(expr,msg,exit(-2))



#define CHK_ABORT(expr,msg) CHK_RUN(expr,msg,abort())

//#define CHK_ABORTe(expr,msg) CHK_RUNe(expr,msg,abort())






#define return_if_fail(expr) \
    do{\
        if LIKELY(expr){}else{\
            fprintf(stderr,OUTPUT_FMT2,#expr );\
            return;\
        }}while(0)


#define return_val_if_fail(expr,val) \
    do{\
        if LIKELY(expr){}else{\
            fprintf(stderr,OUTPUT_FMT2,#expr );\
            return(val);\
    }}while(0)




#define return_if_reached() \
    ({ fprintf(stderr,_BOLD "Reached::"_FG_RED "File %s: Line %d "_RESET" Should not be here!\n",__FILE__,__LINE__ );\
            return;\
        })


#define return_val_if_reached(val) \
    ({ fprintf(stderr,_BOLD "Reached::"_FG_RED "File %s: Line %d "_RESET" Should not be here!\n",__FILE__,__LINE__ );\
            return(val);\
        })











#endif
