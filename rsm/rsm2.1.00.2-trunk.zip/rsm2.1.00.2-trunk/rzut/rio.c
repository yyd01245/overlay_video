#include"rio.h"
#include<errno.h>


ssize_t readn(int fd,void*buff,size_t n)
{

    size_t nleft=n;
    size_t nr;

    char*pb=buff;

    while(nleft>0){
        
        if((nr=read(fd,pb,nleft))<0){

            if(errno == EINTR)/*Interrupted by signal*/
                nr=0; /* Should call read() again*/
            else
                return -1;

        }else if (0==nr){
            break;  /*EOF*/
        }

        nleft-=nr;
        pb+=nr;

    }
    
    return (n-nleft);

}




ssize_t writen(int fd,void*buff,size_t n)
{

    size_t nleft=n;
    ssize_t nw;
    char*pb=buff;

    while(nleft>0){

        if((nw=write(fd,pb,nleft))<=0){
            
            if(errno == EINTR)
                nw=0;
            else
                return -1;

        }
        
        nleft-=nw;
        pb+=nw;

    }

    return n;

}


/*
 *
 * read a line from fd into buff,return line's length(include '\n',if exists).
 *
 * */

ssize_t readln(int fd,void*buff,size_t bsiz)
{
    

    int n, rc;
    char *pb=buff;
    char c;

    for(n=1;n<bsiz;n++){

        if((rc=readn(fd,&c,1)) == 1){
            *pb++=c;
            if(c == '\n'){
                break;
            }

        }else if (rc==0){
            if(n==1)
                return 0;/* EOF ,no data read*/
            else
                break;/* EOF, some data was read*/

        }else
            return -1;

    }

    *pb=0;

    if(n==bsiz)/*buffer smaller than current line*/
        n--;


    return n;

}


















