#ifndef _H_DEFS_
#define _H_DEFS_



#ifndef FALSE
#define FALSE 0
#define TRUE (!FALSE)
#endif


#define MAX(a, b)  (((a) > (b)) ? (a) : (b))

#define MIN(a, b)  (((a) < (b)) ? (a) : (b))

#define ABS(a)     (((a) < 0) ? -(a) : (a))



#define CLAMP(x, low, high)  (((x) > (high)) ? (high) : (((x) < (low)) ? (low) : (x)))

/* Count the number of elements in an array. The array must be defined
 * as such; using this with a dynamically allocated array will give
 * incorrect results.
 **/
#define N_ELEMENTS(arr)       (sizeof (arr) / sizeof ((arr)[0]))




#define LIKELY(expr) \
        (__builtin_expect((expr)?1:0,1))


#define UNLIKELY(expr) \
        (__builtin_expect((expr)?1:0,0))









#endif
