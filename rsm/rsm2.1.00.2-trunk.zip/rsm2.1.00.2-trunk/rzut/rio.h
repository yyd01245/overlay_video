#ifndef _H_RIO_

#define _H_RIO_


#include<unistd.h>




ssize_t readn(int fd,void*buff,size_t n);
ssize_t writen(int fd,void*buff,size_t n);

ssize_t readln(int fd,void*buff,size_t n);




#endif
