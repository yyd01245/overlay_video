
#ifndef _H_LOGGING_
#define _H_LOGGING_

#include<sys/types.h>
#include<stdarg.h>
#include<stdio.h>

enum _logging_level{

    LOGGING_LEVEL_DEFAULT=0,
    LOGGING_LEVEL_DEBUG,
    LOGGING_LEVEL_INFO,
    LOGGING_LEVEL_MESSAGE,
    LOGGING_LEVEL_WARN,
    LOGGING_LEVEL_CRITICAL,
    LOGGING_LEVEL_ERROR,
    LOGGING_LEVEL_FATEL,
    N_LOGGING_LEVEL

};

typedef enum _logging_level logging_level;



struct _logging_struct{

    const char* log_file;
    FILE*log_fp;
    int log_stderr;
    logging_level log_level;
    size_t log_maxsize;

    char*tmp_output;

};

typedef struct _logging_struct logging_t;



void logging_set_stderr(logging_t*plog,int y);



int logging_init(logging_t*);

void logging_fini(logging_t*);




void logging_log(logging_t*,logging_level,const char*modname,const char*fmt,...);

void logging_logv(logging_t*,logging_level,const char*modname,const char*fmt,va_list ap);


















#endif
