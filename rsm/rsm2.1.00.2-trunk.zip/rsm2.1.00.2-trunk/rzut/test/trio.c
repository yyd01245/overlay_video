#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

#include"rio.h"
#include"concolor.h"
#include"chkcall.h"


int main(int argc,char**argv)
{



    const char*fname="ttt";
    if(argc>1)
        fname=argv[1];
    


    int val=-1;
//    CHK_n_EXITe(val<0,"OKOKOKO");

    /*
    IF_EXPR(val<0,"hello")

        printf("-=-=\n");
        return -1;

    END_IF_EXPR;

*/



    char buff[128];

    int lno=-1;

//    IF_RUN(lno!=0,"line No.. Corrupted.",return 100)


    IF_ABORT(lno!=0,"Abbortt");


    int fd=open(fname,O_RDONLY);

    int nr;
    
    while((nr=readln(fd,buff,8))>0)
    {
        
        printf("[%d]:%d:|%s|\n",++lno,nr,buff);
//        if(nr==0)
//            break;

    }

    printf("%s\n",COL_INFO("hello,info"));
    printf("%s\n",COL_ERROR("hello,ERROR"));
    printf("%s\n",COL_WARN("hello,Warnning"));
    printf("%s\n",COL_REVERSE("REVERSE"));

    fprintf(stderr,"==========================\n");

    lseek(fd,0,SEEK_SET);
 
    lno=0;
    while((nr=readn(fd,buff,4))>0)
    {
        printf("[%d]:%d:|%s|\n",++lno,nr,buff);
//        if(nr==0)
//            break;
    }






    return EXIT_SUCCESS;
}
