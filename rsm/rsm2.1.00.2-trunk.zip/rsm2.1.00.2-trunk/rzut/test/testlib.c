#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"sysutils.h"




int main(int argc,char**argv)
{


    char buff[1024];
    bzero(buff,sizeof buff);

    memcpy(buff,argv[1],strlen(argv[1]+1));

    char*dst=buff;
    char*part=argv[2];
    char*subt=argv[3];



    printf("[%s]\n",dst);
    printf("[%s]\n",part);
    printf("[%s]\n",subt);


    strrepl(dst,part,subt);


    printf("=%s=\n",dst);



    return EXIT_SUCCESS;
}
