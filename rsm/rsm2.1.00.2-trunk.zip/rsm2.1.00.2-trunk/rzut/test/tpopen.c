#include<stdio.h>
#include<stdlib.h>
#include"sysutils.h"
#include<string.h>



#define LEN 100


int main()
{

    char buff[LEN];

    popen_out("ls ","r",buff,LEN);

//    printf("[Size:%d]\n",strlen(buff));
//    printf("=============\n");
    printf("%s",buff);
//    printf("-------------\n");


    return 0;
}

