#include<stdio.h>
#include<stdlib.h>
#include"sysutil.h"



int main()
{



    struct timespec ts,ots;
    ts.tv_sec=10;
    ts.tv_nsec=0;


    while(1){

    
        absleep(&ts);


        printf("-------\n");

    }




    return EXIT_SUCCESS;
}
