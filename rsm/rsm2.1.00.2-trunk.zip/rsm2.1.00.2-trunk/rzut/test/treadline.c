#include<stdio.h>
#include<stdlib.h>
#include<readline/readline.h>
#include"concolor.h"



int main(int argc,char**argv)
{


    char*line;


    while(line=readline(">>>")){

        printf(COL_INFO("[%s]\n"),line);

    }


    return EXIT_SUCCESS;
}
