
#include"logging.h"
#include"chks.h"
#include"colors.h"
#include"sysutils.h"
#include<stdlib.h>
#include<string.h>
#include<time.h>


#define LOG_MAXSIZE 1024000
#define MAX_LINE_SIZ 1024


#ifdef _SINGLETON_

static logging_t the_log;

#define _get_log() (&the_log)

#endif


//#define _get_current_module() __FILE__



#define LOG_TIME_FMT "%Y-%m-%d %H:%M:%S"
#define LOG_FILE_FMT "-%Y%m%d-%H%M.log"
#define LOG_FILE_FMT_LEN 20

#define LOG_PREFIX_FMT  _FG_MAGENTA "<TIMESTAMP> "_BOLD _FG_CYAN"[<MODULE>]"_RESET"::"_FG_GREEN"<LEVEL>"_RESET

static const char*log_prefix_fmt=LOG_PREFIX_FMT;


const char*level2str[N_LOGGING_LEVEL]={

    [LOGGING_LEVEL_DEFAULT]="<DEFAULT>",
    [LOGGING_LEVEL_DEBUG]="[DEBUG]",
    [LOGGING_LEVEL_MESSAGE]="[MESSAGE]",
    [LOGGING_LEVEL_INFO]="[INFO]",
    [LOGGING_LEVEL_WARN]="[WARN]",
    [LOGGING_LEVEL_ERROR]="[ERROR]",
    [LOGGING_LEVEL_FATEL]="[FATEL]"

};


static char* _gen_log_file_name(const char*file_prefix)
{

    time_t now;
    struct tm nowtm;

    time(&now);
    localtime_r(&now,&nowtm);

    int fnamelen=LOG_FILE_FMT_LEN+strlen(file_prefix);
    char*pname=calloc(fnamelen,sizeof(char));

    strlcpy(pname,file_prefix,fnamelen);

    strftime(pname+strlen(file_prefix),fnamelen,LOG_FILE_FMT,&nowtm);

    return pname;
}




int logging_init(logging_t*logg)
//logging_t*logging_init(char*logfile)
{

    bzero(logg,sizeof(logging_t));

    logg->log_level=LOGGING_LEVEL_DEFAULT;
    logg->log_maxsize=LOG_MAXSIZE;

    logg->tmp_output=calloc(MAX_LINE_SIZ,sizeof(char));

    
    if(logg->log_file)
        logg->log_fp=fopen(plog->log_file,"w+");

    plog->log_stderr=1;


    return plog;
}


#ifdef _SINGLETON_

logging_t*logging_get_log()
{
    

    if(the_log){
        fprintf(stderr,"Get Log..\n");
        return the_log;
    }

    the_log=logging_init(NULL);

}

#endif




void logging_set_stderr(logging_t*plog,int y)
{

    if(!plog)
        return;

    plog->log_stderr=y;

}







void logging_fini(logging_t*plog)
{
    if(!plog)
        return;

    free((void*)plog->log_file);
    if(plog->log_file)
        fclose(plog->log_fp);
    free(plog->tmp_output);

    free(plog);

}




/*
static int strrepl(char*pstr,const char*pat,const char*rep)
{
    int nmatch=0;
    char*pl;

    int p_len=strlen(pstr);
    int pat_len=strlen(pat);
    int rep_len=strlen(rep);

    int mlen;
    char*ppat,*prep;

    while(pl=strstr(pstr,pat)){
        if(!pl)
            break;
        nmatch++;

        ppat=pl+pat_len;
        prep=pl+rep_len;

        mlen=p_len-(ppat-pstr);

        memmove(prep,ppat,mlen+1);
        memmove(pl,rep,rep_len);
    }

    return nmatch;
}


*/


void logging_logv(logging_t*plog,logging_level level,const char*modname,const char*fmt,va_list ap)
{

    char*modnam=strdup(modname);
    strupper(modnam);
    char*p=strrchr(modnam,'.');
    if(p)
        *p=0;


    if(level<=plog->log_level)
        return;

    int ret;

    FILE*fp=plog->log_fp;

    strlcpy(plog->tmp_output,log_prefix_fmt,MAX_LINE_SIZ);
    time_t now;
    time(&now);
    struct tm tmnow;
    localtime_r(&now,&tmnow);

    char timebuff[64];

    ret=strftime(timebuff,256,LOG_TIME_FMT,&tmnow);
//     printf("[%s]\n",timebuff); 
    strrepl(plog->tmp_output,"<TIMESTAMP>",timebuff);
    strrepl(plog->tmp_output,"<MODULE>",modnam);
    strrepl(plog->tmp_output,"<LEVEL>",level2str[level]);


    free(modnam);

    if(plog->log_file){

        fprintf(plog->log_fp,"%s :>>\t",plog->tmp_output);
        vfprintf(plog->log_fp,fmt,ap);
    }

    if(plog->log_stderr){
        fprintf(stderr,"%s :>>\t",plog->tmp_output);
        vfprintf(stderr,fmt,ap);
    }

}





void logging_log(logging_t*plog, logging_level level,const char*modname,const char*fmt,...)
{
    CHK_EXPR_ONLY(!plog,"Illegal Parameter..");

    va_list ap;

    va_start(ap,fmt);

    logging_logv(plog,level,modname,fmt,ap);

    va_end(ap);

}


#if 0
#define LOGGING_LOG_INFO(fmt,args...)\
    logging_log(_get_log(),LOGGING_LEVEL_INFO,_get_current_module(),fmt,args)

#define LOGGING_LOG_MESSAGE(fmt,args...)\
    logging_log(_get_log(),LOGGING_LEVEL_MESSAGE,_get_current_module(),fmt,args)


#define LOGGING_LOG_DEBUG(fmt,args...)\
    logging_log(_get_log(),LOGGING_LEVEL_DEBUG,_get_current_module(),fmt,args)


#define LOGGING_LOG_WARN(fmt,args...)\
    logging_log(_get_log(),LOGGING_LEVEL_WARN,_get_current_module(),fmt,args)


#define LOGGING_LOG_ERROR(fmt,args...)\
    logging_log(_get_log(),LOGGING_LEVEL_ERROR,_get_current_module(),fmt,##args)



#endif


#if 0


int main(int argc,char**argv)
{
    
    logging_t*plog=logging_init("llog");

//    printf("%s\n",level2str[LOGGING_LEVEL_ERROR]);



    char buff[1024];

    strlcpy(buff,"Hello,World",1024);



    printf("[%s](%s)\n",buff,__FILE__);

    while(1){
        LOGGING_LOG_INFO("dddddddddddddd%dddd\n",1024);
        LOGGING_LOG_ERROR("Errrrrrrorrr\n");

//        sleep(1);
    }
    return EXIT_SUCCESS;

}



#endif
