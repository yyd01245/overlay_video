#ifndef _H_SYS_UTILS_
#define _H_SYS_UTILS_


#include<time.h>




int absleep(const struct timespec*req);



typedef void (*sighandler_ft)(int);


int register_signal(int signum,sighandler_ft hndlr );


int popen_out(const char *command, const char *type,char* buff,size_t buff_siz);




int strrepl(char*pstr,const char*pat,const char*rep);


char* strlower(char*pstr);
char* strupper(char*pstr);







#endif
