
#include"sysutils.h"
#include<errno.h>
#include"chks.h"
#include<time.h>
#include<stdio.h>
#include<signal.h>


#define NS_PER_SEC 1000000000UL
#define US_PER_SEC 1000000UL
#define MS_PER_SEC 1000UL


static void tmspec_add( struct timespec*ots,const struct timespec*ts0,const struct timespec* ts1)
{

    long carry=0;
    long ns=ts0->tv_nsec+ts1->tv_nsec;

    if(ns>=NS_PER_SEC){
        carry=1;
        ns-=NS_PER_SEC;
    }

    ots->tv_sec=ts0->tv_sec+ts1->tv_sec+carry;
    ots->tv_nsec=ns;

}


static void tmspec_diff( struct timespec*ots,const struct timespec*ts0,const struct timespec* ts1)
{

    long carry=0;
    long ns=ts1->tv_nsec-ts0->tv_nsec;
    if(ns<0){
        ns+=NS_PER_SEC;
        carry=1;
    }
    

    ots->tv_sec=ts1->tv_sec-ts0->tv_sec-carry;
    ots->tv_nsec=ns;

}







void timespec_str(const struct timespec*ts,char*outstr,int bufsiz)
{
    snprintf(outstr,bufsiz,"timespec{ .tv_sec=%ld\t.tv_nsec=%ld }",ts->tv_sec,ts->tv_nsec);

}



int absleep(const struct timespec*req)
{

    int ret;
    struct timespec ts;

    ret=clock_gettime(CLOCK_REALTIME,&ts);
    tmspec_add(&ts,&ts,req);

restart:

    ret=clock_nanosleep(CLOCK_REALTIME,TIMER_ABSTIME,&ts,NULL);
    if(ret<0 && errno==EINTR){
        fprintf(stderr,"EINTR...\n");
        goto restart;
    }

    return ret;

}






int register_signal(int signum,sighandler_ft hndlr)
{
    
    int ret;
    struct sigaction sa,osa;

    memset(&sa,0,sizeof(struct sigaction));
    sigemptyset(&sa.sa_mask);

    sa.sa_flags=0;
    sa.sa_handler=hndlr;


    ret=sigaction(signum,&sa,&osa);
    
    return ret;

}





static int str_pos(const char*p)
{

    int off=0;;
    const char*pp=p;
    while(*pp){
        if(*pp=='\n' || *pp=='\0')
            return off;
        off++;
        pp++;
    }

}


int popen_out(const char *command, const char *type,char* buff,size_t buff_siz)
{
    
    FILE*fp=popen(command,type);
    size_t siz=buff_siz;
    int offset;
    char*pbuff=buff;
    char*p;

    while(fgets(pbuff,siz,fp)){
        p=strchr(pbuff,'\n');
        if(!p)
            break;
        offset=p-pbuff+1;
        pbuff+=offset;
        siz-=offset;
        if(siz<=0)break;
    }
    buff[buff_siz-1]=0;

    pclose(fp);
    
    return offset;
}



char* strupper(char*pstr)
{

    int i;
    for(i=0;pstr[i];i++){
        pstr[i]&=~0x20;
    }

    return pstr;
}



char* strlower(char*pstr)
{

    int i;
    for(i=0;pstr[i];i++){
        pstr[i]|=0x20;
    }

    return pstr;
}




int strrepl(char*pstr,const char*pat,const char*rep)
{
    int nmatch=0;
    char*pl;

    int p_len=strlen(pstr);
    int pat_len=strlen(pat);
    int rep_len=strlen(rep);

    int mlen;
    char*ppat,*prep;

    while(pl=strstr(pstr,pat)){
        if(!pl)
            break;
        nmatch++;

        ppat=pl+pat_len;
        prep=pl+rep_len;

        mlen=p_len-(ppat-pstr);

        memmove(prep,ppat,mlen+1);
        memmove(pl,rep,rep_len);
    }

    return nmatch;
}








