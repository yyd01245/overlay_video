#include<sys/types.h>
#include<sys/socket.h>
#include<sys/un.h>
#include<unistd.h>

#include<stdio.h>
#include<stdlib.h>

#include"rsm_keyutils.h"

#include"rfb/rfbclient.h"


int init_keyagent(KeyAgent*ka,int idx)
{

    int sock;
    char pathname[32];
    snprintf(pathname,sizeof pathname,"/tmp/bvbcskey-%d",idx);

    fprintf(stderr,"Path[%s]\n",pathname);

    ka->addr.sun_family=AF_LOCAL;
    strncpy(ka->addr.sun_path,pathname,strlen(pathname)+1);

    sock=socket(PF_LOCAL,SOCK_DGRAM,0);

    struct timeval timeout={0,100000};//100ms
    setsockopt(sock,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof timeout);

    ka->sockfd=sock;

    memset(ka->msgbuff,0,sizeof ka->msgbuff);

    return sock;
    
}

int send_pointer_event(KeyAgent*ka,int x,int y,int buttonMask)
{

    rfbPointerEventMsg*msg=(rfbPointerEventMsg*)ka->msgbuff;
        
    msg->type=rfbPointerEvent;
    msg->buttonMask=buttonMask;
    if(x<0)x=0;
    if(y<0)y=0;
    msg->x=SWAP16(x);
    msg->y=SWAP16(y);

    int ret;
    ret=sendto(ka->sockfd,msg,sz_rfbPointerEventMsg,MSG_NOSIGNAL,(struct sockaddr*)&ka->addr,sizeof ka->addr);
    return !(ret<0);

}
int send_key_event(KeyAgent*ka,int key,int down)
{
 
    rfbKeyEventMsg*msg=(rfbKeyEventMsg*)ka->msgbuff;
    msg->type=rfbKeyEvent;
    msg->down=down?1:0;
    msg->key=SWAP32(key);
    msg->pad=0;

    int ret;
    ret=sendto(ka->sockfd,msg,sz_rfbKeyEventMsg,MSG_NOSIGNAL,(struct sockaddr*)&ka->addr,sizeof ka->addr);
    return !(ret<0);

}












int combine_key(BlcYunKeyIrrMsg* irrmsg)//组合键
{
	int key = 0;
	if(3 == irrmsg->body.key_status)
		return 0;
	switch(irrmsg->body.key_value)
	{
		case 0xf2:	{	key = XK_L; break;}
		case 0xf0:	{	key = XK_T;	break;}
		case 0xec:	{	key = XK_B;	break;}
		case 0xee:	{	key = XK_O;	break;}
		case 0xed:	{	key = XK_G;	break;}
		case 0xf1:	{	key = XK_W;	break;}
		case 0xf5:	{	key = XK_R;	break;}
		case 0xeb:	{	key = XK_C;	break;}
		case 0xf3:	{	key = XK_N;	break;}
		case 0x76:	{	key = XK_M;	break;}
		case 0xe8:	{	key = XK_P;	break;}
		case 0xef:	{	key = XK_S;	break;}
		case 0xe9: 	{	key = XK_V;	break;}
		case 0xea:	{	key = XK_I;	break;}
		case 0x3a:	{	key = XK_X;	break;}
		case 0x3b:	{	key = XK_Y;	break;}
		case 0x3c:	{	key = XK_Z;	break;}
		case 0x3d:	{	key = XK_K;	break;}
		case 0xde:	{	key = XK_H;	break;}
		case 0xdf:	{	key = XK_A;	break;}	
		default :      return 0;
	}

    /*
	SendKeyEvent(vnc_client,XK_Alt_L,1);
	SendKeyEvent(vnc_client,key,1);
	SendKeyEvent(vnc_client,key,0);
	SendKeyEvent(vnc_client,XK_Alt_L,0);
	return 0;
    */
//	LOG_DEBUG_FORMAT("DEBUG - [VNCMS]:Send comb key ALT + %x  \n",key);
    return 3;
}

int conv_key_type(BlcYunKeyIrrMsg* irrmsg)//遥控器及机顶盒前面板
{
	switch(irrmsg->body.key_value)
	{
		case 82 :		return XK_Up;
		case 81 :		return XK_Down;
		case 80 :		return XK_Left;
		case 79 :		return XK_Right;
		case 40 :		return XK_Return;
		case 0x58 :		return XK_Return;
		case 0x77 :		return XK_Return;
		case 158 :		return XK_Insert;
		case 0x27 :		return XK_0;
		case 0x29:		return XK_Escape;
		case 0x1e :		return XK_1;
		case 0x1f :		return XK_2;
		case 0x20 :		return XK_3;
		case 0x21 :		return XK_4;
		case 0x22 :		return XK_5;
		case 0x23 :		return XK_6;
		case 0x24 :		return XK_7;
		case 0x25 :		return XK_8;
		case 0x26 :		return XK_9;
		case 0x4a:		return XK_Home;
		case 0x4b:		return XK_Page_Up;
		case 0x4e:		return XK_Page_Down;
		case 0x34:		return XK_apostrophe;
		
	/********front panel keygw*********/
		case 0xf6:		return XK_Up;
        case 0xf7:		return XK_Down;
        case 0xf8:		return XK_Left;
        case 0xf9:		return XK_Right;
		case 0xfa:		return XK_Return;
		case 0xfc:		return XK_Insert;
		
		default :		return combine_key(irrmsg);//return 3
	}	
return 0;
}


int conv_keyboard_value(BlcYunKeyKeyboardMsg* keboardmsg,int opt)//键盘
{
	switch(keboardmsg->body.key_value)
	{
		case 0x4 :		if(opt)		return XK_A;	return XK_a;
		case 0x5 :  	if(opt)		return XK_B;	return XK_b;
		case 0x6 :  	if(opt)		return XK_C;	return XK_c;
		case 0x7 :  	if(opt)		return XK_D;	return XK_d;
		case 0x8 :  	if(opt)		return XK_E;	return XK_e;
		case 0x9 :  	if(opt)		return XK_F;	return XK_f;
		case 0xa :  	if(opt)		return XK_G;	return XK_g;
		case 0xb :  	if(opt)		return XK_H;	return XK_h;
		case 0xc :  	if(opt)		return XK_I;	return XK_i;
		case 0xd :  	if(opt)		return XK_J;	return XK_j;
		case 0xe :  	if(opt)		return XK_K;	return XK_k;
		case 0xf :  	if(opt)		return XK_L;	return XK_l;
		case 0x10:  	if(opt)		return XK_M;	return XK_m;
		case 0x11:  	if(opt)		return XK_N;	return XK_n;
		case 0x12:  	if(opt)		return XK_O;	return XK_o;
		case 0x13:  	if(opt)		return XK_P;	return XK_p;
		case 0x14:  	if(opt)		return XK_Q;	return XK_q;
		case 0x15:  	if(opt)		return XK_R;	return XK_r;
		case 0x16:  	if(opt)		return XK_S;	return XK_s;
		case 0x17:  	if(opt)		return XK_T;	return XK_t;
		case 0x18:  	if(opt)		return XK_U;	return XK_u;
		case 0x19:  	if(opt)		return XK_V;	return XK_v;
		case 0x1a: 		if(opt)		return XK_W;	return XK_w;
		case 0x1b: 		if(opt)		return XK_X;	return XK_x;
		case 0x1c: 		if(opt)		return XK_Y;	return XK_y;
		case 0x1d:	 	if(opt)		return XK_Z;	return XK_z;
		case 0x1e: 		if(opt)		return XK_exclam;	return XK_1;
		case 0x1f: 		if(opt)		return XK_at;		return XK_2;
		case 0x20:		if(opt)		return XK_numbersign;	return XK_3;
		case 0x21:		if(opt)		return XK_dollar;	return XK_4;
		case 0x22:		if(opt)		return XK_percent;	return XK_5;
		case 0x23:		if(opt)		return XK_asciicircum;	return XK_6;
		case 0x24:		if(opt)		return XK_ampersand;	return XK_7;
		case 0x25:		if(opt)		return XK_asterisk;	return XK_8;
		case 0x26:		if(opt)		return XK_parenleft;	return XK_9;
		case 0x27:		if(opt)		return XK_parenright;	return XK_0;
		case 0x28:		return XK_KP_Enter;
		case 0x29:		return XK_Escape;
		case 0x2a:		return XK_BackSpace;
		case 0x2b:		return XK_Tab;
		case 0x2c:		return XK_space;
		case 0x2d:		if(opt)		return XK_underscore;	return XK_minus;
		case 0x2e:		if(opt)		return XK_plus;		return XK_equal;
		case 0x2f:		if(opt)		return XK_braceleft;	return XK_bracketleft;
		case 0x30:		if(opt)		return XK_braceright;	return XK_bracketright;
		case 0x31:		if(opt)		return XK_bar;		return XK_backslash;
		case 0x32:		if(opt)		return XK_quoteleft;	return XK_asciitilde;
		case 0x33:		if(opt)		return XK_colon;	return XK_semicolon;
		case 0x34:		if(opt)		return XK_quotedbl;	return XK_apostrophe;
		case 0x35:		if(opt)		return XK_asciitilde;	return XK_grave;
		case 0x36:		if(opt)		return XK_less;		return XK_comma;
		case 0x37:		if(opt)		return XK_greater;	return XK_period;
		case 0x38:		if(opt)		return XK_question;	return XK_slash;
		case 0x39:		return XK_Caps_Lock;
		case 0xaa:		return XK_Alt_L;
		case 0xa9:		return XK_Control_L;
		case 0xa8:		return XK_Shift_L;
		case 0x3a:		return XK_F1;
		case 0x3b:		return XK_F2;
		case 0x3c:		return XK_F3;
		case 0x3d:		return XK_F4;
		case 0x3e:		return XK_F5;
		case 0x3f:		return XK_F6;
		case 0x40:		return XK_F7;
		case 0x41:		return XK_F8;
		case 0x42:		return XK_F9;
		case 0x43:		return XK_F10;
		case 0x44:		return XK_F11;
		case 0x45:		return XK_F12;

		case 0x4a:		return XK_Home;
		case 0x4b:		return XK_Page_Up;
		case 0x4c:		return XK_Delete;
		case 0x4d:		return XK_End;
		case 0x4e:		return XK_Page_Down;
		case 0x4f:		return XK_Right;
		case 0x50:		return XK_Left;
		case 0x51:		return XK_Down;
		case 0x52:		return XK_Up;
		default:		return -1;
	}
}

int conv_wheel_type(BlcYunKeyMouseMsg* mousemsg)//鼠标滚轮
{
	short type = (short)(mousemsg->body.key_value);
	if(type>0)
		return rfbButton4Mask;
	return rfbButton5Mask;
}


int conv_mouse_type(BlcYunKeyMouseMsg* mousemsg)//鼠标
{
	switch(mousemsg->body.key_value)
	{
		case 336:		return rfbButton1Mask;
		case 337:		return rfbButton3Mask;
		case 339:		return 0;
		default :		return 0;
	}
}

