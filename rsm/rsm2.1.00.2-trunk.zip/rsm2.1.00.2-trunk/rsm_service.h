#ifndef _H_SERVICE_RSM_
#define _H_SERVICE_RSM_


#include"rzut/zlist.h"

#include"rsm_config.h"
#include"rsm_log.h"
#include"rsm_net.h"
#include"asyncqueue.h"
#include"eventworker.h"
#include"rsm_utils.h"
#include"rsm_resource.h"

#define PLUGIN_DIR "bbcvplugin"
#define EXEC_FAIL 188
#define PLU_DEFAULT_PERIOD 60


typedef struct _rsm_struct rsm_service_t;



enum {
    
    RSM_EVT_0=0,
    RSM_EVT_CMD,//command from CRSM
    RSM_EVT_REP, //report to CRSM
    RSM_EVT_SIG,
    RSM_EVT_PLU,//plugin updated..
    RSM_EVT_VNCMS//reponse for vncms' notify
};


struct rep_alive{

};

struct rep_register{

};
struct rep_alarmevent{
    int level;
    rsm_resource_t*res;
    const char*desc;
//    cJSON*json;
};

struct ew_repinfo{
    int type;
#define TYPE_REP_ALIVE 1
#define TYPE_REP_REGISTER 2
#define TYPE_REP_ALARMEVENT 4
    union {
        struct rep_alarmevent alarm;
        struct rep_register reg;
        struct rep_alive alive;
    }info;

};


struct ew_siginfo{
    int signo;
    int fl_exit;//exit code
    int fl_kill;//signal num
    int pid;
};

struct ew_cmdinfo{
    int fd;
};

struct ew_pluinfo{
    char*plugin_path;
    char*save_path;
};


struct _rsm_struct{
    

    char rsmipstr[INET_ADDRSTRLEN];
    rsm_conf_t rsmconf;
    rsm_log_t rsmlog;


///////////////////////////////////
//resource
    rsm_resource_pool respool;
    int nb_resources;

///////////////////////////////////
//network stuff
    rsm_netlistener_t* cmdlistener;
    rsm_httplistener_t* httplistener;//for preload 
    rsm_httplistener_t* hblistener;//heartbeats from chrome(extension.)
    rsm_netconn_t* reporter;
//    rsm_netbinder_t* vncmsbinder;

///////////////////////////////////
//thread stuff
#ifdef _ENABLE_CHROME_CHECK
    pthread_t webclisten_tid;
    pthread_t webccheck_tid;
//    int hbon;//if any resource recv heartbeats,toggle this flag on.
#endif
    pthread_t cmdlisten_tid;
    pthread_t httplisten_tid;
    pthread_t notify_tid;
    pthread_t sighandle_tid;
    pthread_t stating_tid;
    pthread_t streami_tid;
    pthread_t plucheck_tid;
//eventwork 
    eventworker_t evtworker;

//for rsm_system()
    pid_t sysid;
    int sysret;
    pthread_mutex_t syslock;
    pthread_cond_t syscond;

///////////////////////////////////
//for chrome plugin
    int plu_default;// if !0;then not fetch new plugin from network
    long plu_ts;
    int plu_chkperiod;
    char plu_version[16];
    char* plu_remotepath;//  ""ftp://127.0.0.1/plugin1.zip""
    char* plu_localpath;//   ""file:///opt/""
    char* plu_name;//        ""plugin1.zip""

///////////////////////////////////
//for Utilization
    cpu_stat cpustat0;
    cpu_stat cpustat;
    mem_stat memstat;
    gpu_stats gpustats;
    int cpuoccupy,memoccupy;
    int cpulimit,memlimit,
        gpumemlimit;

    int in_overloaded;//current status
///////////////////////////////////
//for report(vncregister&vncalive)
    char*register_msg;
    unsigned int registered:1;

    int rpt_hearttime;
    int rpt_overtime;

};



int rsm_service_init(rsm_service_t*serv,const char*confname);

void rsm_service_fini(rsm_service_t*serv);

void rsm_service_start(rsm_service_t*serv);


int rsm_service_is_overload(rsm_service_t*serv);

int rsm_service_get_host_utilization(rsm_service_t*serv,int*cpu,int*mem);

const char*rsm_service_get_addr(rsm_service_t*serv);

const char*rsm_service_get_pluginversion(rsm_service_t*serv);


#endif
