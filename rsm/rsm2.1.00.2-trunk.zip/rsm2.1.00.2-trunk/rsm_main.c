
#include"rsm.h"
#include"rsm_service.h"
#include"rsm_resource.h"
#include"rsm_utils.h"


rsm_service_t rsmserv;


int in_daemon=1;
const char* confname="rsm.conf";


int main(int argc,char**argv)
{

    int ret;

    int i;
    for(i=1;argv[i];i++){
        if(!strcmp(argv[i],"-D")){
            in_daemon=0;
        }else if(!strcmp(argv[i],"-f")){
            confname=argv[++i];
        }else if(!strcmp(argv[i],"-h")){
            fprintf(stderr,"RSM VERSION (%s)\n"
                    "Usage: %s [-D|-f|-h]\n"
                    "\t-D        : Disable run in foreground,not in daemon.\n"
                    "\t-f <file> : use <file> instead of `rsm.conf'.\n"
                    "\t-h        : print this message.\n",
                    RSM_VERSION,argv[0]);
            return EXIT_SUCCESS;
        }
    }

//    printf("config:%s\n",confname);
//    printf("in daemon:%d\n",in_daemon);
//    return EXIT_SUCCESS;

    if(in_daemon)
        become_daemon();

    ret=rsm_service_init(&rsmserv,confname);
    if(ret<0){
        fprintf(stderr,"Init Rsm Service Failed..");
        return EXIT_FAILURE;
    }

    rsm_service_start(&rsmserv);

//    fprintf(stderr,"OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO\n");

    rsm_service_fini(&rsmserv);



    return EXIT_SUCCESS;
}
