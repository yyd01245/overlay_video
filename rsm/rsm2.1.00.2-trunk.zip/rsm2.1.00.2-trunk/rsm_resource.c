#include"rsm_resource.h"
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/wait.h>
#include"cJSON/cJSON.h"
#include"rzut/chks.h"
#include"rzut/defs.h"

#include"rsm_config.h"
#include"vncms_msg.h"
#include"rsm_msg.h"
#include"rsm_utils.h"
#include"rsm.h"




#define MAX_RES 256
#define resource_NONE ((rsm_resource_t*)0)


#ifdef _RESOURCE_LOCK

#define INIT_LOCK(pool) \
    pthread_mutex_init(&pool->reslock,NULL);


#define FINI_LOCK(pool) \
    pthread_mutex_destroy(&pool->reslock);


#define LOCK(pool) \
    pthread_mutex_lock(&pool->reslock) 

#define UNLOCK(pool) \
    pthread_mutex_unlock(&pool->reslock) 


#else

#define INIT_LOCK(pool) 

#define FINI_LOCK(pool) 


#define LOCK(pool) 

#define UNLOCK(pool) 


#endif



extern int emit_alarmevent(rsm_resource_t*res,int level,const char*desc);

extern int emit_event_for_vncms(rsm_service_t*serv,void*data);

extern int rsm_service_get_host_utilization(rsm_service_t*serv,int*cpu,int*mem);

extern const char*rsm_service_get_addr(rsm_service_t*serv);

extern const char*rsm_service_get_pluginversion(rsm_service_t*serv);

extern int rsm_service_is_overload(rsm_service_t*serv);







static int check_if_overload(rsm_resource_t*ps)
{
    if(!ps)
        return 0;

    rsm_service_t*serv=ps->ref_pool->rsmserv;

    return rsm_service_is_overload(serv);

}


void rsm_resource_pool_get_resource_info(rsm_resource_pool*respool,int*noconf,int*nook)
{
    //TODO


}


static rsm_resource_t*rsm_resource_pool_drop(rsm_resource_pool*respool,rsm_resource_t* ps);


////////////////////////////////////
//Process resource index

static inline int _respool_occupy_index(rsm_resource_pool*pool,rsm_resource_t*res,int index)
{
    int reti=0;


    if(index>pool->maxidx||index<pool->startidx)
        goto exit;

    if(pool->revindex[index])
        goto exit;
    
    pool->revindex[index]=res;
    reti=index;

exit:    
    return reti;
}

static inline void _respool_release_index(rsm_resource_pool*pool,int idx)
{

    if(idx>=pool->startidx && idx<=pool->maxidx)
        pool->revindex[idx]=resource_NONE;


}


static inline int _respool_set_start(rsm_resource_pool*pool,int startid)
{

    pool->startidx=startid;

}


////////////////////////////////////////////

static void _respool_dump(rsm_resource_pool*pool)
{


    char buff[2048];
    buff[0]=0;
//for debug
    int i;
    rsm_resource_t*ps;


    rsm_snprintf_append(buff,sizeof buff,"\n");
    rsm_snprintf_append(buff,sizeof buff,"(FAIL:%3d: ",pool->num_fail);
    list_for_each_entry(ps,&pool->failhead,list){
            rsm_snprintf_append(buff,sizeof buff,"%3d ",ps->index);
    }
    rsm_snprintf_append(buff,sizeof buff,"\n");
    rsm_snprintf_append(buff,sizeof buff,"(FREE:%3d: ",pool->num_free);
    list_for_each_entry(ps,&pool->freehead,list){
            rsm_snprintf_append(buff,sizeof buff,"%3d ",ps->index);
    }
    rsm_snprintf_append(buff,sizeof buff,"\n");
    rsm_snprintf_append(buff,sizeof buff,"(PRE :%3d: ",pool->num_pre);
    list_for_each_entry(ps,&pool->prehead,list){
            rsm_snprintf_append(buff,sizeof buff,"%3d ",ps->index);
    }
    rsm_snprintf_append(buff,sizeof buff,"\n");
    rsm_snprintf_append(buff,sizeof buff,"(BUSY:%3d: ",pool->num_busy);
    int avon_no=0;
    int avoff_no=0;
    list_for_each_entry(ps,&pool->busyhead,list){
        char it[5];
        if(ps->avstatus==AVSTATUS_ON){
            avon_no++; 
            rsm_snprintf_append(buff,sizeof buff,"%3d ",ps->index);
        }else{
            avoff_no++;
            rsm_snprintf_append(buff,sizeof buff,"%2d^ ",ps->index);
        }
    }
    rsm_snprintf_append(buff,sizeof buff,"\n\tON:%d/OFF:%d\n",avon_no,avoff_no);
    rsm_snprintf_append(buff,sizeof buff,"\n");

    RSM_LOG_DEBUG("RESPOOL STATUS::\n\033[32m%s\033[0m",buff);

}






static int _respool_res_busy2free(rsm_resource_pool*pool,rsm_resource_t*ps)
{

    return_val_if_fail(pool!=NULL&&ps!=NULL,-1);
    if(ps->status!=RES_BUSY){
        return -1;
    }

    RSM_LOG_DEBUG("Move Resource<%d> From `Busy' to `Free'.",ps->index);
//    _respool_dump(pool);

    list_del(&ps->list);
    pool->num_busy--;
    list_add_tail(&pool->freehead,&ps->list);
    pool->num_free++;
    ps->status=RES_FREE;

    _respool_dump(pool);
    return 0;
}

static int _respool_res_all2fail(rsm_resource_pool*pool,rsm_resource_t*ps)
{

    return_val_if_fail(pool!=NULL&&ps!=NULL,-1);
#if 1
    char whichlist[8];
    if(ps->status==RES_FREE){
        strlcpy(whichlist,"Free",sizeof whichlist);
    }else 
    if(ps->status==RES_BUSY){
        strlcpy(whichlist,"Busy",sizeof whichlist);
    }else 
    if(ps->status==RES_PRE){
        strlcpy(whichlist,"Pre",sizeof whichlist);
    }else 
    if(ps->status==RES_FAIL){
        strlcpy(whichlist,"Fail",sizeof whichlist);
    }else{
        strlcpy(whichlist,"???",sizeof whichlist);
    }


    RSM_LOG_DEBUG("Move Resource<%d> From `%s' to `Fail'.",ps->index,whichlist);
//    _respool_dump(pool);
#endif
    if(ps->status==RES_FAIL){
        RSM_LOG_DEBUG("Resource<%d> already in `Fail'.",ps->index);
        goto skip;
    }

    list_del(&ps->list);
    if(ps->status==RES_FREE){
        pool->num_free--;
    }else 
    if(ps->status==RES_BUSY){
        pool->num_busy--;
    }else 
    if(ps->status==RES_PRE){
        pool->num_pre--;
    }else{

    }

    list_add_tail(&pool->failhead,&ps->list);
    pool->num_fail++;
    ps->status=RES_FAIL;

skip:
    _respool_dump(pool);
    return 0;
}


static int _respool_res_fail2free(rsm_resource_pool*pool,rsm_resource_t*ps)
{

    return_val_if_fail(pool!=NULL&&ps!=NULL,-1);
    if(ps->status!=RES_FAIL){
        return -1;
    }
    RSM_LOG_DEBUG("Move Resource<%d> From `Fail' to `Free'.",ps->index);
//    _respool_dump(pool);

    list_del(&ps->list);
    pool->num_fail--;
    list_add_tail(&pool->freehead,&ps->list);
    pool->num_free++;
    ps->status=RES_FREE;

    _respool_dump(pool);
    return 0;
}


static int _respool_res_free2pre(rsm_resource_pool*pool,rsm_resource_t*ps)
{

    return_val_if_fail(pool!=NULL&&ps!=NULL,-1);
    if(ps->status!=RES_FREE){
        return -1;
    }
    RSM_LOG_DEBUG("Move Resource<%d> From `Free' to `Pre'.",ps->index);
//    _respool_dump(pool);

    list_del(&ps->list);
    pool->num_free--;
    list_add_tail(&pool->prehead,&ps->list);
    pool->num_pre++;
    ps->status=RES_PRE;

    _respool_dump(pool);
    return 0;
}


static int _respool_res_free2free_tail(rsm_resource_pool*pool,rsm_resource_t*ps)
{

    return_val_if_fail(pool!=NULL&&ps!=NULL,-1);
    if(ps->status!=RES_FREE){
        return -1;
    }

    RSM_LOG_DEBUG("Move Resource<%d> From `Free' to `Free_tail'.",ps->index);
//    _respool_dump(pool);

    list_del(&ps->list);
    list_add_tail(&pool->freehead,&ps->list);

    _respool_dump(pool);
    return 0;
}



static int _respool_res_pre2busy(rsm_resource_pool*pool,rsm_resource_t*ps)
{

    return_val_if_fail(pool!=NULL&&ps!=NULL,-1);
    if(ps->status!=RES_PRE){
        return -1;
    }
    RSM_LOG_DEBUG("Move Resource<%d> From `Pre' to `Busy'.",ps->index);
//    _respool_dump(pool);

    list_del(&ps->list);
    pool->num_pre--;
    list_add_tail(&pool->busyhead,&ps->list);
    pool->num_busy++;
    ps->status=RES_BUSY;

    _respool_dump(pool);
    return 0;
}



static int _respool_res_first(struct list_head*which,rsm_resource_t**ps)
{

    if(list_empty(which)){
        *ps=NULL;
        return -1;
    }

    *ps=list_first_entry(which,rsm_resource_t,list);

    return 0;
}

////////////////////////////////////////////
//For Login Logout

static int _respool_locate_res_by_index(rsm_resource_pool*pool,int idx,rsm_resource_t**ops)
{
    RSM_LOG_DEBUG("Find Resource by index[%d]",idx);
    int ret=0;
    

    if(idx<pool->startidx||idx>pool->maxidx){
        *ops=NULL;
        ret=0;
    }else{
        *ops=pool->revindex[idx];
        ret=idx;
    }

    return ret;
}

static int _respool_locate_res_by_resid(rsm_resource_pool*pool,char*resid,rsm_resource_t**ops)
{
    RSM_LOG_DEBUG("Find Resource by resid[%s]",resid);

    rsm_resource_t*ps=NULL;
    int ret=0;
    int found=0;


    list_for_each_entry(ps,&pool->busyhead,list){
        if(!strcmp(ps->resid,resid)){
            ret=ps->index;
            found=1;
            break;
        }
    }

    if(found){
        *ops=ps;
        RSM_LOG_DEBUG("Resource<idx:%d> has resid(%s)",ret,resid);
    }else{
        *ops=NULL;
        RSM_LOG_DEBUG("No Resource has resid(%s)",resid);
    }

//    _respool_dump(pool);

    return ret;

}

//preloaded resource
static int _respool_obtain_fail_res(rsm_resource_pool*pool,rsm_resource_t**ops)
{
    RSM_LOG_DEBUG("Obtain Fail Resource");
    int ret=0;
    rsm_resource_t*ps=NULL;


    ret=_respool_res_first(&pool->failhead,&ps);
    if(ret!=0){
        RSM_LOG_WARN("No More Fail Resource");
        ret=0;
        *ops=NULL;
    }else{
        ret=ps->index;
        *ops=ps;
    }

    return ret;

}


//preloaded resource
static int _respool_obtain_free_res(rsm_resource_pool*pool,rsm_resource_t**ops)
{
    RSM_LOG_DEBUG("Obtain Free Resource");
    int ret=0;
    rsm_resource_t*ps=NULL;


    ret=_respool_res_first(&pool->freehead,&ps);
    if(ret!=0){
        RSM_LOG_WARN("No More Free Resource");
        ret=0;
        *ops=NULL;
    }else{
        ret=ps->index;
        *ops=ps;
    }

//    _respool_dump(pool);
    return ret;

}


//preloaded resource
static int _respool_obtain_preloaded_res(rsm_resource_pool*pool,rsm_resource_t**ops)
{
    RSM_LOG_DEBUG("Obtain Preloaded Resource");
    int ret=0;
    rsm_resource_t*ps=NULL;

    ret=_respool_res_first(&pool->prehead,&ps);
    if(ret!=0){
        RSM_LOG_WARN("No More Preloaded Resource");
        *ops=NULL;
        ret=0;
    }else{
        ret=ps->index;
        *ops=ps;
    }

//    _respool_dump(pool);
    return ret;

}


//////////////////////////////////
//////////////////////////////////
//for Recovery vncms
//
int rsm_resource_pool_mark_resource_fail(rsm_resource_t*ps)
{
    int ret;

    rsm_resource_pool*pool=ps->ref_pool;
    ret=_respool_res_all2fail(pool,ps);

    return ret;
}

int rsm_resource_pool_mark_resource_free(rsm_resource_t*ps)
{
    int ret;

    rsm_resource_pool*pool=ps->ref_pool;
    ret=_respool_res_fail2free(pool,ps);

    return ret;
}

////////////////////////////////////////////////
////////////////////////////////////////////////
////////////////////////////////////////////////


inline int rsm_send_to_vncms(rsm_resource_t*ps,char*buff)
{
    
    int ret;
    int len=strlen(buff);
    ret=rsm_netlsender_send(ps->sender,buff,len);
    if(ret<0){
        RSM_LOG_DEBUG("RSM Send to VNCMS ERROR(%d){%s}..",ret,strerror(errno));
    }
    return ret;
}


inline int rsm_send_to_crsm(rsm_resource_t*ps,void*buff,size_t len,void*obuff,size_t osiz)
{
#ifdef _DEBUG
    RSM_LOG_DEBUG("Before RSM send to CRSM");
#endif
    int ret;
    ret=rsm_netconn_shot(ps->crsmconn,buff,len,obuff,osiz);
    if(ret>=0)
        ((char*)obuff)[ret]=0;
#ifdef _DEBUG
    RSM_LOG_DEBUG("After RSM send to CRSM <%d>",ret);
    fprintf(stderr,"\033[33m%s\n==>\n%s\033[0m\n",(char*)buff,(char*)obuff);
#endif
    return ret;
}


////////////////////////////////////////
////////////////////////////////////////

static int do_vncms_timeout(rsm_resource_t*ps,cJSON*json)
{
    RSM_LOG_MSG("DO_VNCMS_TIMEOUT");
    int ret;
    rsm_netconn_t*conn=ps->crsmconn;

    char rbuff[256]={0,};
    char sbuff[256];
    char mgmtportstr[8];


    vncms_make_json_msg(json,rbuff,sizeof rbuff);
//    cJSON_Delete(json);
    RSM_LOG_MSG("Got Timeout From VNCMS<idx:%d>:[%s]",ps->index,rbuff);


    snprintf(mgmtportstr,sizeof(mgmtportstr),"%d",atoi(ps->rref_conf->rsm_listen_port)+1);

    cJSON*pjson=rsm_get_json_cmd(RSM_CMD_TIMEOUT,"resid",ps->resid,"vncip",ps->rrsmipstr,
            "vncport",ps->rref_conf->rsm_listen_port,"mgmtport",mgmtportstr,NULL);

    rsm_make_json_cmd(pjson,sbuff,sizeof sbuff);
//    snprintf(sbuff,sizeof(sbuff),"%sXXEE",cJSON_PrintUnformatted(pjson));
    cJSON_Delete(pjson);


    RSM_LOG_MSG("Send VNCTIMEOUT[%s] to CRSM..",sbuff);
    ret= rsm_send_to_crsm(ps,sbuff,strlen(sbuff),rbuff,sizeof(rbuff));
    RSM_LOG_MSG("Recv VNCTIMEOUT[%s] from CRSM..",rbuff);




    return 0;
}



static int do_vncms_exit(rsm_resource_t*ps,cJSON*json)
{
    RSM_LOG_MSG("DO_VNCMS_EXIT");


    int ret;
    rsm_netconn_t*conn=ps->crsmconn;

    char rbuff[256]={0,};
    char sbuff[256];
    char mgmtportstr[8];

    vncms_make_json_msg(json,rbuff,sizeof rbuff);
//    cJSON_Delete(json);
    RSM_LOG_MSG("Got Exit From VNCMS<idx:%d>:[%s]",ps->index,rbuff);


    snprintf(mgmtportstr,sizeof(mgmtportstr),"%d",atoi(ps->rref_conf->rsm_listen_port)+1);

    cJSON*pjson=rsm_get_json_cmd(RSM_CMD_CHECK,"resid",ps->resid,"serialno",ps->serialno,NULL);

    rsm_make_json_cmd(pjson,sbuff,sizeof sbuff);
//    snprintf(sbuff,sizeof(sbuff),"%sXXEE",cJSON_PrintUnformatted(pjson));
    cJSON_Delete(pjson);


    RSM_LOG_MSG("Send VNCCHECK[%s] to CRSM..",sbuff);
    ret= rsm_send_to_crsm(ps,sbuff,strlen(sbuff),rbuff,sizeof(rbuff));
    RSM_LOG_MSG("Recv VNCCHECK[%s] from CRSM..",rbuff);

    //TODO
    //PARSE rbuff
    rsm_resource_pool_drop(ps->ref_pool,ps);

//    _respool_return_res(ps->ref_pool,ps);

    rsm_resource_pool_preload(ps->ref_pool);

    return 0;

}


static int do_vncms_alive(rsm_resource_t*ps,cJSON*json)
{

    RSM_LOG_MSG("DO_VNCMS_ALIVE");
    int ret;
    rsm_netconn_t*conn=ps->crsmconn;

    char rbuff[256]={0,};
    char sbuff[256];
    char mgmtportstr[8];

    vncms_make_json_msg(json,rbuff,sizeof rbuff);
//    cJSON_Delete(json);
    RSM_LOG_MSG("Got Alive From VNCMS<idx:%d>:[%s]",ps->index,rbuff);


    return 0;
}

static int do_vncms_action_reply(rsm_resource_t*ps,cJSON*json)
{

    char buff[256];

    vncms_make_json_msg(json,buff,sizeof buff);
//    cJSON_Delete(json);

    RSM_LOG_MSG("Got Action-Reply From VNCMS<idx:%d>:[%s]",ps->index,buff);


    return 0;
}



static void* recv_notify_from_vncms(void*data)
{
    rsm_resource_t*ps=(rsm_resource_t*)data;

//    fprintf(stderr,"Recv From VNCMS(idx:%d)\n",ps->index);
    RSM_LOG_MSG("Enter VNCMS(idx:%d) Recv Thread..",ps->index);


    rsm_service_t*serv=ps->ref_pool->rsmserv;

    

    char tname[32];
    snprintf(tname,sizeof tname,"vncms-recvr:%d",ps->index);
    SET_THREAD_NAME(tname);

    cJSON*pjson=NULL;
    notif_t rntf;

    char rbuff[128]={0,};
    char sbuff[128];
    
    char desc[256];

    unsigned long seq;
    //
    while(1){

        int ret;
        rsm_netlbinder_recv(ps->binder,rbuff,sizeof(rbuff));

        RSM_LOG_MSG("Recv Notify From VNCMS(idx:%d)",ps->index);

        rntf=vncms_parse_json_notify(rbuff,&pjson);
        CHK_RUN(!pjson,"Parse notify json Failed..Continue",
                continue);


        RSM_LOG_DEBUG("Get Notify[%s]",vncms_get_notify_str(rntf));
        switch(rntf){

             case VNCMS_NTF_ACT_REPLY:{

                ret=do_vncms_action_reply(ps,pjson);
                
                snprintf(desc,sizeof desc,"vncms action reply unexpected..");
                emit_alarmevent(ps,2,desc);

                break;
                }

             case VNCMS_NTF_PROC_EXIT:{

                char*proc=NULL;
                char*pid=NULL;
                char*count=NULL;
                cjson_get_value(pjson,"proc",&proc);
                cjson_get_value(pjson,"pid",&pid);
                cjson_get_value(pjson,"count",&count);

#ifdef _ENABLE_CHROME_CHECK
                if(proc&&!strcmp(proc,"chrome")){//PROC_TYPE_CHROME 
                    ps->hb_ts=0; 
                    ps->n_hbdelay=HB_MAXDELAY; 
                    ps->n_hbretry=HB_MAXRETRY; 
                    __sync_synchronize();
                }
#endif

                snprintf(desc,sizeof desc,"process %s(pid:%s) has exited, may retry %s times.",proc,pid,count);
                iffree(proc);
                iffree(pid);
                iffree(count);

                emit_alarmevent(ps,2,desc);


                break;
                }
#ifdef _ENABLE_CHROME_CHECK_SHOW
             case VNCMS_NTF_CHROME_CHECK_SHOW:{
                
                char*pok=NULL;
                cjson_get_value(pjson,"show",&pok);
                int ok=atoi(pok);
                iffree(pok);
                ps->webcchk_show=ok;

                if(ok){
                    RSM_LOG_DEBUG("Chrome<idx:%d> check show Okay..",ps->index);
                    break;
                }

                RSM_LOG_DEBUG("Chrome<idx:%d> check show Fail..",ps->index);
#ifdef _ENABLE_CHROME_CHECK
                ps->hb_ts=0; 
                ps->n_hbdelay=HB_MAXDELAY; 
                ps->n_hbretry=HB_MAXRETRY; 
                __sync_synchronize();
#endif

                rsm_resource_reset_webc(ps);

                snprintf(desc,sizeof desc,"chrome not show during preloading..");
                emit_alarmevent(ps,2,desc);

                break;
                }
#endif
           
            case VNCMS_NTF_TIMEOUT:{
#if 1
                ret=do_vncms_timeout(ps,pjson);//direct send to CRSM
#else
                snprintf(desc,sizeof desc,"vncms notify timeout..");

                emit_alarmevent(ps,1,desc);
#endif
                break;
                }
            case VNCMS_NTF_EXIT:{
#if 1
                ret=do_vncms_exit(ps,pjson);//direct send to CRSM
#else

                snprintf(desc,sizeof desc,"vncms notify exit..");

                emit_alarmevent(ps,1,desc);
#endif
                break;
                }
            case VNCMS_NTF_ALIVE:{
#if 1
                ret=do_vncms_alive(ps,pjson);
#else

                snprintf(desc,sizeof desc,"vncms notify alive..");

                emit_alarmevent(ps,1,desc);

#endif
                break;
                }
            
            default:{

                RSM_LOG_WARN("Unknow Notify Type<%s> From VNCMS",vncms_get_notify_str(rntf));
                }
        }

        cJSON_Delete(pjson);


    }

}



rsm_resource_pool*rsm_resource_pool_init(rsm_resource_pool*respool,rsm_conf_t *conf,rsm_service_t*serv,int maxsize)
{

    return_val_if_fail(respool!=NULL,NULL);

    bzero(respool,sizeof(rsm_resource_pool));

    respool->rsmserv=serv; 
    respool->config=conf;

    INIT_LIST_HEAD(&respool->failhead);
    INIT_LIST_HEAD(&respool->freehead);
    INIT_LIST_HEAD(&respool->prehead);
    INIT_LIST_HEAD(&respool->busyhead);

    respool->num_free=maxsize;
    respool->num_fail=0;
    respool->num_busy=0;
    respool->num_pre=0;

    respool->num_setpre=atoi(conf->rsm_pre_amount);

    int ret=rsm_get_addr_by_iface(conf->rsm_net_iface,respool->rsmipstr,INET_ADDRSTRLEN);
    if(ret<0){
//        RSM_LOG_WARN("Get IP Failed!! Using 127.0.0.1 instead.");
        RSM_LOG_ERROR("Get IP of NetIface(%s) Failed!!.",conf->rsm_net_iface);
        return NULL;
    }
    rsm_resource_t*ps;


    int startidx=1;
    startidx=atoi(conf->rsm_vid_startidx);
    if(startidx<1)
        startidx=1;
    
    respool->startidx=startidx;

    respool->maxidx=maxsize+startidx-1;
   
    //revindex[0] allocated but reserved..
    respool->revindex=calloc(respool->maxidx+1,sizeof(rsm_resource_t*));
    CHK_EXPRe(!respool->revindex,"Allocate ResourcePool's revindex Failed..")

        RSM_LOG_ERROR("Allocate ResourcePool's revindex Failed..")
        goto fail0;
    END_CHK_EXPR

    INIT_LOCK(respool);


    int i;
    for(i=respool->startidx;i<=respool->maxidx;i++){
        ps=rsm_resource_pool_new_resource(respool,i);
        CHK_EXPR(!ps,"RSM Resource New Failed..")
            RSM_LOG_ERROR("Add New Resource<:%d> Failed",i);
            
            goto fail1;
        END_CHK_EXPR

        usleep(100000);
    }

    rsm_resource_pool_preload(respool);
    usleep(200000);

    return respool;




fail1:
    for(i=respool->startidx;i<respool->maxidx;i++){
        ps=respool->revindex[i];
        if(ps)
            rsm_resource_pool_free(respool,ps);

    }

    FINI_LOCK(respool);

    free(respool->revindex);

fail0:

    return NULL;
}




void rsm_resource_pool_fini(rsm_resource_pool*respool)
{
 
    RSM_LOG_MSG("Resource Pool Finilize..");
    return_if_fail(respool!=NULL);

    int i;

    rsm_resource_t*ps;

    RSM_LOG_MSG("Resource Pool [%d:%d]..",respool->startidx,respool->maxidx);
    for(i=respool->startidx;i<=respool->maxidx;++i){
        rsm_resource_pool_free(respool,respool->revindex[i]);
    }
    
    FINI_LOCK(respool);

    free(respool->revindex);
    
}


rsm_resource_t*rsm_resource_pool_new_resource(rsm_resource_pool*respool,int index)
{
    int ret;
    return_val_if_fail(respool!=NULL,NULL);

    RSM_LOG_DEBUG("New Resource.");

    rsm_resource_t*ps=calloc(1,sizeof(rsm_resource_t));
    CHK_RUNe(!ps,"Allocate Failed.",
            goto fail0)


    ps->ref_pool=respool;

    index=_respool_occupy_index(respool,ps,index);   
    CHK_RUN(index==0,"Index busy..",
            goto fail1);

//init ps
    ps->index=index;
    ps->status=RES_FREE; 
    bzero(ps->iip,sizeof ps->iip);
    ps->iport=0;
    ps->rate=0;
    ps->peakrate=0;
//
    ps->keytimeout=atoi(respool->config->vncms_keytimeout);
    ps->sendport=atoi(respool->config->vncms_listenport)+index;
    ps->bindport=atoi(respool->config->rsm_vncms_listenport)+index;
    ps->connport=atoi(respool->config->crsm_port);


//communication
    char path[32];
    snprintf(path,sizeof path,"/tmp/rsm_binder%d",ps->index);
    ps->binder=rsm_netlbinder_new(path);
    CHK_EXPRe(!ps->binder,"Make VNCMS Binder Failed..")
        goto fail2;
    END_CHK_EXPRe

    snprintf(path,sizeof path,"/tmp/vncms_binder%d",ps->index);
    ps->sender=rsm_netlsender_new(path); 
    CHK_EXPRe(!ps->sender,"Make VNCMS Sender Failed..")
        goto fail3;
    END_CHK_EXPRe

    const char*crsmip=respool->config->crsm_ip;
    ps->crsmconn=rsm_netconn_new(crsmip,ps->connport);
    CHK_EXPRe(!ps->crsmconn,"Make CRSM Connecter Failed..")
        goto fail4;
    END_CHK_EXPRe


    pthread_attr_t tattr;
    pthread_attr_init(&tattr);
    pthread_attr_setdetachstate(&tattr,PTHREAD_CREATE_DETACHED);
   
    ret=pthread_create(&ps->binder_tid,NULL,recv_notify_from_vncms,ps);
    pthread_attr_destroy(&tattr);
    CHK_RUNe(ret!=0,"Create binder thread for vncms failed...",
            goto fail5);

    ////////////////
    
    list_add_tail(&respool->freehead,&ps->list);


//    ps->vncms_cnt=3;//最多重启3次

    pid_t pid;

    pid=fork();
    CHK_RUNe(pid<0,"Fork Failed.",
            goto fail6)


    if(pid!=0){
        //Parent
        ps->vncmspid=pid;

        return ps;
    }

    unblock_all_signals();
    //CHILD PROCESS
    char idx[8];
    snprintf(idx,sizeof(idx),"%d",ps->index);
    
    ret=execlp("./vncms","vncms",idx,(void*)0);
    CHK_RUNe(ret<0,"Launch VNCMS Failed..",
            exit(EXEC_FAIL));
    
    return NULL;



fail6:
    pthread_cancel(ps->binder_tid);
fail5:
    rsm_netconn_free(ps->crsmconn);
fail4:
    rsm_netlsender_free(ps->sender);
fail3:
    rsm_netlbinder_free(ps->binder);
fail2:
    _respool_release_index(respool,index);
fail1:
    free(ps);

fail0:

    return NULL;

}


//called when logout
static void _rsm_resource_pool_reset_resource(rsm_resource_pool*respool,rsm_resource_t*ps)
{

    int ret;
//    ps->keytimeout=0;//键值超时seconds

    ps->status=RES_FREE;//RES_BUSY RES_PRE RES_FREE
    ps->avstatus=AVSTATUS_OFF;//AVSTATUS_ON AVSTATUS_OFF
    ps->start_ts=0;
#ifdef _ENABLE_CHROME_CHECK
    ps->hb_ts=0;
    ps->n_hbdelay=HB_MAXDELAY;
    ps->n_hbretry=HB_MAXRETRY;
#endif    

#ifdef _ENABLE_CHROME_CHECK_SHOW
    ps->webcchk_show=0;
#endif

    iffreez(ps->resid);
    iffreez(ps->url);
    iffreez(ps->serialno);

    bzero(ps->iip,sizeof ps->iip);
    ps->keytimeout=0;
    ps->iport=0;
    ps->rate=0;
    ps->peakrate=0;

}


void rsm_resource_pool_free(rsm_resource_pool*respool,rsm_resource_t*ps)
{
    return_if_fail(respool!=NULL&&ps!=NULL);

    RSM_LOG_DEBUG("Free Resource<idx:%d>.",ps->index);
    int ret;


    pthread_cancel(ps->binder_tid);

    rsm_netlbinder_free(ps->binder);

    rsm_netlsender_free(ps->sender);

    rsm_netconn_free(ps->crsmconn);

    _respool_release_index(respool,ps->index);


    RSM_LOG_DEBUG("About To Send SIGTERM to VNCMS<pid:%d>..",ps->vncmspid);

    ret=kill(ps->vncmspid,SIGTERM);
    CHK_RUNe(ret<0,"Kill VNCMS Failed..",);
/*
    ret=kill(ps->vncmspid,SIGKILL);
    CHK_RUNe(ret<0,"Kill VNCMS Failed..",);
*/
    free(ps);

    return ;

}



//for preload
int rsm_resource_pool_preload(rsm_resource_pool*respool)
{
//    numbusy+curprenum+freenum=maxsize;

    rsm_resource_t*ps;
    int maxidx=respool->maxidx;
    int minidx=respool->startidx;

    int busynum=respool->num_busy;
    int prenum=respool->num_setpre;
    int curprenum=respool->num_pre;
    int triggernum=(prenum+1)/3;
    int diff=prenum-curprenum;


    RSM_LOG_DEBUG("\033[33mNo.Busy:%d, No.Preload:%d,No.curPreloaded:%d IDX[%d:%d]\n\033[0m",
            busynum,prenum,curprenum,minidx,maxidx);

    RSM_LOG_DEBUG("Before Preload Resource...");
    _respool_dump(respool);
    ////

    char sbuff[128];
    cJSON*act_json=NULL;
    act_json=vncms_get_json_action(VNCMS_ACT_OPEN_WEBC,NULL);
    vncms_make_json_msg(act_json,sbuff,sizeof(sbuff));
    cJSON_Delete(act_json);

    int rcode=0;
    int id=0;
    int i=0,c=0;
    int maxloop=respool->num_free;//avoid dead loop
    while(diff>=triggernum && i<diff && c<maxloop){

        c++;
        i++;
        //check gpumem for load chrome
        // No more FREE Resource
        id=_respool_obtain_free_res(respool,&ps);
        if(id==0){
            RSM_LOG_WARN("STOP PRELOAD ::NO MORE RESOURCE.");
            break;
        }

        // Send message to VNCMS for launching chrome
        RSM_LOG_MSG("About To PreLoad Chrome<vncms:%d>..",id);
#ifdef _ENABLE_CHROME_CHECK
        ps->hb_ts=0;
        ps->n_hbdelay=HB_MAXDELAY;
        ps->n_hbretry=HB_MAXRETRY;
        __sync_synchronize();
#endif    
        int rv=rsm_send_to_vncms(ps,sbuff);//,strlen(sbuff));
        CHK_EXPRe(rv<0,"Communicate to vncms Failed..")
            RSM_LOG_WARN("Ask VNCMS<%d> to Launch Chrome Failed..");
            i--;
//            _respool_res_free2free_tail(respool,ps);
            _respool_res_all2fail(respool,ps);          
            continue;
        END_CHK_EXPRe

        _respool_res_free2pre(respool,ps);

    }

    RSM_LOG_DEBUG("After Preload Resource...");
    _respool_dump(respool);

    return 0;

}



int rsm_resource_reset_webc(rsm_resource_t*res)
{

    char sbuff[128];
    cJSON*act_json=NULL;

    RSM_LOG_MSG("About To Reset Chrome<vncms:%d>..",res->index);

    act_json=vncms_get_json_action(VNCMS_ACT_CLOSE_WEBC,NULL);
    vncms_make_json_msg(act_json,sbuff,sizeof(sbuff));
    cJSON_Delete(act_json);
    int rv=rsm_send_to_vncms(res,sbuff);
 
    act_json=vncms_get_json_action(VNCMS_ACT_OPEN_WEBC,NULL);
    vncms_make_json_msg(act_json,sbuff,sizeof(sbuff));
    cJSON_Delete(act_json);
    rv=rsm_send_to_vncms(res,sbuff);

    return 0;
}




rsm_resource_t*rsm_resource_pool_login(rsm_resource_pool*respool,const cJSON*pjson,cJSON**retjson)
{

    int ret;
    int index;
	int retcode=0;
    return_val_if_fail(respool!=NULL&&pjson!=NULL&&retjson!=NULL,NULL);
   
	rsm_resource_t*ps=NULL;

    char pretcode[8];
    char*riip=NULL;
    char*riport=NULL;
    char*rrate=NULL;
    char*rurl=NULL;
    char*rresid=NULL;
    char*rserialno=NULL;

//  1. Validate json's fields

    ret=rsm_json_fill(pjson,"resid",&rresid,"iip",&riip,"iport",&riport,"url",&rurl,"rate",&rrate,"serialno",&rserialno,NULL);
    CHK_EXPR(ret!=6,"Parse Login Json.")
        RSM_LOG_WARN("Invalid Json From CRSM");
 
        retcode=-8;
        snprintf(pretcode,sizeof(pretcode),"%d",retcode);
        if(retjson){
//            if(rserialno)
                *retjson=rsm_get_json_cmd(RSM_CMD_LOGIN,"retcode",pretcode,"serialno",rserialno,NULL);
//            else
//                *retjson=rsm_get_json_cmd(RSM_CMD_LOGIN,"retcode",pretcode,NULL);
        }

        iffree(riip);
        iffree(riport);
        iffree(rrate);
        iffree(rurl);
        iffree(rresid);
        iffree(rserialno);

        return NULL;

    END_CHK_EXPR


//  2. Check whether the resid has been employed yet.
//  if `index' is not `0', imply that the resource was paused,
//  We should open avencoder & audiorecord again....
    index=_respool_locate_res_by_resid(respool,rresid,&ps);
    CHK_EXPR(index!=0,"Current Resource Already Logined(paused)..")
//        RSM_LOG_WARN("RESID(%s)@%d Already Logined..",rresid,index);

/*
        if(ps->avstatus==AVSTATUS_ON){
            RSM_LOG_WARN("Invalid Login,Due to AVEncoder is running..");            
            retcode=-1835;
            snprintf(pretcode,sizeof(pretcode),"%d",retcode);
            if(retjson)
                *retjson=rsm_get_json_cmd(RSM_CMD_LOGIN,"retcode",pretcode, "resid",rresid,"serialno",rserialno,NULL);

        iffree(riip);
        iffree(riport);
        iffree(rrate);
        iffree(rurl);
        iffree(rresid);
        iffree(rserialno);
            return NULL;
        }
*/
        
        RSM_LOG_MSG("Vnclogin After Pause{idx:%d,resid:[%s]}..",index,rresid);
        RSM_LOG_MSG("TO Resume AVENCODER...");

        goto resume;

    END_CHK_EXPR


    int overload=0;

//  3. Choose a preloaded Resource.
    index=_respool_obtain_preloaded_res(respool,&ps);
    overload=check_if_overload(ps);
    CHK_EXPR(!index||overload,"No More Resource Available..")
        if(!index)
            RSM_LOG_WARN("No More Resource Available..");
        if(overload)
            RSM_LOG_WARN("Host is Overload<state:%d>, Login not allowed..",overload);

        retcode=-1833;
        snprintf(pretcode,sizeof(pretcode),"%d",retcode);
        if(retjson)
            *retjson=rsm_get_json_cmd(RSM_CMD_LOGIN,"retcode",pretcode, "resid",rresid,"serialno",rserialno,NULL);

        iffree(riip);
        iffree(riport);
        iffree(rrate);
        iffree(rurl);
        iffree(rresid);
        iffree(rserialno);
        return NULL;

    END_CHK_EXPR

    //new index 
    _respool_res_pre2busy(respool,ps);

    time(&ps->start_ts);

resume:


    ps->iport=atoi(riport);
    ps->rate=atoi(rrate);
    strlcpy(ps->iip,riip,sizeof(ps->iip));
    
    iffree(riip);
    iffree(riport);
    iffree(rrate);

    iffreez(ps->resid);
    iffreez(ps->serialno);
    iffreez(ps->url);

    ps->resid=rresid;
    ps->serialno=rserialno;
    ps->url=rurl;

    char destaddr[INET_ADDRSTRLEN+8];
    char rate[8];
    snprintf(destaddr,sizeof(destaddr),"%s:%d",ps->iip,ps->iport);
    snprintf(rate,sizeof(rate),"%d",ps->rate);

    char sbuff[128];
    char rbuff[128]={0,};
    cJSON*act_json=NULL;

    act_json=vncms_get_json_action(VNCMS_ACT_OPEN_AVENC,"destaddr",destaddr,"rate",rate,NULL);
    ps->avstatus=AVSTATUS_ON;
    //
    vncms_make_json_msg(act_json,sbuff,sizeof(sbuff));
    cJSON_Delete(act_json);

    int rcode;
    int rv=rsm_send_to_vncms(ps,sbuff);//,strlen(sbuff));//,rbuff,sizeof(rbuff));


/////////
//set timeout
    if(ps->keytimeout){

        act_json=vncms_get_json_action(VNCMS_ACT_SET_TIMEOUT,"val",respool->config->vncms_keytimeout,NULL);
        //
        vncms_make_json_msg(act_json,sbuff,sizeof(sbuff));
        cJSON_Delete(act_json);
        rv=rsm_send_to_vncms(ps,sbuff);//,strlen(sbuff));
        
    }
//////
	char pkeyport[8];
    char pnum_free[8];


    snprintf(pretcode,sizeof(pretcode),"%d",retcode);

    char*prsmip=respool->rsmipstr;
	snprintf(pkeyport,sizeof(pkeyport),"%d",atoi(respool->config->vncms_keyport)+ps->index);
	snprintf(pnum_free,sizeof(pnum_free),"%d",rsm_resource_pool_get_free_num(respool));

    if(retjson)
        *retjson=rsm_get_json_cmd(RSM_CMD_LOGIN,"retcode",pretcode, "resid",rresid,"vncip",prsmip,"keyport",pkeyport,"freenum",pnum_free,"serialno",rserialno,NULL);


//    RSM_LOG_DEBUG("-----------------------rsm-url:%s==========",ps->url);

    rsm_resource_pool_preload(respool);

    return ps;

}


rsm_resource_t*rsm_resource_pool_logout(rsm_resource_pool*respool,const cJSON*pjson,cJSON**retjson)//const char*jsonstr)
{
    
    int ret;
	rsm_resource_t*ps=NULL;
    char pretcode[8];

    return_val_if_fail(respool!=NULL&&pjson!=NULL,NULL);
	int retcode=0;
    int index=0;
    int havidx=0;

/////////////////////
    char*rresid=NULL;
    char*rserialno=NULL;
    char*rindex=NULL;

    ret=rsm_json_fill(pjson,"serialno",&rserialno,NULL);
    CHK_EXPR(ret!=1,"No serialno field found..")
        RSM_LOG_WARN("No `serialno' Field Found..");

    END_CHK_EXPR


//HAVE index field.....
    ret=rsm_json_fill(pjson,"index",&rindex,NULL);
    CHK_EXPR(ret==1,"logout json from CRSMC..")
        RSM_LOG_MSG("Got VNCLOGOUT(idx:%s) from CRSMC...",rindex);
        int base=atoi(respool->config->vncms_keyport);
        index=atoi(rindex)-base;
        havidx=1;
        iffree(rindex);
        //FIXME!!
        _respool_locate_res_by_index(respool,index,&ps);
        if(!ps&&retjson){
            retcode=-1831;
            snprintf(pretcode,sizeof(pretcode),"%d",retcode);

            if(rserialno)
                *retjson=rsm_get_json_cmd(RSM_CMD_LOGOUT,"retcode",pretcode,"serialno",rserialno,NULL);
            else
                *retjson=rsm_get_json_cmd(RSM_CMD_LOGOUT,"retcode",pretcode,NULL);

            return NULL;
        }
//        ps=respool->revindex[index];
        goto skip_findres;
    END_CHK_EXPR 


//    ret=rsm_json_fill(pjson,"resid",&rresid,"serialno",&rserialno,NULL);
    ret=rsm_json_fill(pjson,"resid",&rresid,/*"serialno",&rserialno,*/NULL);
    CHK_EXPR(ret!=1,"Invalid json fields..")

        RSM_LOG_WARN("The Json is Invalid{No `resid' Field Found}..");
        //return 0 for compatible with CRSM
        retcode=0;//-123;

        snprintf(pretcode,sizeof(pretcode),"%d",retcode);
        if(retjson)
            if(rserialno)
                *retjson=rsm_get_json_cmd(RSM_CMD_LOGOUT,"retcode",pretcode,"serialno",rserialno,NULL);
            else
                *retjson=rsm_get_json_cmd(RSM_CMD_LOGOUT,"retcode",pretcode,NULL);

//        if(rresid) free(rresid);

        return NULL;

    END_CHK_EXPR


    index=_respool_locate_res_by_resid(respool,rresid,&ps);
    CHK_EXPR(!index,"Can not find resource..")
        RSM_LOG_WARN("Resource<%d> has not Logined..",rresid);
        retcode=-1831;

        snprintf(pretcode,sizeof(pretcode),"%d",retcode);
        if(retjson){
            if(rserialno)
                *retjson=rsm_get_json_cmd(RSM_CMD_LOGOUT,"retcode",pretcode,"serialno",rserialno,NULL);
            else
                *retjson=rsm_get_json_cmd(RSM_CMD_LOGOUT,"retcode",pretcode,NULL);
        }

        iffree(rresid);
        iffree(rserialno);
        /*
        if(rresid) free(rresid);
        if(rserialno) free(rserialno);
        */
        return NULL;

    END_CHK_EXPR
/////////////////


    char sbuff[128];
    char rbuff[128]={0,};
    cJSON*act_json;
skip_findres:

  
    snprintf(pretcode,sizeof(pretcode),"%d",retcode);

    if(retjson){
        if(rserialno)
            *retjson=rsm_get_json_cmd(RSM_CMD_LOGOUT,"retcode",pretcode,"serialno",rserialno,NULL);
        else
            *retjson=rsm_get_json_cmd(RSM_CMD_LOGOUT,"retcode",pretcode,NULL);
    }

    iffree(rresid);
    iffree(rserialno);


    rsm_resource_pool_drop(respool,ps);


    rsm_resource_pool_preload(respool);

    return ps;

}




rsm_resource_t*rsm_resource_pool_pause(rsm_resource_pool*respool,const cJSON*pjson,cJSON**retjson)
{
    int ret; 
    return_val_if_fail(respool!=NULL&&pjson!=NULL,NULL);
	int retcode=0;
	rsm_resource_t*ps=NULL;
/////////////////////
/////////
    char pretcode[8];
    char*rresid=NULL;
    char*rserialno=NULL;
    ret=rsm_json_fill(pjson,"resid",&rresid,/*"serialno",&rserialno,*/NULL);
    CHK_EXPR(ret!=1,"Invalid Json")
        retcode=0;//-123;
        RSM_LOG_WARN("The Json is Invalid{No `resid' Field Found/Ignored}..");
//        RSM_LOG_WARN("The Json's Fields are Corruptied..Ignored");
        snprintf(pretcode,sizeof(pretcode),"%d",retcode);
        if(retjson)
            *retjson=rsm_get_json_cmd(RSM_CMD_PAUSE,"retcode",pretcode,NULL);

//        if(rresid) free(rresid);
//        if(rserialno) free(rserialno);
        return NULL;

    END_CHK_EXPR

    ret=rsm_json_fill(pjson,"serialno",&rserialno,NULL);
    CHK_EXPR(ret!=1,"No serialno field found..")
        RSM_LOG_WARN("No `serialno' Field Found..");

    END_CHK_EXPR

    int index=_respool_locate_res_by_resid(respool,rresid,&ps);
    CHK_EXPR(!index,"Can not find resource..")
        RSM_LOG_WARN("Invalid resid<%d>(not logined yet)..",rresid);
        retcode=-1831;

        snprintf(pretcode,sizeof(pretcode),"%d",retcode);
        if(retjson){
            if(rserialno)
                *retjson=rsm_get_json_cmd(RSM_CMD_PAUSE,"retcode",pretcode,"serialno",rserialno,NULL);
            else
                *retjson=rsm_get_json_cmd(RSM_CMD_PAUSE,"retcode",pretcode,NULL);

        }

        free(rresid);
        iffree(rserialno);
//        if(rserialno) free(rserialno);
        return NULL;

    END_CHK_EXPR
//Logined..

    cJSON*act_json;
        
    act_json=vncms_get_json_action(VNCMS_ACT_CLOSE_AVENC,NULL);
    ps->avstatus=AVSTATUS_OFF;
//    ps->avon_ts=0;
    RSM_LOG_MSG("To Pause Resource<%d>",ps->index);


    char sbuff[128];
    vncms_make_json_msg(act_json,sbuff,sizeof(sbuff));
    cJSON_Delete(act_json);
    rsm_send_to_vncms(ps,sbuff);//,strlen(sbuff));

    //retcode=0;
    snprintf(pretcode,sizeof(pretcode),"%d",retcode);
    if(retjson){
        if(rserialno)
            *retjson=rsm_get_json_cmd(RSM_CMD_PAUSE,"retcode",pretcode,"serialno",rserialno,NULL);
        else
            *retjson=rsm_get_json_cmd(RSM_CMD_PAUSE,"retcode",pretcode,NULL);

    }
    free(rresid);
    iffree(rserialno);

    _respool_dump(respool);

    
    return ps;
}

int rsm_resource_pool_getserverinfo(rsm_resource_pool*respool,const cJSON*pjson,cJSON**retjson)
{

    int ret;

    return_val_if_fail(respool!=NULL&&pjson!=NULL,-1);


    int n_free,n_busy,n_pre;
    int n_cpu,n_mem;
    
    int n_total=rsm_resource_pool_get_num(respool,&n_free,&n_busy,&n_pre);
    int n_tsload=rsm_resource_pool_get_stream_num(respool);
    int n_leftload=n_free+n_pre;

    rsm_service_get_host_utilization(respool->rsmserv,&n_cpu,&n_mem);

    char totalload_str[8];
    char tsload_str[8];
    char onload_str[8];
    char leftload_str[8];
    char cpu_str[8];
    char mem_str[8];
    char pluginver_str[16];

    snprintf(totalload_str,sizeof totalload_str,"%d",n_total);
    snprintf(onload_str,sizeof onload_str,"%d",n_busy);
    snprintf(leftload_str,sizeof leftload_str,"%d",n_leftload);
    snprintf(tsload_str,sizeof tsload_str,"%d",n_tsload);

    snprintf(cpu_str,sizeof cpu_str,"%d",n_cpu);
    snprintf(mem_str,sizeof mem_str,"%d",n_mem);
    snprintf(pluginver_str,sizeof pluginver_str,"%s",
            rsm_service_get_pluginversion(respool->rsmserv));

    if(retjson)
        *retjson=rsm_get_json_cmd(RSM_CMD_GETSERVERINFO,"retcode","0","addr",rsm_service_get_addr(respool->rsmserv),
            "totalload",totalload_str,"onload",onload_str,"tsload",tsload_str,
            "leftload",leftload_str,"cpu",cpu_str,"mem",mem_str,
            "pluginversion",pluginver_str,NULL);
    
    return 0;

}

int rsm_resource_pool_sync(rsm_resource_pool*respool,const cJSON*pjson,cJSON**retjson)
{
    
    int ret;
	rsm_resource_t*ps=NULL;

    return_val_if_fail(respool!=NULL&&pjson!=NULL,-1);



/////////////////////
    char*rserialno=NULL;

    ret=rsm_json_fill(pjson,"serialno",&rserialno,NULL);
    CHK_EXPR(ret!=1,"No serialno field found..")
        RSM_LOG_WARN("No `serialno' Field Found(%p)..",rserialno);

    END_CHK_EXPR

    int totalidx=respool->maxidx-respool->startidx+1;
//    char*idxarray=calloc(totalidx,sizeof(char));
    RSM_LOG_MSG("Before Statistic(total:%d) .....",totalidx);
    char idxarray[512]={0,};
    int num=rsm_resource_pool_statistic_busy(respool,idxarray,512);
    CHK_EXPR(num<0,"idxarray too small..")
        num=512;
        RSM_LOG_WARN("[idxarray] is Out of Buffer.....");
    END_CHK_EXPR
    RSM_LOG_MSG("After Statistic(inuse:%d) .....",num);

    char outidx[512*4]={0,};
    int i;
    for(i=0;i<num;i++){
        rsm_snprintf_append(outidx,sizeof outidx,"%d:",idxarray[i]);
    }

    i=strlen(outidx);
    if(i>0)
        outidx[i-1]=0;//delete lastest `:' sign
    

    const char* base=respool->config->vncms_keyport;

    char bnum[4];
    snprintf(bnum,sizeof bnum,"%d",num);

    if(retjson){
        if(rserialno)
            *retjson=rsm_get_json_cmd(RSM_CMD_SYNC,"total",bnum,"indexbase",base,"index",outidx,"serialno",rserialno,NULL);
        else
            *retjson=rsm_get_json_cmd(RSM_CMD_SYNC,"total",bnum,"indexbase",base,"index",outidx,NULL);
    }


    return num;

}


//TODO
rsm_resource_t*rsm_resource_pool_chgcfg(rsm_resource_pool*respool,const cJSON*pjson,cJSON**retjson)
{

}


rsm_resource_t*rsm_resource_pool_drop(rsm_resource_pool*respool,rsm_resource_t* ps)
{
    char sbuff[128];
    char rbuff[128]={0,};
    cJSON*act_json;

    act_json=vncms_get_json_action(VNCMS_ACT_RESET,NULL);
    
    vncms_make_json_msg(act_json,sbuff,sizeof sbuff );
    cJSON_Delete(act_json);
    rsm_send_to_vncms(ps,sbuff);//,strlen(sbuff));

    //release given index
    //clean up 
    int ret;
    ret=_respool_res_busy2free(respool,ps);
    if(ret<0){
        RSM_LOG_DEBUG("Move Resource From 'Busy' to 'Free' Failed...");
    }
    _rsm_resource_pool_reset_resource(respool,ps);


    return ps;
}





rsm_resource_t*rsm_resource_pool_get_resource_by_index(rsm_resource_pool*respool,int index)
{

    return_val_if_fail(respool!=NULL,NULL);
    return_val_if_fail(index>=respool->startidx&&index<=respool->maxidx,NULL);

    return respool->revindex[index];

}




//for http server;
inline int rsm_resource_pool_check_index(rsm_resource_pool*pool,int index,rsm_resource_t**ps)
{


    int ret=0;
    *ps=NULL;

    if(index<=0&&index>pool->maxidx){
        goto exit;
    }
    *ps=pool->revindex[index];

    if((*ps)->status==RES_BUSY)
        ret=1;
    else
        ret=0;

exit:


    return ret;

}


inline int rsm_resource_pool_get_free_num(rsm_resource_pool*pool)
{
   
    rsm_resource_t*ps;
    int num=0;
    int i;   
    for(i=pool->startidx;i<=pool->maxidx;i++){
        ps=pool->revindex[i];
        //free+pre
        if(ps->status==RES_FREE||ps->status==RES_PRE){
            num++;
        }
    }
    return num;
}

inline int rsm_resource_pool_get_busy_num(rsm_resource_pool*pool)
{
    rsm_resource_t*ps;
    int num=0;
    int i;   
    for(i=pool->startidx;i<=pool->maxidx;i++){
        ps=pool->revindex[i];
        if(ps->status==RES_BUSY){
            num++;
        }
    }
    return num;
   
}


inline int rsm_resource_pool_get_num(rsm_resource_pool*pool,int*freenum,int*busynum,int*prenum)
{
   
    rsm_resource_t*ps;
    int total=0;
    int fnum=0;
    int bnum=0;
    int pnum=0;
    int i;   

    for(i=pool->startidx;i<=pool->maxidx;i++){
        ps=pool->revindex[i];
        //free+pre
        if(ps->status==RES_FREE){
            fnum++;
        }else if(ps->status==RES_PRE){
            pnum++;
        }else if(ps->status==RES_BUSY){
            bnum++;
        }
        total++;
    }

    if(freenum)
        *freenum=fnum;
    if(busynum)
        *busynum=bnum;
    if(prenum)
        *prenum=pnum;

    return total;
}


//for VNCSYNC
inline int rsm_resource_pool_statistic_busy(rsm_resource_pool*pool,char*numarray,int arraysiz)
{
   
    rsm_resource_t*ps;
    int cnt=0;

    int i;   
    for(i=pool->startidx;i<=pool->maxidx;i++){
        ps=pool->revindex[i];
        if(ps && ps->status==RES_BUSY){
            if(cnt>=arraysiz){
                cnt=-1;
                break;
            }
            numarray[cnt++]=ps->index;
        }
    }

    return cnt;
}

inline int rsm_resource_pool_get_stream_num(rsm_resource_pool*pool)
{
   
    rsm_resource_t*ps;
    int cnt=0;


    int i;   
    for(i=pool->startidx;i<=pool->maxidx;i++){
        ps=pool->revindex[i];
        if(ps && ps->status==RES_BUSY&& ps->avstatus==AVSTATUS_ON){
            cnt++;
        }
    }


    return cnt;
}


cJSON*rsm_resource_pool_get_reslists(rsm_resource_pool*pool,int *nlist)
{
    
 
    rsm_resource_t*ps;
    int cnt=0;

    cJSON*retjson=cJSON_CreateObject();
    cJSON*tjson=NULL;
    cJSON*ijson=NULL;

    int i;   
    for(i=pool->startidx;i<=pool->maxidx;i++){
        ps=pool->revindex[i];
        if(ps->status!=RES_BUSY)
            continue;

        cnt++;
    }
    char listnum_str[4];
    snprintf(listnum_str,sizeof listnum_str,"%d",cnt);
    cJSON_AddStringToObject(retjson,"cmd","getreslist");
    cJSON_AddStringToObject(retjson,"retcode","0");
    cJSON_AddStringToObject(retjson,"listnum",listnum_str);


    char vncport_str[8];
    char keyport_str[8];
    char bitrate_str[16];
    char dstport_str[8];
    char startdate_str[16];

    cJSON*ajson=cJSON_CreateArray();

    for(i=pool->startidx;i<=pool->maxidx;i++){
        ps=pool->revindex[i];
        if(ps->status!=RES_BUSY)
            continue;

        ijson=cJSON_CreateObject();
        cJSON_AddStringToObject(ijson,"resid",ps->resid);
    
        snprintf(vncport_str,sizeof vncport_str,"%d",atoi(pool->config->vncms_serverport)+i);
        cJSON_AddStringToObject(ijson,"vncport",vncport_str);

        snprintf(keyport_str,sizeof keyport_str,"%d",atoi(pool->config->vncms_keyport)+i);
        cJSON_AddStringToObject(ijson,"keyport",keyport_str);
        
        snprintf(bitrate_str,sizeof bitrate_str,"%d",atoi(pool->config->rsm_enc_video_rate)*1024*1024);
        cJSON_AddStringToObject(ijson,"bitrate",bitrate_str);

        cJSON_AddStringToObject(ijson,"dstip",ps->iip);

        snprintf(dstport_str,sizeof dstport_str,"%d",ps->iport);
        cJSON_AddStringToObject(ijson,"dstport",dstport_str);

        strftime(startdate_str,sizeof startdate_str,"%Y%m%d%H%M%S",localtime(&ps->start_ts));
        cJSON_AddStringToObject(ijson,"startdate",startdate_str);

        cJSON_AddItemToArray(ajson,ijson);

        cnt++;
    }

    cJSON_AddItemToObject(retjson,"lists",ajson);
    




    if(nlist)
        *nlist=cnt;

    return retjson;

}




