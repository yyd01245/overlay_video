
#include<stdio.h>
#include<stdlib.h>
#include"rsm_net.h"


#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<signal.h>
#include<pthread.h>
#include<fcntl.h>

#include"rzut/chks.h"
#include"rzut/defs.h"


//#include"rsm_log.h"


#if 1
int connect_timeout(int fd,const struct sockaddr*addr,socklen_t addrlen,struct timeval to){

    int ret;
    int val;
    socklen_t lon;
//1. make socket nonblock
    long flag=fcntl(fd,F_GETFL,NULL);
    CHK_EXPRe(flag<0,"Fcntl() Fail")
        return -1;
    END_CHK_EXPRe

    flag|=O_NONBLOCK;
    fcntl(fd,F_SETFL,flag);

//2. connect..
    ret=connect(fd,addr,addrlen);
    if(ret<0) {
        if(errno==EINPROGRESS){
            //need to wait

            fd_set wset;
            int maxfd;
            FD_ZERO(&wset);
            FD_SET(fd,&wset);
            maxfd=fd+1;
            ret=select(maxfd,NULL,&wset,NULL,&to);
            if(ret>0){
                lon=sizeof(val); 
                getsockopt(fd,SOL_SOCKET,SO_ERROR,&val,&lon) ;
                if(val){
                    fprintf(stderr,"Error in connect():%d:{%s}",val,strerror(errno));
                    return -2;
                }
            }else{
                return -4;//select failed
            }

        }else{
            return -3;//fail with other error;
        }

    }

    flag=fcntl(fd,F_GETFL,NULL);
    flag&=(~O_NONBLOCK);
    fcntl(fd,F_SETFL,flag);


    return 0;

}

#endif



rsm_httplistener_t*rsm_httplistener_new(const char*ipstr,int port)
{

    return_val_if_fail(port>0,NULL);

    rsm_httplistener_t*pr=calloc(1,sizeof(rsm_httplistener_t));


    int ret;

    if(!ipstr)
        ipstr="0.0.0.0";

    pr->polladdr.sin_family=AF_INET;
    ret=inet_pton(AF_INET,ipstr,&pr->polladdr.sin_addr);
    CHK_RUNe(ret<0,"inet_pton() Failed..",goto fail0);

    pr->polladdr.sin_port=htons(port);

    pr->pollfd=socket(PF_INET,SOCK_STREAM|SOCK_CLOEXEC,0);
    CHK_RUNe(pr->pollfd<0,"Socket() Failed..",goto fail0);

    int val=1;
    ret=setsockopt(pr->pollfd,SOL_SOCKET,SO_REUSEADDR,&val,sizeof(val));
    CHK_EXPRe_ONLY(ret<0,"Set FD Reuseable.");
#if 1
    int flags;
    flags = fcntl(pr->pollfd, F_GETFL, NULL);
    CHK_EXPRe_ONLY(flags<0,"Get FD FL.");
    ret=fcntl(pr->pollfd,F_SETFL,flags|O_NONBLOCK);
    CHK_EXPRe_ONLY(ret<0,"Set FD Nonblock.");
#endif

#if 0
    struct timeval timeout={0,50000};//50ms
    setsockopt(sender->sock_fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof timeout);
#endif

    ret=bind(pr->pollfd,(struct sockaddr*)&pr->polladdr,sizeof(pr->polladdr));
    CHK_RUNe(ret<0,"Bind() Failed..",goto fail1);

    ret=listen(pr->pollfd,MAXQ);
    CHK_RUNe(ret<0,"Listen() Failed..",goto fail1);


    pr->allfds[0].fd=pr->pollfd;
    pr->allfds[0].events=POLLRDNORM;

    pr->maxfd=1;

    int i;
    for(i=1;i<MAXFD;i++){
        pr->allfds[i].fd=-1;
    }


    return pr;

fail1:
    close(pr->pollfd);

fail0:
    free(pr);

    return NULL;
}

void rsm_httplistener_free(rsm_httplistener_t*pr){

    return_if_fail(pr!=NULL);
    close(pr->allfds[0].fd);
    free(pr);

}


int rsm_httplistener_listen(rsm_httplistener_t*pr)
{
    int ret; 
    int nready;

    return_val_if_fail(pr!=NULL,-1);

    while(1){
        int i;
        int connfd;
        struct sockaddr_in cliaddr;
        socklen_t clilen=sizeof(cliaddr);


        nready=poll(pr->allfds,MAXFD,-1) ;   
        CHK_EXPRe(nready<0,"poll()  Continue..")
                continue;
        END_CHK_EXPRe
//            fprintf(stderr,"\n\033[32m Poll NReady:%d\033[0m\n",nready);

        if(pr->allfds[0].revents&POLLRDNORM){
            
            connfd=accept(pr->pollfd,(struct sockaddr*)&cliaddr,&clilen);
//            CHK_EXPRe(connfd<0,"accept().")
//                continue;
//            END_CHK_EXPRe
//            fprintf(stderr,"\033[32m-%d)accepted(%d)\033[0m\n",pr->pollfd,connfd);
            
            for(i=1;i<MAXFD;i++){
                if(pr->allfds[i].fd<0){
                    pr->allfds[i].fd=connfd;
                    pr->allfds[i].events=POLLRDNORM;
                    break;
                }
            }

            if(i>pr->maxfd)
                pr->maxfd=i;

            if(--nready<=0)
                continue;//no more requests;

        }

        int cfd;
        short cre;
        for(i=1;i<=pr->maxfd;i++){
            int nr;
            cfd=pr->allfds[i].fd;
            cre=pr->allfds[i].revents;
            if(cfd<0)
                continue;///skip
//            fprintf(stderr,"\t\033[32m :%d(%d)\t\033[0m",cfd,cre);

            if(cre&POLLNVAL){
//                fprintf(stderr,"XXXXXX closed..");
                pr->allfds[i].fd=-1;
                continue;
            }
#if 0
            if(cre&(POLLERR|POLLHUP)){
            
                fprintf(stderr,"XXXXXX Error..");
                close(cfd); 
                pr->allfds[i].fd=-1;
                continue;
            }
#endif
            if(cre&(POLLRDNORM|POLLERR)){
//            if(cre&(POLLRDNORM)){
//                fprintf(stderr,"\033[32m To Work\033[0m\n");
                ret=pr->worker_cb(cfd,pr->worker_data);
                if(ret==CONN_CLOSE){
                    close(cfd); 
                    pr->allfds[i].fd=-1;
                }

                if(--nready<=0)
                    break;//no more requests;

            }

        }

    }

    return 0;
}


void rsm_httplistener_set_worker(rsm_httplistener_t*pr,evtworker_cb cb,void*ud)
{
    return_if_fail(pr!=NULL);

    pr->worker_cb=cb;
    pr->worker_data=ud;

}

///////////////////////////////////////////////////////////


rsm_netlistener_t*rsm_netlistener_new(const char*ipstr,int port)
{

    return_val_if_fail(port>0,NULL);

    rsm_netlistener_t*pr=calloc(1,sizeof(rsm_netlistener_t));

//    pr->recv_buffsiz=MAXBUFFSIZ;
//    pr->recv_buff=calloc(pr->recv_buffsiz,sizeof(char));

    int ret;

    if(!ipstr)
        ipstr="0.0.0.0";

    pr->servaddr.sin_family=AF_INET;
    ret=inet_pton(AF_INET,ipstr,&pr->servaddr.sin_addr);
    CHK_RUNe(ret<0,"inet_pton() Failed..",goto fail0);

    pr->servaddr.sin_port=htons(port);

    pr->servfd=socket(PF_INET,SOCK_STREAM|SOCK_CLOEXEC,0);
    CHK_RUNe(pr->servfd<0,"Socket() Failed..",goto fail0);

    int val=1;
    ret=setsockopt(pr->servfd,SOL_SOCKET,SO_REUSEADDR,&val,sizeof(val));
    CHK_EXPRe_ONLY(ret<0,"Set FD Reuseable.");

//    struct timeval timeout={0,500000};//0.5s
////    setsockopt(pr->servfd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof timeout);
//    setsockopt(pr->servfd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof timeout);


    ret=bind(pr->servfd,(struct sockaddr*)&pr->servaddr,sizeof(pr->servaddr));
    CHK_RUNe(ret<0,"Bind() Failed..",goto fail1);


    ret=listen(pr->servfd,MAXQ);
    CHK_RUNe(ret<0,"Listen() Failed..",goto fail1);


    return pr;

fail1:
    close(pr->servfd);

fail0:
    free(pr);

    return NULL;
}



void rsm_netlistener_free(rsm_netlistener_t*pr){

    return_if_fail(pr!=NULL);
    close(pr->servfd);
    free(pr);

}


int rsm_netlistener_listen(rsm_netlistener_t*pr)
{
    int ret; 
    int nready;

    return_val_if_fail(pr!=NULL,-1);

    int i;
    int connfd;
    struct sockaddr_in cliaddr;
    socklen_t clilen=sizeof(cliaddr);

    while(1){
            
        connfd=accept(pr->servfd,(struct sockaddr*)&cliaddr,&clilen);
        CHK_EXPRe(connfd<0,"Accept() Failed")

            continue;
        END_CHK_EXPRe

        struct timeval timeout={0,150000};//150ms
//        setsockopt(connfd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof timeout);
        setsockopt(connfd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof timeout);
    
//        fprintf(stderr,"[%p]:(%d)++++++++++++++++++++++++++++\n",pr,connfd);

        ret=pr->worker_cb(connfd,pr->worker_data);
        if(ret==CONN_CLOSE){
            close(connfd); 
        }
            
    }

    return 0;
}


void rsm_netlistener_set_worker(rsm_netlistener_t*pr,evtworker_cb cb,void*ud)
{
    return_if_fail(pr!=NULL);

    pr->worker_cb=cb;
    pr->worker_data=ud;

}


///////////////////////////////////////////////////////////





rsm_netconn_t*rsm_netconn_new(const char*ip,int port)
{

    int ret;
    return_val_if_fail((NULL!=ip && port>0),NULL);
    rsm_netconn_t*conn=calloc(1,sizeof(rsm_netconn_t));
    CHK_RUN(!conn,"Allocate EventNode.",
            return NULL);

    ret=inet_pton(AF_INET,ip,&conn->peer_addr.sin_addr);
    CHK_RUN(ret<=0,"INET_PTON",
            goto cleanup0);

    conn->peer_addr.sin_family=AF_INET;
    conn->peer_addr.sin_port=htons(port);
#if 0
    conn->conn_fd=socket(PF_INET,SOCK_STREAM,0);
    CHK_RUNe(conn->conn_fd<0,"Make Socket",
            goto cleanup0);

    struct timeval timeout={2,0};//3s
//    setsockopt(conn->conn_fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof timeout);
    setsockopt(conn->conn_fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof timeout);
#endif

    return conn;
cleanup0:
    free(conn);
    return NULL;

}

#if 0
int rsm_netconn_connect(rsm_netconn_t*conn)
{
    int ret=0; 
    return_val_if_fail(NULL!=conn,-1);

    ret=connect(conn->conn_fd,(struct sockaddr*)&conn->peer_addr,sizeof(conn->peer_addr));
    CHK_RUNe(ret<0,"Connect to Server..",
            ret=-2);
    return ret;

}

#endif


void rsm_netconn_free(rsm_netconn_t*conn)
{

    return_if_fail(NULL!=conn);

    close(conn->conn_fd);
    free(conn);

}


int rsm_netconn_shot(rsm_netconn_t*conn,void*buff,int len,void*obuff,int olen)
{
    int rv;
    return_val_if_fail(conn!=NULL&&buff!=NULL&&len>0,-1);
//    fprintf(stderr,"<<%d>>",conn->conn_fd);

#if 1
    conn->conn_fd=socket(PF_INET,SOCK_STREAM|SOCK_CLOEXEC,0);
    CHK_RUNe(conn->conn_fd<0,"Make Socket",
            rv=-5;
            goto fail0);


    struct timeval timeout={0,150000};//150ms
//    setsockopt(conn->conn_fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof timeout);
    setsockopt(conn->conn_fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof timeout);
#endif

    //TODO add timeout stuff for connect, through "select(),EINPROGRESS,O_NONBLOCK"
    rv=connect(conn->conn_fd,(struct sockaddr*)&conn->peer_addr,sizeof(conn->peer_addr));
    CHK_RUNe(rv<0,"Connect to Server..",
            rv=-2;
            goto fail);

    rv=send(conn->conn_fd,buff,len,MSG_DONTWAIT|MSG_NOSIGNAL);
    CHK_RUNe(rv<0,"Send to Server..",
            rv=-3;
            goto fail);

    rv=recv(conn->conn_fd,obuff,olen,0);
    CHK_RUNe(rv<0,"Recv from Server..",
            rv=-4;
            goto fail);


fail:
    close(conn->conn_fd);
fail0:
    return rv;
}




///////////////////////////////////////////
///////////UDP/////////////////////////////
///////////////////////////////////////////


rsm_netbinder_t*rsm_netbinder_new(const char*ipstr,int port)
{

    int ret;
    return_val_if_fail((NULL!=ipstr && port>0),NULL);
    rsm_netbinder_t*binder=calloc(1,sizeof(rsm_netbinder_t));
    CHK_RUN(!binder,"Allocate EventNode.",
            goto err0);

    ret=inet_pton(AF_INET,ipstr,&binder->bind_addr.sin_addr);
    CHK_RUN(ret<=0,"INET_PTON",
            goto err1);

    binder->bind_addr.sin_family=AF_INET;
    binder->bind_addr.sin_port=htons(port);


    binder->sock_fd=socket(PF_INET,SOCK_DGRAM|SOCK_CLOEXEC,0);
    CHK_RUNe(binder->sock_fd<0,"Make Socket",
            goto err1);

    int val=1;
    ret=setsockopt(binder->sock_fd,SOL_SOCKET,SO_REUSEADDR,&val,sizeof(val));
    CHK_EXPRe_ONLY(ret<0,"Set FD Reuseable.");

//    struct timeval timeout={0,500000};//0.5s
//    setsockopt(binder->sock_fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof timeout);
//    setsockopt(binder->sock_fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof timeout);


    ret=bind(binder->sock_fd,(struct sockaddr*)&binder->bind_addr,sizeof(binder->bind_addr));
    CHK_RUNe(ret<0,"Bind Socket",
            goto err2);

    return binder;

err2:
    close(binder->sock_fd);

err1:
    free(binder);

err0:
    return NULL;

}


void rsm_netbinder_free(rsm_netbinder_t*binder)
{
    return_if_fail(binder!=NULL);

    close(binder->sock_fd);

    free(binder);

}


int rsm_netbinder_recv(rsm_netbinder_t*binder,void*buff,size_t siz)
{
    int ret;

    socklen_t clilen=sizeof(binder->cliaddr);
    ret=recvfrom(binder->sock_fd,buff,siz,0,(struct sockaddr*)&binder->cliaddr,&clilen);
//    binder->recv_len=ret;
    CHK_EXPRe_ONLY(ret<0,"recvfrom UDP client Failed..");

    return ret;
}



int rsm_netbinder_reply(rsm_netbinder_t*binder,void*buff,size_t buffsiz)
{
    int ret;

    ret=sendto(binder->sock_fd,buff,buffsiz,0,(struct sockaddr*)&binder->cliaddr,sizeof(binder->cliaddr));
    CHK_EXPRe_ONLY(ret<0,"Replay <sendto()> Failed.");

    return ret;
}



rsm_netsender_t*rsm_netsender_new(const char*ipstr,int port)
{

    int ret;
    return_val_if_fail((NULL!=ipstr && port>0),NULL);
    rsm_netsender_t*sender=calloc(1,sizeof(rsm_netsender_t));
    CHK_RUN(!sender,"Allocate EventNode.",
            goto err0);

    ret=inet_pton(AF_INET,ipstr,&sender->serv_addr.sin_addr);
    CHK_RUN(ret<=0,"INET_PTON",
            goto err1);

    sender->serv_addr.sin_family=AF_INET;
    sender->serv_addr.sin_port=htons(port);

    sender->sock_fd=socket(PF_INET,SOCK_DGRAM|SOCK_CLOEXEC,0);
    CHK_RUNe(sender->sock_fd<0,"Make Socket",
            goto err1);

    //0420:disable timeout ,to eliminate 1833 error
//    struct timeval timeout={0,900000};//0.9s
//    setsockopt(sender->sock_fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof timeout);

    return sender;


err1:
    free(sender);

err0:
    return NULL; 

}


void rsm_netsender_free(rsm_netsender_t*sender)
{
    
    return_if_fail(sender!=NULL);

    close(sender->sock_fd);

    free(sender);
}



int rsm_netsender_send(rsm_netsender_t*sender,void*buff,size_t len)
{

    return_val_if_fail(sender!=NULL,-1);
    return_val_if_fail(buff!=NULL,-1);
    return_val_if_fail(len>0,-1);

    int rv=sendto(sender->sock_fd,buff,len,MSG_NOSIGNAL,
            (struct sockaddr*)&sender->serv_addr,sizeof(sender->serv_addr));
    CHK_EXPRe_ONLY(rv<0,"Send <sendto()> Failed.");

    return rv;

}

int rsm_netsender_recv(rsm_netsender_t*sender,void*buff,size_t siz)
{
    int ret;

    ret=recvfrom(sender->sock_fd,buff,siz,0,NULL,NULL);
    CHK_EXPRe_ONLY(ret<0,"Recv <recvfrom()> Failed.");

    return ret;

}


int rsm_netsender_shot(rsm_netsender_t*sender,void*buff,size_t len,void* obuff,size_t olen)
{
   
    return_val_if_fail(sender!=NULL,-1);
    return_val_if_fail(buff!=NULL,-1);
    return_val_if_fail(len>0,-1);
    return_val_if_fail(obuff!=NULL,-1);
    return_val_if_fail(olen>0,-1);

    int rv;

//    int ret=connect(sender->sock_fd,(struct sockaddr*)&sender->serv_addr,sizeof(sender->serv_addr));

    rv=sendto(sender->sock_fd,buff,len,MSG_NOSIGNAL|MSG_DONTWAIT,
            (struct sockaddr*)&sender->serv_addr,sizeof(sender->serv_addr));
    CHK_RUNe(rv<0,"Shot:sendto() Failed.",
            rv=-2;
            goto fail0);

    rv=recv(sender->sock_fd,obuff,olen,0);
    CHK_RUNe(rv<0,"Shot:recvfrom() Failed.",
            rv=-4;
            goto fail0);


fail0:
    return rv;//received len 

    

}


/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
////UNIX DOMAIN SOCKET///////
/////////////////////////////////////////////////////////



rsm_netlbinder_t*rsm_netlbinder_new(const char*pathstr)
{
 
    int ret;
    return_val_if_fail((NULL!=pathstr),NULL);
    rsm_netlbinder_t*binder=calloc(1,sizeof(rsm_netlbinder_t));
    CHK_RUN(!binder,"Allocate EventNode.",
            goto err0);


    binder->bind_addr.sun_family=AF_LOCAL;
    strlcpy(binder->bind_addr.sun_path,pathstr,sizeof(binder->bind_addr));
    binder->addrpath=strdup(pathstr);

    binder->sock_fd=socket(PF_LOCAL,SOCK_DGRAM|SOCK_CLOEXEC,0);
    CHK_RUNe(binder->sock_fd<0,"Make Socket",
            goto err1);

    unlink(pathstr);

    ret=bind(binder->sock_fd,(struct sockaddr*)&binder->bind_addr,sizeof(binder->bind_addr));
    CHK_RUNe(ret<0,"Bind Socket",
            goto err2);

//    socklen_t clen=sizeof(binder->cli_addr);
//    getsockname(binder->sock_fd,(struct sockaddr*)&binder->cli_addr,&clen);

    return binder;

err2:
    close(binder->sock_fd);

err1:
    free(binder);

err0:
    return NULL;


}


void rsm_netlbinder_free(rsm_netlbinder_t*binder)
{
    return_if_fail(binder!=NULL);

    close(binder->sock_fd);
    unlink(binder->addrpath);
    free(binder->addrpath);

    free(binder);

}

int rsm_netlbinder_recv(rsm_netlbinder_t*binder,void*buff,size_t siz)
{
    int ret;

    socklen_t clilen=sizeof(binder->cli_addr);
    ret=recvfrom(binder->sock_fd,buff,siz,0,(struct sockaddr*)&binder->cli_addr,&clilen);
//    ret=recv(binder->sock_fd,buff,siz,0);
//    binder->recv_len=ret;
    CHK_EXPRe_ONLY(ret<0,"recvfrom Unix client Failed..");

    return ret;

}


int rsm_netlbinder_reply(rsm_netlbinder_t*binder,void*buff,size_t buffsiz)
{
    int ret;

    ret=sendto(binder->sock_fd,buff,buffsiz,0,(struct sockaddr*)&binder->cli_addr,sizeof(binder->cli_addr));
 //   ret=send(binder->sock_fd,buff,buffsiz,MSG_NOSIGNAL);
    CHK_EXPRe_ONLY(ret<0,"Replay <sendto()> Failed.");

    return ret;
}



rsm_netlsender_t*rsm_netlsender_new(const char*pathstr)
{

    int ret;
    return_val_if_fail((NULL!=pathstr),NULL);
    rsm_netlsender_t*sender=calloc(1,sizeof(rsm_netlsender_t));
    CHK_RUN(!sender,"Allocate EventNode.",
            goto err0);


    sender->serv_addr.sun_family=AF_LOCAL;
    strlcpy(sender->serv_addr.sun_path,pathstr,sizeof sender->serv_addr.sun_path);
    sender->addrpath=strdup(pathstr);

    sender->sock_fd=socket(PF_LOCAL,SOCK_DGRAM|SOCK_CLOEXEC,0);
    CHK_RUNe(sender->sock_fd<0,"Make Socket",
            goto err1);

    struct timeval timeout={0,100000};//100ms
    setsockopt(sender->sock_fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof timeout);
//    setsockopt(sender->sock_fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof timeout);

#if 0
    char clipath[128];
    snprintf(clipath,sizeof clipath,"%s_cli",pathstr);
    sender->sendaddr.sun_family=AF_LOCAL;
    strlcpy(sender->sendaddr.sun_path,clipath,sizeof sender->sendaddr.sun_path);

    unlink(clipath);
    ret=bind(sender->sock_fd,(struct sockaddr*)&sender->sendaddr,sizeof(sender->sendaddr));
    CHK_RUNe(ret<0,"Bind Socket",
            goto err2);
#endif

    return sender;

err2:
    close(sender->sock_fd);

err1:
    free(sender);

err0:
    return NULL; 



}


void rsm_netlsender_free(rsm_netlsender_t*sender)
{
    return_if_fail(sender!=NULL);
    close(sender->sock_fd);
    unlink(sender->addrpath);
    free(sender->addrpath);
    free(sender);
}

int rsm_netlsender_send(rsm_netlsender_t*sender,void*buff,size_t len)
{

    return_val_if_fail(sender!=NULL,-1);
    return_val_if_fail(buff!=NULL,-1);
    return_val_if_fail(len>0,-1);

    int rv=sendto(sender->sock_fd,buff,len,MSG_NOSIGNAL,
            (struct sockaddr*)&sender->serv_addr,sizeof(sender->serv_addr));
    CHK_EXPRe_ONLY(rv<0,"Send <sendto()> Failed.");

    return rv;


}

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
//


rsm_netbinders_t*rsm_netbinders_new(const char*ipstr,int port)
{

    int ret;
    return_val_if_fail((NULL!=ipstr && port>0),NULL);
    rsm_netbinders_t*binder=calloc(1,sizeof(rsm_netbinders_t));
    CHK_RUN(!binder,"Allocate EventNode.",
            goto err0);

    ret=inet_pton(AF_INET,ipstr,&binder->bind_addr.sin_addr);
    CHK_RUN(ret<=0,"INET_PTON",
            goto err1);

    binder->bind_addr.sin_family=AF_INET;
    binder->bind_addr.sin_port=htons(port);


    binder->sock_fd=socket(PF_INET,SOCK_DGRAM|SOCK_CLOEXEC,0);
    CHK_RUNe(binder->sock_fd<0,"Make Socket",
            goto err1);

    int val=1;
    ret=setsockopt(binder->sock_fd,SOL_SOCKET,SO_REUSEADDR,&val,sizeof(val));
    CHK_EXPRe_ONLY(ret<0,"Set FD Reuseable.");

//    struct timeval timeout={0,500000};//0.5s
//    setsockopt(binder->sock_fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof timeout);
//    setsockopt(binder->sock_fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof timeout);


    ret=bind(binder->sock_fd,(struct sockaddr*)&binder->bind_addr,sizeof(binder->bind_addr));
    CHK_RUNe(ret<0,"Bind Socket",
            goto err2);


    binder->tmpbuff_len=2048;
    binder->tmpbuff=calloc(1,binder->tmpbuff_len);

    return binder;

err2:
    close(binder->sock_fd);

err1:
    free(binder);

err0:
    return NULL;




}


void rsm_netbinders_free(rsm_netbinders_t*binder)
{
    return_if_fail(binder!=NULL);

    close(binder->sock_fd);

    free(binder->tmpbuff);

    free(binder);
}



int rsm_netbinders_recv(rsm_netbinders_t*binder,void*buff,size_t siz,unsigned long *oseq)
{
    int ret;

    socklen_t clilen=sizeof(binder->cliaddr);
    ret=recvfrom(binder->sock_fd,binder->tmpbuff,binder->tmpbuff_len,0,(struct sockaddr*)&binder->cliaddr,&clilen);
    CHK_EXPRe_ONLY(ret<0,"recvfrom Unix client Failed..");

    struct msg_head*head=(struct msg_head*)(binder->tmpbuff);
//    binder->sequencer=ntohl(head->msgseq); 
    *oseq=ntohl(head->msgseq);
    size_t msglen=ntohl(head->msglen);
//    fprintf(stderr,"[seq:%ld,msglen:%ld]\n",binder->sequencer,msglen);
    CHK_EXPR(msglen+sizeof*head!=ret,"Recv() Size Inconsistance..");
        fprintf(stderr,"Recv() Size(%ld),ret(%d) Inconsistance..",msglen,ret);
        return -6;
    END_CHK_EXPR


    memcpy(buff,binder->tmpbuff+sizeof(struct msg_head),msglen);
//    ((char*)buff)[msglen-1]='\0';

    return ret;

}



int rsm_netbinders_reply(rsm_netbinders_t*binder,void*buff,size_t buffsiz,unsigned long seq)
{
    int ret;

    struct msg_head*head=(struct msg_head*)(binder->tmpbuff);
    head->msgseq=htonl(seq);
    head->msglen=htonl(buffsiz);
//    fprintf(stderr,"msg seq:%lu,len:%zu\n",binder->sequencer,buffsiz);

    memcpy(binder->tmpbuff+sizeof(struct msg_head),buff,buffsiz);
//    ((char*)buff)[buffsiz]='\0';

    ret=sendto(binder->sock_fd,binder->tmpbuff,buffsiz+sizeof(struct msg_head),0,(struct sockaddr*)&binder->cliaddr,sizeof(binder->cliaddr));
    CHK_EXPRe_ONLY(ret<0,"Replay <sendto()> Failed.");

    return buffsiz;

}





rsm_netsenders_t*rsm_netsenders_new(const char*ipstr,int port)
{

    int ret;
    return_val_if_fail((NULL!=ipstr && port>0),NULL);
    rsm_netsenders_t*sender=calloc(1,sizeof(rsm_netsenders_t));
    CHK_RUN(!sender,"Allocate EventNode.",
            goto err0);

    ret=inet_pton(AF_INET,ipstr,&sender->serv_addr.sin_addr);
    CHK_RUN(ret<=0,"INET_PTON",
            goto err1);

    sender->serv_addr.sin_family=AF_INET;
    sender->serv_addr.sin_port=htons(port);

    sender->sock_fd=socket(PF_INET,SOCK_DGRAM|SOCK_CLOEXEC,0);
    CHK_RUNe(sender->sock_fd<0,"Make Socket",
            goto err1);

    struct timeval timeout={0,500000};//0.5s
    setsockopt(sender->sock_fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof timeout);


#define UDPOFFSET 5000

    struct sockaddr_in localaddr;
    localaddr.sin_addr.s_addr=INADDR_ANY;
    localaddr.sin_family=AF_INET;
    localaddr.sin_port=htons(port+UDPOFFSET);


    int val=1;
    ret=setsockopt(sender->sock_fd,SOL_SOCKET,SO_REUSEADDR,&val,sizeof(val));
    CHK_EXPRe_ONLY(ret<0,"Set FD Reuseable.");


    ret=bind(sender->sock_fd,(struct sockaddr*)&localaddr,sizeof(localaddr));
    CHK_RUNe(ret<0,"Bind Socket",
            goto err1);



    sender->tmpbuff_len=2048;
    sender->tmpbuff=calloc(1,sender->tmpbuff_len);

    return sender;

err1:
    free(sender);

err0:
    return NULL; 



}




void rsm_netsenders_free(rsm_netsenders_t*sender)
{
    return_if_fail(sender!=NULL);

    close(sender->sock_fd);

    free(sender->tmpbuff);
    free(sender);

}

int rsm_netsenders_send(rsm_netsenders_t*sender,void*buff,size_t len)
{
    return_val_if_fail(sender!=NULL,-1);
    return_val_if_fail(buff!=NULL,-1);
    return_val_if_fail(len>0,-1);

    sender->sequencer++;

    struct msg_head*head=(struct msg_head*)(sender->tmpbuff);
    head->msgseq=htonl(sender->sequencer);
    head->msglen=htonl(len);

    memcpy(sender->tmpbuff+sizeof(struct msg_head),buff,len);

    int nlen=len+sizeof(struct msg_head);

    int rv=sendto(sender->sock_fd,sender->tmpbuff,nlen,MSG_NOSIGNAL,
            (struct sockaddr*)&sender->serv_addr,sizeof(sender->serv_addr));
    CHK_EXPRe_ONLY(rv<0,"Send <sendto()> Failed.");

    return rv-sizeof(struct msg_head);

}





int rsm_netsenders_recv(rsm_netsenders_t*sender,void*buff,size_t siz)
{
    int ret;
    int cseq;
    socklen_t clilen=sizeof(sender->sendaddr);

    struct msg_head*head;

    do{
        ret=recvfrom(sender->sock_fd,sender->tmpbuff,sender->tmpbuff_len,0,(struct sockaddr*)&sender->sendaddr,&clilen);
        CHK_EXPRe_ONLY(ret<0,"recvfrom Unix client Failed..");

        head=(struct msg_head*)(sender->tmpbuff);
        cseq=ntohl(head->msgseq); 
    }while(cseq<sender->sequencer);
    
    CHK_RUN(cseq>sender->sequencer,"Error Sequencer??",
            return -1);
    //cseq==sequencer;

    size_t msglen=ntohl(head->msglen);
    CHK_EXPR(msglen+sizeof*head!=ret,"Recv() Size Inconsistance..");
        fprintf(stderr,"Recv() Size(%ld),ret(%d) Inconsistance..",msglen,ret);
        return -6;
    END_CHK_EXPR
//    CHK_EXPR_ONLY(msglen+sizeof*head!=ret,"Recv() Size Inconsistance..");


    memcpy(buff,sender->tmpbuff+sizeof(struct msg_head),msglen);

    return msglen;

}


int rsm_netsenders_shot(rsm_netsenders_t*sender,void*buff,size_t len,void *obuff,size_t olen)
{
     
    return_val_if_fail(sender!=NULL,-1);
    return_val_if_fail(buff!=NULL,-1);
    return_val_if_fail(len>0,-1);
    return_val_if_fail(obuff!=NULL,-1);
    return_val_if_fail(olen>0,-1);

    int rv;
    sender->sequencer++;

    struct msg_head*head=(struct msg_head*)sender->tmpbuff;
    head->msgseq=htonl(sender->sequencer);
    head->msglen=htonl(len);

//    int ret=connect(sender->sock_fd,(struct sockaddr*)&sender->serv_addr,sizeof(sender->serv_addr));

    memcpy(sender->tmpbuff+sizeof(struct msg_head),buff,len);

    rv=sendto(sender->sock_fd,sender->tmpbuff,sizeof(struct msg_head)+len,MSG_NOSIGNAL,(struct sockaddr*)&sender->serv_addr,sizeof(sender->serv_addr));
    
    fprintf(stderr,"Send :%lu(%zu)[%s]\n",sender->sequencer,head->msglen,(char*)sender->tmpbuff+sizeof*head);

    CHK_RUNe(rv<0,"Shot:sendto() Failed.",
            rv=-2;
            goto fail0);

    size_t readlen;
    unsigned long readseq=0;

    do{

        rv=recvfrom(sender->sock_fd,sender->tmpbuff,sender->tmpbuff_len,0,NULL,NULL);
        CHK_RUNe(rv<0,"Shot:recvfrom() Failed.",
                rv=-4;
                goto fail0);
//        head=(struct msg_head*)sender->tmpbuff;
        readseq=ntohl(head->msgseq);
        readlen=ntohl(head->msglen);
        fprintf(stderr,"read msgque :%lu[%s]\n",readseq,(char*)sender->tmpbuff+sizeof*head);

    }while(readseq<sender->sequencer);

    fprintf(stderr,"Recv :%lu(%zu)[%s]\n",readseq,readlen,(char*)sender->tmpbuff+sizeof*head);
#if 0
    CHK_RUN(readseq!=sender->sequencer,"Error Sequencer??",
        rv=-5;
        fprintf(stderr,"read seq:%lu,sender->seq:%lu\n",readseq,sender->sequencer);
        goto fail0);
#endif
    size_t msglen=ntohl(head->msglen);
    CHK_EXPR(msglen+sizeof*head!=rv,"Recv() Size Inconsistance..");
        fprintf(stderr,"Recv() Size(%ld),ret(%d) Inconsistance..",msglen,rv);
        rv=-6;
        goto fail0;
    END_CHK_EXPR


    memcpy(obuff,sender->tmpbuff+sizeof(struct msg_head),msglen);



fail0:
    return rv;//received len 

   

  

}









