
#include"rsm.h"
#include"rsm_msg.h"
#include"rzut/chks.h"
#include"rzut/defs.h"

#include"rsm_config.h"

#include<string.h>





static struct _cmd2str{
    cmd_t cmd;
    const char*str;
}cmd2str[]={
    {RSM_CMD_None,  "<None>"},
    {RSM_CMD_REG,   "vncregister"},
    {RSM_CMD_LOGIN, "vnclogin"},
    {RSM_CMD_LOGOUT,"vnclogout"},
    {RSM_CMD_PAUSE, "vncpause"},
    {RSM_CMD_EXIST, "vncexist"},
    {RSM_CMD_CHECK, "vnccheck"},
    {RSM_CMD_ALIVE, "vncalive"},
    {RSM_CMD_TIMEOUT,"vnctimeout"},
    {RSM_CMD_GETSERVERINFO,"getserverinfo"},
    {RSM_CMD_GETRESLIST,"getreslist"},
    {RSM_CMD_ALARMEVENT,"alarmevent"},
    {RSM_CMD_SYNC,"vncsync"},
    {RSM_CMD_Last,"<Last>"}
};


const char*rsm_cmd_to_str(cmd_t cmd){
    
    int i=0;
    int siz=N_ELEMENTS(cmd2str);
    const char*ret=NULL;

    for(i=0;i<siz;i++){
        if(cmd==cmd2str[i].cmd){
            ret=cmd2str[i].str;
            break;
        }
    }
    if(!ret)
        ret=cmd2str[RSM_CMD_None].str;
    return ret;
}

cmd_t rsm_str_to_cmd(const char*cmdstr){
    
    int i=0;
    int siz=N_ELEMENTS(cmd2str);
    cmd_t ret=RSM_CMD_None;

    for(i=0;i<siz;i++){
        if(!strcmp(cmdstr,cmd2str[i].str)){
            ret=cmd2str[i].cmd;
            break;
        }
    }
    return ret;
}




int rsm_make_json_cmd(const cJSON*json,char*buff,int bufsiz)
{
    int ret;
    char*jsonstr=cJSON_PrintUnformatted((cJSON*)json);
    ret=snprintf(buff,bufsiz,"%sXXEE",jsonstr);
    free(jsonstr);
    return ret;
}


cmd_t rsm_parse_json_cmd(char*msg,cJSON**retjson)
{
    cmd_t rcmd=RSM_CMD_None; 
    char*p = strstr(msg,"XXEE");
    CHK_RUN(!p,"Delimiter`XXEE` Not Found..",
            goto fail);

    *p='\0';//remove trailing XXEE


    cJSON*pjson=cJSON_Parse(msg);
    CHK_RUN(!pjson,"Parse CRSM Json Failed..",
            goto fail);


    cJSON*pit=cJSON_GetObjectItem(pjson,"cmd");
    CHK_RUN(!pit,"Field `CMD` Not Found..",
            cJSON_Delete(pjson);
            goto fail);
    
    rcmd=rsm_str_to_cmd(pit->valuestring);

    if(retjson)
        *retjson=pjson;
    else
        cJSON_Delete(pjson);

   
    return rcmd;

fail:

    if(retjson)
        *retjson=NULL;

    return RSM_CMD_None;
}


cJSON* rsm_get_json_cmd(cmd_t type,...)
{

    cJSON*pjson=cJSON_CreateObject();
    cJSON_AddStringToObject(pjson,"cmd",rsm_cmd_to_str(type));
    
    char*key,*val;

    va_list ap;
    va_start(ap,type);

    while(1){

        key=va_arg(ap,char*);
        if(!key)
            break;
        val=va_arg(ap,char*);
        if(!val)//missing value,
            break;

        cJSON_AddStringToObject(pjson,key,val);
    }
    va_end(ap);

    return pjson;

}





inline int cjson_get_value(const cJSON*node,const char* key,char**opstr){
   
    cJSON*pit=cJSON_GetObjectItem((cJSON*)node,key);
    if(!pit){
#if 1
        if(opstr)
            *opstr=NULL;
#else
        if(opstr)
            *opstr=strdup("<INVALID>");
#endif
        return -1;
    }

    if(opstr){
        *opstr=strdup(pit->valuestring);
        return 0;
    }
    return -2;
}

/*
usage int nok=rsm_json_fill(proot,"cmd",&pcmd,"resid",&presid,NULL);
expect nok==2
*/
int rsm_json_fill(const cJSON*pjson,...)
{
    int ret=0; 
    char*key;
    char**val;

    cJSON*p;

    va_list ap;
    va_start(ap,pjson);

    while(1){

        key=va_arg(ap,char*);
        if(!key)
            break;
        val=va_arg(ap,char**);
        if(!val)
            break;

        if(!cjson_get_value(pjson,key,val))
            ret++;
    }
    va_end(ap);

    return ret;//num of valid fields
}




const char* rsm_get_null_msg(void){

    static char retmsg[]="{}XXEE";
    return retmsg;

}







