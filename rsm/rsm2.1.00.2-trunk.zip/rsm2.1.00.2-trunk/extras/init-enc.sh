#!/bin/bash
#execute by root 
#for BLUELINK
/etc/init.d/dm816x start 63
