#!/bin/bash


RCLOCAL=/etc/init.d/rc.local
RCLOCAL=aa

sed  -i -e 's#[[:space:]]*/etc/init\.d/dmx816.*##' ${RCLOCAL}
sed  -i -e '$a\/etc/init.d/dmx816 start 63 #launch encode-card' ${RCLOCAL}
