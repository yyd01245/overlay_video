#!/bin/bash
#execute by root
#for vgl


get_gpubusid()
{
    local gpuits
    local busids

    if [ -e /proc/driver/nvidia/gpus/  ];then
        gpuits=/proc/driver/nvidia/gpus/* 
    else
        echo Can not find nVidia drivers! You must install nVidia proprietary drivers properly..
        return -1;
    fi

    busids=$(echo $gpuits |tr ' [[:lower:]]' '\n[[:upper:]]'|sed -n 's#.*:\([0-9A-F]*\):.*#\1#p')

    ids=
    for i in $busids;do
        ids+=$(echo "ibase=16; $i" |bc)" "
#        retids="$retids $ids"
    done

}


config_X(){

    local busids
    local preffix
    local id
    local file

    preffix='/etc/X11/xorg.conf.'
#    busids=$(get_gpubusid)

    busids=$*
    echo BUSIDS: $busids

    local i
    i=0
    for id in $busids;do
        file=$preffix$i
#        if [ ! -e $file ] ;then
             nvidia-xconfig --busid=PCI:$id:0:0 --use-display-device=None --force-generate --no-probe-all-gpus -o ${file}
#       fi
        ((i++))
    done
    ncores=$((i))
}

get_gpubusid

#echo -e $ids

config_X $ids

echo NCORES: $ncores

echo Stop Lightdm..

for((i=0;i<ncores;i++));do

#echo $i
#echo start X with specified configuration:$i
X -config /etc/X11/xorg.conf.$i :$i -sharevts &> /var/log/logX.$i &

done


