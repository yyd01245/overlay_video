#!/bin/bash

ulimit -c unlimited

echo 'core-%t(%s)' > /proc/sys/kernel/core_pattern
