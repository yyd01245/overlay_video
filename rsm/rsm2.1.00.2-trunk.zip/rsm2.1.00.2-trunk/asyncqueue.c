#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include"asyncqueue.h"
#include"rzut/chks.h"
#include"rzut/defs.h"

#include<unistd.h>
#include<signal.h>


/**
 *
 */

static que_nd_t*new_queue_node(void*data)
{
    que_nd_t*nd=(que_nd_t*)calloc(1,sizeof(que_nd_t));
    CHK_RUNe(nd==NULL,"Allocate Node.",
            return NULL);

    nd->carrier=data;

    return nd;
}


static void free_queue_node(que_nd_t*node)
{
    return_if_fail(node!=NULL);
    free(node);
}



// statically initialize a object
int async_que_init(async_que_t*que)
{
    return_val_if_fail(que!=NULL,-1);

    bzero(que,sizeof(async_que_t));

    pthread_mutex_init(&que->lock,NULL);
    pthread_cond_init(&que->notify,NULL);

    INIT_LIST_HEAD(&que->qhead);


    return 0;
}



async_que_t*async_que_new()
{

    async_que_t*que=(async_que_t*)calloc(1,sizeof(async_que_t));
    CHK_RUNe(que==NULL,"Allocate Queue.",
            return NULL) ;

    async_que_init(que);
    
    return que;
}


//int async_que_enque_full(async_que_t*que,void*ptr,clear_cb callback,void*cbarg )
//
int async_que_enque(async_que_t*que,void*ptr)
{
 
    return_val_if_fail(que!=NULL,-1);
    return_val_if_fail(ptr!=NULL,-2);

    CHK_RUN(que->freezed,"Frozen Queue.",
            return -3);
   
    que_nd_t*nd=new_queue_node(ptr);
    CHK_RUN(nd==NULL,"New Que Node.",
            return -4);

    pthread_mutex_lock(&que->lock);
    list_add_tail(&que->qhead,&nd->list);
    que->size++;
    pthread_mutex_unlock(&que->lock);
    pthread_cond_signal(&que->notify);
    
    return 0;

}





int async_que_try_deque(async_que_t*que,void**pptr)
{
    return_val_if_fail(que!=NULL,-1);
    return_val_if_fail(pptr!=NULL,-2);
    
    
    pthread_mutex_lock(&que->lock);
    if(list_empty(&que->qhead)||que->freezed){
        fprintf(stderr,"Empty Queue || Frozen..\n");
        goto fail;
    }
    
    struct list_head* pos=que->qhead.next;

    list_del(pos);
    que->size--;
   
    que_nd_t*qnd=list_entry(pos,que_nd_t,list);

    pthread_mutex_unlock(&que->lock);

    *pptr=qnd->carrier;

    free_queue_node(qnd);

    return 0;

fail:

    pthread_mutex_unlock(&que->lock);
    *pptr=NULL;

    return -3;

}



int async_que_deque(async_que_t*que,void**pptr)
{
    return_val_if_fail(que!=NULL,-1);
    return_val_if_fail(pptr!=NULL,-2);
    
    pthread_mutex_lock(&que->lock);
    while(list_empty(&que->qhead)||que->freezed){

        pthread_cond_wait(&que->notify,&que->lock);
    }
    
    struct list_head* pos=que->qhead.next;
    que_nd_t*qnd=list_entry(pos,que_nd_t,list);

    list_del(pos);
    que->size--;
  

    pthread_mutex_unlock(&que->lock);

    *pptr=qnd->carrier;

    free_queue_node(qnd);

    return 0;

}








static void async_que_print(async_que_t*que)
{

    if(list_empty(&que->qhead))
        return;

    que_nd_t*qnd;

    list_for_each_entry(qnd,&que->qhead,list){

        printf("(%d)>>{%s}<<\n",que->size,(char*)qnd->carrier);
    }

}



/*
int async_que_clear(async_que_t*que,clear_cb destroy)
{
    
    return_val_if_fail(que!=NULL,-1);
    return_val_if_fail(destroy!=NULL,-2);

    que_nd_t* pos;
    que_nd_t* savpos;

    pthread_mutex_lock(&que->lock);

    list_for_each_entry_safe(pos, savpos, &que->qhead, list){
       
        list_del(&pos->list);
        (*destroy)(pos,que);

        free_queue_node(pos);
        que->size--;
    }

    pthread_mutex_unlock(&que->lock);

    return 0;

}



static void direct_free(que_nd_t*nd,async_que_t*que){
    free(nd);
}

*/


int async_que_freeze(async_que_t*que)
{
    return_val_if_fail(que!=NULL,-1);

    que->freezed=1;

}

int async_que_thaw(async_que_t*que)
{
    return_val_if_fail(que!=NULL,-1);

    que->freezed=0;

}






int async_que_clear(async_que_t*que)
{
 
    return_val_if_fail(que!=NULL,-1);

    que_nd_t* pos;
    que_nd_t* savpos;

    pthread_mutex_lock(&que->lock);

    list_for_each_entry_safe(pos, savpos, &que->qhead, list){
       
        list_del(&pos->list);
        free_queue_node(pos);
        que->size--;
    }

    pthread_mutex_unlock(&que->lock);

    return 0;
}




void async_que_fini(async_que_t*que)
{
   
    int ret;

    ret=async_que_clear(que);
    CHK_EXPR_ONLY(ret<0,"Free Async Queue.");
    pthread_mutex_destroy(&que->lock);
    pthread_cond_destroy(&que->notify);

}


int async_que_free(async_que_t*que)
{
    int ret=0;
    return_val_if_fail(que!=NULL,-1);

    async_que_fini(que);

    free(que);

    return ret;
}




#if 0

async_que_t*queue;


void sighandler(int signo)
{
   
//    async_que_clear(queue);

    char*pcarrier;
    int rv=async_que_try_deque(queue,(void**)&pcarrier);
    if(rv<0)
        return;
    fprintf(stderr,"\033[31m >>>>[%s]\033[0m\n",pcarrier);
    free(pcarrier);

}



void* thr_deq(void*arg){


    char*pp;
    while(1){

        printf("=========\n");
        async_que_deque(queue,(void**)&pp);
        printf("[%s]",pp);
        free(pp);
    }



}




void* thr_enq(void*arg){

    int c=0;

    char buff[32];

    while(1){
        
        snprintf(buff,sizeof(buff),"%dHelo,Worl",c);

        char*p=strdup(buff);
        async_que_enque(queue,p);
        printf(":::%s\n",p);

//        async_que_print(queue);
        sleep(1);
        c++;
    }



}


int main()
{

    signal(SIGINT,sighandler);


    queue=async_que_new();

    pthread_t tid0;
    pthread_t tid1;

    int ret=pthread_create(&tid0,NULL,thr_enq,queue);
//    ret=pthread_create(&tid1,NULL,thr_deq,queue);



    pthread_join(tid0,NULL);
//    pthread_join(tid1,NULL);

    return 0;
}

#endif

