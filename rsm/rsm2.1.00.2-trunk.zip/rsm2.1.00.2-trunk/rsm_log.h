#ifndef _H_LOG_RSM_
#define _H_LOG_RSM_


#include<stdarg.h>
#include<stdio.h>

#include"asyncqueue.h"

typedef enum _log_level{

    LOG_LEVEL_INFO=1,
    LOG_LEVEL_DEBUG=2,
    LOG_LEVEL_MSG=3,
    LOG_LEVEL_WARN=4,
    LOG_LEVEL_ERROR=5,
    LOG_LEVEL_UNKNOW=6

}log_lv_t;



#define MAX_FILELEN 128



typedef void (*logging_func)(char*msg,void*data);


struct _rsm_log{

    int b_stderr;

    int log_filter;
    logging_func log_func;
    void*        log_data;

    pthread_t logthr;
    async_que_t msgq;
    int log_siz;
    int log_maxsiz;
    pthread_mutex_t lock;
    int date;
};

typedef struct _rsm_log rsm_log_t;



void rsm_log_set_filter(rsm_log_t*log,int lv);
void rsm_log_set_logging_func(rsm_log_t*log,logging_func func,void* data);
void rsm_log_reset_func(rsm_log_t*log,const char*filename);
void rsm_log_set_maxsize(rsm_log_t*log,int maxsize);

int rsm_log_init(rsm_log_t*log);
void rsm_log_fini(rsm_log_t*log);

void rsm_logv(rsm_log_t*log,int lv,const char*modname,const char*fmt,va_list ap);
void rsm_log(rsm_log_t*log,int lv,const char*modname,const char*fmt,...);



#ifdef _DEFAULT_
int rsm_log_init_default(const char*filename);
void rsm_log_fini_default();
void rsm_log_default(int lv,const char*modname,const char*fmt,...);
rsm_log_t*rsm_get_log();

#endif










#endif
