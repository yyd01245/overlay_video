#ifndef _H_VNCMS_MESSAGE_
#define _H_VNCMS_MESSAGE_

#include"cJSON/cJSON.h"


typedef enum{

    VNCMS_ACT_NONE=0,

    VNCMS_ACT_START_XVNC=1<<0,
    VNCMS_ACT_OPEN_WEBC=1<<1,
    VNCMS_ACT_OPEN_ENC=1<<2,
    VNCMS_ACT_OPEN_AUD=1<<3,
    VNCMS_ACT_OPEN_AVENC=VNCMS_ACT_OPEN_ENC|VNCMS_ACT_OPEN_AUD,
    VNCMS_ACT_SET_TIMEOUT=1<<5,

    VNCMS_ACT_STOP_XVNC=1<<8,
    VNCMS_ACT_CLOSE_WEBC=1<<9,
    VNCMS_ACT_CLOSE_ENC=1<<10,
    VNCMS_ACT_CLOSE_AUD=1<<11,
    VNCMS_ACT_CLOSE_AVENC=VNCMS_ACT_CLOSE_ENC|VNCMS_ACT_CLOSE_AUD,

    VNCMS_ACT_RESET=1<<13,
    VNCMS_ACT_Last=1<<14


}act_t;

typedef enum _report_t{

    VNCMS_NTF_NONE=0,
    VNCMS_NTF_TIMEOUT =1<<0,
    VNCMS_NTF_EXIT =1<<1,
    VNCMS_NTF_ALIVE =1<<2,
    VNCMS_NTF_ACT_REPLY =1<<3,
    VNCMS_NTF_PROC_EXIT =1<<4,
    VNCMS_NTF_CHROME_CHECK_SHOW=1<<5,
    VNCMS_NTF_Last =1<<10

}notif_t;


typedef enum _proc_type{

    PROC_TYPE_XVNC=1,
    PROC_TYPE_WEBC,
    PROC_TYPE_ENCODER,
    PROC_TYPE_AUDIO

}proc_t;


const char* vncms_get_action_str(act_t action);
const char* vncms_get_notify_str(notif_t notify);

act_t vncms_parse_json_action(const char*buff,cJSON**opjson);
cJSON* vncms_get_json_action(act_t type,...);

notif_t vncms_parse_json_notify(const char*buff,cJSON**opjson);
cJSON* vncms_get_json_notify(notif_t type,...);
cJSON* vncms_get_json_notify_action_reply(act_t act,int retcode,...);
cJSON* vncms_get_json_notify_proc_exit(proc_t type,int pid,int count,...);

int vncms_make_json_msg(cJSON*json,char*buff,int bufsiz);


#endif
