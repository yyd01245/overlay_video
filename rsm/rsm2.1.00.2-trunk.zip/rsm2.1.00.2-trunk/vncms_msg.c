#include<sys/types.h>
#include<stdlib.h>
#include<stdarg.h>
#include"vncms_msg.h"
#include"cJSON/cJSON.h"
#include"rzut/chks.h"
#include"rzut/defs.h"

#include"rsm_net.h"



static struct actstr{
    act_t type;
    const char*str;
}act2str[]={
    { VNCMS_ACT_NONE, "action-none"},

    { VNCMS_ACT_START_XVNC, "start-xvnc"},
    { VNCMS_ACT_OPEN_WEBC,"open-webc"},
    { VNCMS_ACT_OPEN_ENC,"open-enc"},
    { VNCMS_ACT_OPEN_AUD, "open-aud"},
    { VNCMS_ACT_OPEN_AVENC, "open-avenc"},
    { VNCMS_ACT_STOP_XVNC, "stop-xvnc"},
    { VNCMS_ACT_CLOSE_WEBC, "close-webc"},
    { VNCMS_ACT_CLOSE_ENC, "close-enc"},
    { VNCMS_ACT_CLOSE_AUD, "close-aud"},
    { VNCMS_ACT_CLOSE_AVENC, "close-avenc"},
    { VNCMS_ACT_SET_TIMEOUT,"set-timeout"},
    { VNCMS_ACT_RESET,"reset" },
    { VNCMS_ACT_Last,"action-last" }
};

static struct ntfstr{
    notif_t type;
    const char*str;
}ntf2str[]={
    {VNCMS_NTF_NONE,"notify-none"},
    {VNCMS_NTF_TIMEOUT,"timeout"},
    {VNCMS_NTF_EXIT,"exit"},
    {VNCMS_NTF_ALIVE,"alive"},
    {VNCMS_NTF_ACT_REPLY,"action-reply"},
    {VNCMS_NTF_PROC_EXIT,"proc-exit"},
    {VNCMS_NTF_CHROME_CHECK_SHOW,"chrome-check-show"},
    {VNCMS_NTF_Last,"notify-last"}
};



const char* vncms_get_action_str(act_t action)
{
    int i=0;
    int siz=N_ELEMENTS(act2str);
    const char*ret=NULL;

    for(i=0;i<siz;i++){
        if(action==act2str[i].type){
            ret=act2str[i].str;
            break;
        }
    }

    if(!ret)
        ret=act2str[VNCMS_ACT_NONE].str;

    return ret;

}

const char* vncms_get_notify_str(notif_t notify)
{
    int i=0;
    int siz=N_ELEMENTS(ntf2str);
    const char*ret=NULL;

    for(i=0;i<siz;i++){
        if(notify==ntf2str[i].type){
            ret=ntf2str[i].str;
            break;
        }
    }

    if(!ret)
        ret=ntf2str[VNCMS_NTF_NONE].str;

    return ret;

}

act_t vncms_str_to_action(const char*actionstr)
{
    int i=0;
    int siz=N_ELEMENTS(act2str);
    act_t ret=VNCMS_ACT_NONE;

    for(i=0;i<siz;i++){
        if(!strcmp(actionstr,act2str[i].str)){
            ret=act2str[i].type;
            break;
        }
    }
    return ret;
}

notif_t vncms_str_to_notify(const char*notifystr)
{
    int i=0;
    int siz=N_ELEMENTS(ntf2str);
    notif_t ret=VNCMS_NTF_NONE;

    for(i=0;i<siz;i++){
        if(!strcmp(notifystr,ntf2str[i].str)){
            ret=ntf2str[i].type;
            break;
        }
    }
    return ret;
}






act_t vncms_parse_json_action(const char*buff,cJSON**opjson)
{
    return_val_if_fail(buff!=NULL,VNCMS_ACT_NONE);

    act_t reta=VNCMS_ACT_NONE;
    cJSON*pjson=NULL;

    pjson=cJSON_Parse(buff);
    CHK_RUN(!pjson,"Parse Json Failed.",
            goto fail);

    cJSON*cit=cJSON_GetObjectItem(pjson,"action");
    CHK_RUN(!cit,"Field `action' Not Found..",
            cJSON_Delete(pjson);
            goto fail);

    reta=vncms_str_to_action(cit->valuestring);


    if(opjson)
        *opjson=pjson;
    else
        cJSON_Delete(pjson);

    return reta;

fail:
    
    if(opjson)
        *opjson=NULL;
    reta=VNCMS_ACT_NONE;
    return reta;
}



cJSON* vncms_get_json_action(act_t type,...)
{

    cJSON*pjson=cJSON_CreateObject();
    cJSON_AddStringToObject(pjson,"action",vncms_get_action_str(type));
    
    char*key,*val;

    va_list ap;
    va_start(ap,type);

    while(1){

        key=va_arg(ap,char*);
        if(!key)
            break;
        val=va_arg(ap,char*);
        if(!val)
            break;

        cJSON_AddStringToObject(pjson,key,val);
    }
    va_end(ap);

    return pjson;

}



notif_t vncms_parse_json_notify(const char*buff,cJSON**opjson)
{
    return_val_if_fail(buff!=NULL,VNCMS_NTF_NONE);

    notif_t retn=VNCMS_NTF_NONE;
    cJSON*pjson=NULL;

    pjson=cJSON_Parse(buff);
    CHK_RUN(!pjson,"Parse Json Failed.",
            goto fail);

    cJSON*cit=cJSON_GetObjectItem(pjson,"notify");
    CHK_RUN(!cit,"Field `notify' Not Found..",
            cJSON_Delete(pjson);
            goto fail);

    retn=vncms_str_to_notify(cit->valuestring);


    if(opjson)
        *opjson=pjson;
    else
        cJSON_Delete(pjson);

    return retn;

fail:

    if(opjson)
        *opjson=NULL;
    retn=VNCMS_NTF_NONE;
    return retn;

}

cJSON* vncms_get_json_notify(notif_t type,...)
{
    cJSON*pjson=cJSON_CreateObject();
    cJSON_AddStringToObject(pjson,"notify",vncms_get_notify_str(type));
    
    char*key,*val;

    va_list ap;
    va_start(ap,type);

    while(1){

        key=va_arg(ap,char*);
        if(!key)
            break;
        val=va_arg(ap,char*);
        if(!val)
            break;

        cJSON_AddStringToObject(pjson,key,val);
    }
    va_end(ap);

    return pjson;

}


cJSON* vncms_get_json_notify_action_reply(act_t act,int retcode,...)
{
    cJSON*pjson=cJSON_CreateObject();
    cJSON_AddStringToObject(pjson,"notify",vncms_get_notify_str(VNCMS_NTF_ACT_REPLY));
 

    cJSON_AddStringToObject(pjson,"action-name",vncms_get_action_str(act));

    char retcodestr[8];
    snprintf(retcodestr,sizeof(retcodestr),"%d",retcode);
    cJSON_AddStringToObject(pjson,"retcode",retcodestr);

   
    char*key,*val;

    va_list ap;
    va_start(ap,retcode);

    while(1){

        key=va_arg(ap,char*);
        if(!key)
            break;
        val=va_arg(ap,char*);
        if(!val)
            break;

        cJSON_AddStringToObject(pjson,key,val);
    }
    va_end(ap);

    return pjson;

}

const char*vncms_proc_to_str(proc_t t){
    switch(t){

        case PROC_TYPE_XVNC:
            return "bvbcs";
        case PROC_TYPE_WEBC:
            return "chrome";
        case PROC_TYPE_ENCODER:
            return "avencoder";
        case PROC_TYPE_AUDIO:
            return "audiorecord";
        default:
            return "unknown proc";
    }
}

cJSON* vncms_get_json_notify_proc_exit(proc_t type,int pid,int count,...)
{
    cJSON*pjson=cJSON_CreateObject();
    cJSON_AddStringToObject(pjson,"notify",vncms_get_notify_str(VNCMS_NTF_PROC_EXIT));
 
    char pid_str[12];
    char cnt_str[4];
    snprintf(pid_str,sizeof pid_str,"%d",pid);
    snprintf(cnt_str,sizeof cnt_str,"%d",count);

    cJSON_AddStringToObject(pjson,"pid",pid_str);
    cJSON_AddStringToObject(pjson,"proc",vncms_proc_to_str(type));
    cJSON_AddStringToObject(pjson,"count",cnt_str);
   
    char*key,*val;

    va_list ap;
    va_start(ap,count);

    while(1){

        key=va_arg(ap,char*);
        if(!key)
            break;
        val=va_arg(ap,char*);
        if(!val)
            break;

        cJSON_AddStringToObject(pjson,key,val);
    }
    va_end(ap);

    return pjson;

}





int vncms_make_json_msg(cJSON*json,char*buff,int bufsiz)
{
    int ret;
    char*jsonstr=cJSON_PrintUnformatted(json);
    ret=snprintf(buff,bufsiz,"%s",jsonstr);
    free(jsonstr);
    return ret;
}





