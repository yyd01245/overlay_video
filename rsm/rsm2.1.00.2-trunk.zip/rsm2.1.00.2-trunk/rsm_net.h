
#ifndef _H_NET_RSM_
#define _H_NET_RSM_


#define MAXQ 10


#define MAXBUFFSIZ 2048

#define MAXFD 100




#include<poll.h>
#include<sys/select.h>
#include<sys/socket.h>
#include<sys/un.h>

#include<netinet/in.h>
//#include"rzut/zlist.h"

#define CONN_ONCE 0
#define CONN_KEEP 1
#define CONN_FAIL -1
#define CONN_CLOSE -1

/*
 * FOR TCP
 *  return:
 *      0: Success, Connect Once,OR, Should be closed,After process.
 *      1: Success, not close.
 *     -1: Failed, Should close fd.
 * 
 */
typedef int (*evtworker_cb)(int fd,void*data);

typedef struct _poller{


    struct sockaddr_in polladdr;
    int pollfd;

    struct pollfd allfds[MAXFD];
    int maxfd; 

//    void*recv_buff;
//    size_t recv_buffsiz;

    evtworker_cb worker_cb;
    void*worker_data;

//    struct list_head clihead;

}rsm_httplistener_t;




typedef struct _listener{


    struct sockaddr_in servaddr;
    int servfd;


    evtworker_cb worker_cb;
    void*worker_data;


}rsm_netlistener_t;



struct _rsm_conn_event{
    
    int conn_fd;
    struct sockaddr_in peer_addr;
//    evtworker_cb worker_cb;
//    void* worker_data;
};

typedef struct _rsm_conn_event rsm_netconn_t;




rsm_netconn_t*rsm_netconn_new(const char*ip,int port);
//int rsm_netconn_reconnect(rsm_netconn_t*conn);

void rsm_netconn_free(rsm_netconn_t*conn);

int rsm_netconn_shot(rsm_netconn_t*conn,void*buff,int len,void*obuff,int olen);



rsm_netlistener_t*rsm_netlistener_new(const char*ip,int port);
void rsm_netlistener_free(rsm_netlistener_t*evt);
void rsm_netlistener_set_worker(rsm_netlistener_t*pr,evtworker_cb cb,void*ud);
int rsm_netlistener_listen(rsm_netlistener_t*evt);


rsm_httplistener_t*rsm_httplistener_new(const char*ip,int port);
void rsm_httplistener_free(rsm_httplistener_t*evt);
void rsm_httplistener_set_worker(rsm_httplistener_t*pr,evtworker_cb cb,void*ud);
int rsm_httplistener_listen(rsm_httplistener_t*evt);



//////////////////////////////////////////////////
//////////////////////////////////////////////////



typedef struct _udp_server rsm_netbinder_t;


struct _udp_server{

    int sock_fd;

    int bind_port;
    struct sockaddr_in bind_addr;
    struct sockaddr_in cliaddr;

};




typedef struct _udp_client rsm_netsender_t;


struct _udp_client{

    int sock_fd;

    int serv_port;
    struct sockaddr_in serv_addr;
    struct sockaddr_in sendaddr;

};



rsm_netbinder_t*rsm_netbinder_new(const char*ipstr,int port);
void rsm_netbinder_free(rsm_netbinder_t*binder);

int rsm_netbinder_recv(rsm_netbinder_t*binder,void*buff,size_t siz);
int rsm_netbinder_reply(rsm_netbinder_t*binder,void*buff,size_t buffsiz);





rsm_netsender_t*rsm_netsender_new(const char*ipstr,int port);
void rsm_netsender_free(rsm_netsender_t*sender);

int rsm_netsender_send(rsm_netsender_t*sender,void*buff,size_t len);
int rsm_netsender_recv(rsm_netsender_t*sender,void*buff,size_t siz);


int rsm_netsender_shot(rsm_netsender_t*sender,void*buff,size_t len,void *obuff,size_t olen);

////////////////////////////////////////////



typedef struct _local_server rsm_netlbinder_t;


struct _local_server{

    int sock_fd;
    char*addrpath;

    struct sockaddr_un bind_addr;
    struct sockaddr_un cli_addr;

};




typedef struct _local_client rsm_netlsender_t;


struct _local_client{

    int sock_fd;
    char*addrpath;

//    int serv_port;
    struct sockaddr_un serv_addr;
    struct sockaddr_un sendaddr;

};


rsm_netlbinder_t*rsm_netlbinder_new(const char*ipstr);
void rsm_netlbinder_free(rsm_netlbinder_t*binder);

int rsm_netlbinder_recv(rsm_netlbinder_t*binder,void*buff,size_t siz);
int rsm_netlbinder_reply(rsm_netlbinder_t*binder,void*buff,size_t buffsiz);




rsm_netlsender_t*rsm_netlsender_new(const char*ipstr);
void rsm_netlsender_free(rsm_netlsender_t*sender);

int rsm_netlsender_send(rsm_netlsender_t*sender,void*buff,size_t len);
//int rsm_netlsender_recv(rsm_netlsender_t*sender,void*buff,size_t siz);
//int rsm_netlsender_shot(rsm_netlsender_t*sender,void*buff,size_t len,void *obuff,size_t olen);





//////////////////////////////////////////////////
//////////////////////////////////////////////////


struct msg_head{

    unsigned long msgseq;
    size_t msglen;

};


typedef struct s_udp_server rsm_netbinders_t;


struct s_udp_server{

    int sock_fd;

    int bind_port;
    struct sockaddr_in bind_addr;
    struct sockaddr_in cliaddr;

    unsigned long sequencer;

    void*tmpbuff;
    int tmpbuff_len;

};




typedef struct s_udp_client rsm_netsenders_t;


struct s_udp_client{

    int sock_fd;
    int local_port;
    int serv_port;
    struct sockaddr_in serv_addr;
    struct sockaddr_in sendaddr;

    unsigned long sequencer;

    void*tmpbuff;
    int tmpbuff_len;
};



rsm_netbinders_t*rsm_netbinders_new(const char*ipstr,int port);
void rsm_netbinders_free(rsm_netbinders_t*binder);

int rsm_netbinders_recv(rsm_netbinders_t*binder,void*buff,size_t siz,unsigned long*oseq);
int rsm_netbinders_reply(rsm_netbinders_t*binder,void*buff,size_t buffsiz,unsigned long seq);





rsm_netsenders_t*rsm_netsenders_new(const char*ipstr,int port);
void rsm_netsenders_free(rsm_netsenders_t*sender);

int rsm_netsenders_send(rsm_netsenders_t*sender,void*buff,size_t len);
int rsm_netsenders_recv(rsm_netsenders_t*sender,void*buff,size_t siz);


int rsm_netsenders_shot(rsm_netsenders_t*sender,void*buff,size_t len,void *obuff,size_t olen);

////////////////////////////////////////////






#endif
