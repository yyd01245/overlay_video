
RSM's Command 
========================


## Send To RSM

```
{"cmd":<cmd>,.../*,"serialno":<serial>*/} 

    <cmd>::

    "vnclogin": (resid,)
    "vncpause": (resid,)
    "vnclogout":(resid,)

    "vncexist":
    "getserverinfo":
    "getreslist":

    "vncsync":


```


## Send To CRSM


```
{"cmd":<cmd>,.../*,"serialno":<serial>*/} 

    <cmd>::

    "vncregister":
    "vncalive":

    "vnctimeout": (resid,)
    "vnccheck": (resid,)

    "alarmevent":

```





