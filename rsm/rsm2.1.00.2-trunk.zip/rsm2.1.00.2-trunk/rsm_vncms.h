#ifndef _H_VNCMS_RSM_
#define _H_VNCMS_RSM_

#include"rsm_config.h"
#include"rsm_log.h"
#include"rsm_net.h"
#include"rsm_utils.h"
#include"vncms_msg.h"
#include"rsm_keyutils.h"
#include"eventworker.h"
#include<inttypes.h>
#include<time.h>

#ifdef _HAVE_LIBVNC
#include"rfb/rfbclient.h"
#endif



#define XVNC_BIN "bvbcs"
#define WEBC_BIN "google-chrome"
/**
 *
 */
#define KEY_TIMEOUT 30
#define CLOSE_TIMEOUT 10

#define NUM_RELAUNCH 3

#define CHROME_Normal 0
#define CHROME_TVnet 1




//types for eventworker
enum{
    
    VNCMS_EVT_0=0,

    VNCMS_EVT_ACTION,

    VNCMS_EVT_SIGCHLD,//signals

    VNCMS_EVT_TERM,//send when want term

    VNCMS_EVT_NOTIFY,//notify to RSM

};

struct ew_actinfo{
    act_t type;
    cJSON*json;
};

struct ew_ntfinfo{
    int type;
#define TYPE_NTF_ALIVE 1
#define TYPE_NTF_TIMEOUT 2
#define TYPE_NTF_EXIT 3
#define TYPE_NTF_ACT_REPLY 4
#define TYPE_NTF_PROC_EXIT 5
#define TYPE_NTF_CHROME_CHECK_SHOW 6
    cJSON*json;
    int value;
};

struct ew_siginfo{
    int fl_exit;
    int fl_kill;
    int pid;

    int which;
#define TYPE_SIG_NONE 0
#define TYPE_SIG_XVNC 1
#define TYPE_SIG_WEBC 2
#define TYPE_SIG_ENC 3
#define TYPE_SIG_AUD 4
#define TYPE_SIG_SYSTEM 5
    int crashed;//not by user?.

};


typedef void (*timer_cb)(union sigval );



typedef struct _vncms{

    int index;
    int userid;
    int sinkid;

    int vnctype;



    //Xvnc's geometry
    int width;
    int height;

    char*url;
    char*webc_path;
    char*encoder_path;
    char*audio_path;
    char*xvnc_path;
    char av_pids[32];
    char av_gopsiz[16];
    char av_destaddr[INET_ADDRSTRLEN+8];
    int av_bitrate;
    int av_peakbitrate;


////
    char vncmsip[INET_ADDRSTRLEN];
    rsm_netlbinder_t* actbinder;
    rsm_netlsender_t* notifysender;
    rsm_netbinder_t* keylistener;

////

    pthread_t sighnandle_tid;


    pthread_t keylisten_tid;
    int keyport;//forward and translae key to xvnc

    pthread_t actbind_tid;
    int listenport;//accept action from RSM

    pthread_t notifysend_tid;
    int rsm_listenport;// port to which Vncms should notify
#ifdef _HAVE_LIBVNC
    rfbClient* vncclient;//key agent
#endif
    int xvncport;//vncserver's listen port for rfbclient
//
    pid_t xvncid;
    pid_t webcid;
    pid_t encid;
    pid_t audid;

    //non-zero implys that correspond process was closed by normal ways. 
    pid_t xvncid_sav;//for further ref
    pid_t webcid_sav;
    pid_t encid_sav;
    pid_t audid_sav;

//for vncms_system()
    pid_t otherid;
    int otherret;
    pthread_mutex_t othlock;
    pthread_cond_t othcond;

// for relaunch count 0~3
    timer_t proctimer;
    int nb_relaunch_xvnc;
    int nb_relaunch_webc;
    int nb_relaunch_enc;
    int nb_relaunch_aud;

//-----
    unsigned int chrome_type       :1;
    unsigned int b_audio           :1;//enable audio
    unsigned int b_vgl             :1;
    unsigned int b_timeout         :1;//enable user key timeout

#ifdef _ENABLE_CHROME_CHECK_SHOW
    int webcchk_times;
    timer_t webcchk_timer;
    int webcchk_delay;
#endif


#ifdef _ENABLE_KEY_TIMEOUT
    timer_cb keytimeout_cb;
    int keytimeout_val;
    rsmtimer_t keytimeout_timer;
#endif

#ifndef _HAVE_LIBVNC
    KeyAgent ka;
#endif


    rsm_conf_t vncms_conf;
    rsm_log_t vncms_log;
    eventworker_t evtworker;

}rsm_vncms_t;


typedef uint32_t idx_t;

//CAUTION!!!
//All Methods below are not thread safety.
//Shall call those Methods within one thread
rsm_vncms_t*rsm_vncms_new(idx_t idx);

void rsm_vncms_free(rsm_vncms_t*vncms);

int rsm_vncms_start(rsm_vncms_t*pvncms);

int rsm_vncms_start_xvnc(rsm_vncms_t*vncms);
int rsm_vncms_stop_xvnc(rsm_vncms_t*vncms);

int rsm_vncms_open_webc(rsm_vncms_t*vncms);
int rsm_vncms_close_webc(rsm_vncms_t*vncms);
int rsm_vncms_set_timeout(rsm_vncms_t*vncms,int sec);

int rsm_vncms_open_encoder(rsm_vncms_t*vncms);
int rsm_vncms_close_encoder(rsm_vncms_t*vncms);

int rsm_vncms_open_audiorecorder(rsm_vncms_t*vncms);
int rsm_vncms_close_audiorecorder(rsm_vncms_t*vncms);

int rsm_vncms_reset(rsm_vncms_t*vncms);


int rsm_vncms_open_avencoder(rsm_vncms_t*vncms);
int rsm_vncms_close_avencoder(rsm_vncms_t*vncms);



//////////////////////////////////////////////





#endif
