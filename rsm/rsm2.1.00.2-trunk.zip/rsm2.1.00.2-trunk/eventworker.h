#ifndef _H_EVENTWORKER_
#define _H_EVENTWORKER_


#include"asyncqueue.h"
#include"rzut/zlist.h"

//#include""
#include<pthread.h>



#define EVW_PRESIS 1
#define EVW_ONCE -1

#define EV_BRK -1   //for stop eventwork..

typedef struct _evs{
    int type;
    void*userdata;
}evtinfo_t;


typedef int(*eventworker_func)(void*data,void*udata);


typedef struct evwkr{

    int type;
    eventworker_func func;
    void*workdata;

    struct list_head list;
}evtwork_t;




typedef struct _evtworker{

    async_que_t evtq;

    struct list_head workers;//registered event workers.
    int nb_workers;

    pthread_t arbiter_tid;
//    pthread_attr_t arbiter_attr;

    pthread_mutex_t lock;

    char name[32];

}eventworker_t;




int eventworker_init(eventworker_t*ew);

void eventworker_fini(eventworker_t*ew);

void eventworker_setname(eventworker_t*ew,const char*name);

int eventworker_register_event(eventworker_t*ew,int type,eventworker_func func,void*data);

int eventworker_unregister_event(eventworker_t*ew,int type);


int eventworker_start(eventworker_t*ew);

int eventworker_stop(eventworker_t*ew);


int eventworker_emit_event(eventworker_t*ew,int type,void*userdata);





#endif
