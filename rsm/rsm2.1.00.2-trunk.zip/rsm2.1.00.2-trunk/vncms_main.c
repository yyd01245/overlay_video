#include"rsm_vncms.h"
#include<stdio.h>
#include<stdlib.h>


int main(int argc,char**argv)
{


    int idx=10;
    if(argc>1)
        idx=atoi(argv[1]);

    int ret;

    rsm_vncms_t*vncms=rsm_vncms_new(idx);
    if(!vncms)
        return -1;

    ret=rsm_vncms_start(vncms);

    rsm_vncms_free(vncms);
    
    return ret;

}
