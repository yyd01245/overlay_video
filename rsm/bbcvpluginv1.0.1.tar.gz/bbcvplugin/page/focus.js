;(function () {
    /**
     * 以获取往下焦点为例
     * 获取top值大于元素bottom值的所有元素
     * 计算当前元素的中心点与匹配元素的中心点
     * 取值最小的为当前元素的下移对象
     *
     * 此方法会逐个匹配每一个元素，故不适合移动元素过多的页面
     * 此方法亦不适合焦点动态移动的页面。焦点只在加载后初始化一次。
     */


    var match_ele = [];
    var slice = match_ele.slice;
    var outline_color = "#F00";
	var outline_width = "2";
    var focus_box = null;
    var force_ele = false;
    var session_key = location.origin + location.pathname + "bbcvext";
    var session_value = sessionStorage.getItem(session_key);
    var start_ele = {
        rect: {
            left: 1280,
            top: 720
        }
    };
    var direct_opp = {
        "left": "right",
        "right": "left",
        "top": "bottom",
        "bottom": "top"
    }
    var valid_area = Math.tan((20 / 180) * Math.PI); //对边比邻边

    function appendTag(tag) {
        var list = document.getElementsByTagName(tag);
        list = slice.call(list);

        list.forEach(function (ele) {
            var rect = ele.getBoundingClientRect();
            match_ele.push({
                ele: ele,
                rect: rect,
                index: match_ele.length
            })
        })
    }

    function appendArea(){
        var map_list = slice.call(document.getElementsByTagName("map"));
        map_list.forEach(function(map_ele){
            var map_name = map_ele.getAttribute("name");
            //查找对应的图片元素
            var map_img = document.querySelectorAll('img[usemap="#'+map_name+'"]');

            if(map_img.length) {
                map_img = map_img[0];
                var map_rect = map_img.getBoundingClientRect();

                var map_top = map_rect.top;
                var map_left = map_rect.left;

                var area_list = slice.call(map_ele.getElementsByTagName("area"));
                area_list.forEach(function(area_ele){
                    var shape = area_ele.getAttribute("shape");
                    if(shape &&shape !== "rect"){
                        //只处理矩形的area
                        return;
                    }

                    var area_coords = area_ele.getAttribute("coords");

                    if(area_coords){
                        var coords_list = area_coords.split(","); //x1,y1,x2,y2
                        var rect = {
                            "left": map_left + parseInt(coords_list[0]),
                            "top": map_top + parseInt(coords_list[1]),
                            "right": map_left + parseInt(coords_list[2]),
                            "bottom": map_top + parseInt(coords_list[3]),
                            "width": parseInt(coords_list[2]) - parseInt(coords_list[0]),
                            "height": parseInt(coords_list[3]) - parseInt(coords_list[1])
                        }

                        match_ele.push({
                            ele: area_ele,
                            rect: rect,
                            index: match_ele.length
                        })
                    }
                })
            }
        });
    }

    function pointCenter() {
        match_ele = match_ele.map(function (ele) {
            var rect = ele.rect;
            var center = {
                left: rect.left + (rect.width / 2),
                top: rect.top + (rect.height / 2)
            }

            ele.center = center;
            return ele;
        })
    }

    function paintMap() {
        var length = match_ele.length;
        var compare_start;
        if(session_value){
            compare_start = function(ele){
                if(!force_ele){
                    var value = factorySessionValue(ele.center);
                    if(value === session_value){
                        start_ele = ele;
                        force_ele = true;
                    }
                }
            }
        }
        else {
            compare_start = function(ele){
                var ele_rect = ele.rect;
                if(!force_ele){
                    if(ele.ele.hasAttribute("bbcv-start")){
                        start_ele = ele;
                        force_ele = true;
                    }
                    else {
                        if (ele_rect.left < start_ele.rect.left || ele_rect.top < start_ele.rect.top) {
                            start_ele = ele;
                        }
                    }
                }
            }
        }

        match_ele.forEach(function (ele) {
            var may_left = [];
            var may_right = [];
            var may_top = [];
            var may_bottom = [];

            var last_left = null;
            var last_right = null;
            var last_top = null;
            var last_bottom = null;

            var temp;
            var temp_rect;
            var ele_rect = ele.rect;
            var ele_center = ele.center;

            //确定初始元素
            compare_start(ele);

            for (var i = 0; i < length; i++) {
                temp = match_ele[i];
                temp_rect = temp.rect;
                //left
                if (temp_rect.right <= ele_rect.left) {
                    if (temp_rect.bottom < ele_rect.top){
                        //在左上
                        if( ((ele_rect.top - temp_rect.bottom) / (ele_center.left - temp_rect.left)) < valid_area ){
                            may_left.push(temp);
                        }
                    }
                    else if(temp_rect.top > ele_rect.bottom){
                        //在左下
                        if( ((temp_rect.top - ele_rect.bottom) / (ele_center.left - temp_rect.left)) < valid_area ){
                            may_left.push(temp);
                        }
                    }
                    else {
                        may_left.push(temp);
                    }
                }
                //right
                if (temp_rect.left >= ele_rect.right) {
                    if (temp_rect.bottom < ele_rect.top){
                        //在右上
                        if( ((ele_rect.top - temp_rect.bottom) / (temp_rect.right - ele_rect.right)) < valid_area ){
                            may_right.push(temp);
                        }
                    }
                    else if(temp_rect.top > ele_rect.bottom){
                        //在右下
                        if( ((temp_rect.top - ele_rect.bottom) / (temp_rect.right - ele_rect.right)) < valid_area ){
                            may_right.push(temp);
                        }
                    }
                    else {
                        may_right.push(temp);
                    }
                }
                //top
                if (temp_rect.bottom <= ele_rect.top) {
                    if (temp_rect.right < ele_rect.left){
                        //在上左
                        if( ((ele_rect.left - temp_rect.right) / (ele_rect.top - temp_rect.top)) < valid_area ){
                            may_top.push(temp)
                        }
                    }
                    else if(temp_rect.left > ele_rect.right){
                        //在上右
                        if( ((temp_rect.left - ele_rect.right) / (ele_rect.top - temp_rect.top)) < valid_area ){
                            may_top.push(temp)
                        }
                    }
                    else {
                        may_top.push(temp)
                    }
                }
                //bottom
                if (temp_rect.top >= ele_rect.bottom) {
                    if (temp_rect.right < ele_rect.left){
                        //在下左
                        if( ((ele_rect.left - temp_rect.right) / (temp_rect.bottom - ele_rect.bottom)) < valid_area ){
                            may_bottom.push(temp);
                        }
                    }
                    else if(temp_rect.left > ele_rect.right){
                        //在下右
                        if( ((temp_rect.left - ele_rect.right) / (temp_rect.bottom - ele_rect.bottom)) < valid_area ){
                            may_bottom.push(temp);
                        }
                    }
                    else {
                        may_bottom.push(temp);
                    }
                }
            }

            last_left = getDistance(may_left, ele_center);
            last_right = getDistance(may_right, ele_center);
            last_top = getDistance(may_top, ele_center);
            last_bottom = getDistance(may_bottom, ele_center);

            if (last_left) {
                ele.left = last_left.index;
            }

            if (last_right) {
                ele.right = last_right.index;
            }

            if (last_top) {
                ele.top = last_top.index;
            }

            if (last_bottom) {
                ele.bottom = last_bottom.index;
            }
        })
    }

    function getDistance(list, center) {
        var distance = 2000;
        var last = null;
        list.forEach(function (ele) {
            var temp = Math.abs(center.left - ele.center.left) + Math.abs(center.top - ele.center.top);
            if (temp < distance) {
                distance = temp;
                last = ele;
            }
        })
        return last;
    }

    function addFocusBox(){
        focus_box = document.createElement("div");
        focus_box.style.cssText = "position: absolute; outline: " + outline_color + " solid "+outline_width+"px; z-index: 9999999";

        document.body.appendChild(focus_box);
    }

    function setColor(color){
        color && (focus_box.style.outlineColor = color);
    }
	  function setWidth(width){
        width && (focus_box.style.outlineWidth = width);
    }

    function move(direct) {
        var next = start_ele[direct];
        var next_obj;

        if (typeof next !== "undefined") {
            next_obj = match_ele[next];
            //将反方向的对象设为来源对象
            next_obj[direct_opp[direct]] = start_ele.index;
            outfocus();
            start_ele = next_obj;
            infocus();
        }
    }

    function outfocus() {
        start_ele.ele.blur();
    }

    function infocus() {
        var cssText = "left: " + start_ele.rect.left + "px; top: " + start_ele.rect.top + "px; height: " + start_ele.rect.height + "px; width: " + start_ele.rect.width + "px;";
        focus_box.style.cssText += cssText;
    }

    function select() {
        var href = start_ele.ele.getAttribute("href");
        if(href && href !== "#"){
            sessionStorage.setItem(session_key, factorySessionValue(start_ele.center));
            location.href = href;
        }
    }

    function factorySessionValue(center){
        return center.left + "*" + center.top;
    }

    function bindKeyBoard() {
        document.addEventListener("keydown", function (e) {
            var keyCode = e.keyCode;
            switch (keyCode) {
                case 37: //left
                    move("left");
                    break;

                case 38: //top
                    move("top");
                    break;

                case 39: //right
                    move("right");
                    break;

                case 40: //down
                    move("bottom");
                    break;

                case 45: //back
                    if(wasuUserHistory1){
                        wasuUserHistory1.back();
                    }
                    else {
                        history.back();
                    }
                    break;

                case 13: //选择
                    select();
                    break;
            }
        }, false)
    }

    function init() {
        appendTag("a");
        appendArea();
        pointCenter();
        paintMap();

        addFocusBox();
        infocus();

        bindKeyBoard();
    }

    window.BROWSERFOCUSOBJ = {
        "open": init,
        "setColor": setColor,
		"setWidth": setWidth
    };
})();