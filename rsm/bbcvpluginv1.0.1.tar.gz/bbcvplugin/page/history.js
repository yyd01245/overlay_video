//1����¼�û�������ʷ��2������û�������ʷ��3���ϱ��û������Ϣ��4��������һҳ�� 
(function(window){
//����Ƿ���Ҫ��������cookie��Ϣ
var reset_cookies =(window.location.href).indexOf("?")>0?(window.location.href).split("?")[1]:null;
if(reset_cookies!==null && (window.location.href).indexOf("focusInfo")>=0){
	reset_cookies = decodeURIComponent(reset_cookies);
	var exp = new Date();
	exp.setTime(exp.getTime() + 30 * 24 * 60 * 60 * 1000);
	eval("var reset_cookinfo="+ (typeof(reset_cookies.split("cookies=")[1])!="undefined"?reset_cookies.split("cookies=")[1].split("&")[0]:null));
	for (var key1 in reset_cookinfo){
		document.cookie =key1+"="+reset_cookinfo[key1]+";expires="+exp.toGMTString()+";path=/;domain="+document.domain;
    }	
	eval("var reset_pageinfo="+ (typeof(reset_cookies.split("pageInRequestInfo=")[1])!="undefined"?reset_cookies.split("pageInRequestInfo=")[1].split("&")[0]:null));
	for (var key2 in reset_pageinfo){
		//document.cookie =key2+"="+decodeURIComponent(reset_pageinfo[key2])+";expires="+exp.toGMTString()+";path=/;domain="+document.domain;
		document.cookie =key2+"=\""+encodeURI(reset_pageinfo[key2])+"\";expires="+exp.toGMTString()+";path=/;domain="+document.domain;
    }
	eval("var reset_extendInfo="+ (typeof(reset_cookies.split("extendInfo=")[1])!="undefined"?reset_cookies.split("extendInfo=")[1].split("&")[0]:null));
	for (var key3 in reset_extendInfo){
		document.cookie =key3+"="+reset_extendInfo[key3]+";expires="+exp.toGMTString()+";path=/;domain="+document.domain;
    }
}
//ע�����
var historyObj1 = {
		/**
		 * getCookie ��ȡcookie
		 * @param key
		 * @returns
		 */
		getCookie:function(key){
		    var arr=document.cookie.match(new RegExp("(^| )"+key+"=([^;]*)(;|$)"));
		    if (arr != null)
		        return unescape(arr[2]);
		    return null;
		},
		setCurr_cookies:function(){
			var c = document.cookie.split(";");
			var cookieStr = "{";
			for(var i=0;i<c.length-1;i++){
				var cs = c[i].split("=");
				if(cs.length>1){
					var name = cs[0];
					name = name.replace(/^\s+|\s+$/g,"");
					var value = cs[1];
					value = value.replace(/\"/g,"");
					cookieStr += "\""+name+"\":\""+value+"\"";
				}
				if(i<c.length-2){
					cookieStr += ",";
				}
			}
			cookieStr += "}";
			return cookieStr;
		},
		//usm.cloudplatform.syetemservice.wasu.cn  usm.cloudplatform.wasu.cn:8880
		globalPageInfoReportUrl:"http://usm.cloudplatform.wasu.cn:8880/usm/visithistory/globalPageInfoReport",
		currPageInfoReportUrl:"http://usm.cloudplatform.wasu.cn:8880/usm/visithistory/currPageInfoReport",
		pageInfoClearUrl:"http://usm.cloudplatform.wasu.cn:8880/usm/visithistory/pageInfoClear",
		pageBackUrl:"http://usm.cloudplatform.wasu.cn:8880/usm/visithistory/pageBack",
		curr_stbId:function (){
			return this.getCookie("stbid"); 
		},
		curr_userId:function (){
			return this.getCookie("uid");				
		},
		curr_appId:function (){
			return this.getCookie("appId");
		},
		curr_cookies:function (){
			return this.setCurr_cookies();
		},
		curr_headers:function (){
			return "{}";
		},
		curr_extendInfo:function (){
			return "{}";
		},
		curr_pageInRequestInfo:function (){
			var pageInfos = this.getCookie("pageInfoCookies");
			if(pageInfos != null){
				//pageInfos = encodeURIComponent(pageInfos);
				pageInfos = pageInfos.replace(/\"/g,"");
				return "{\"pageInfoCookies\":\""+ pageInfos +"\"}";
			}else{
				return "{}";
			}
			
		},
		page_currUrl:(window.location.href).indexOf("?")>0?(window.location.href).split("?")[0]:(window.location.href),
		jsonObjTostring:function(jsonObj){
			 var reStr="";
			 if(jsonObj!=null && typeof(jsonObj)=="object"){
				 var beginStr = "{";
				 var endStr = "}";
				 if(Object.prototype.toString.call(jsonObj) === '[object Array]'){
					 beginStr = "[";
					 endStr = "]";
				 }	
				 for(var item in jsonObj){
					 //JSON ����
					 if(!(item>=0)){
						 reStr += "'"+ item + "':";
					 }
					 var type=typeof(jsonObj[item]);
					 if(type=="number"){
						 reStr +=jsonObj[item];
					 }else if(type=="object"){
						 reStr += XEpg.Util.objectToStr(jsonObj[item]);
					 }else{
						 reStr +="'"+jsonObj[item]+"'"; 
					 }
					 reStr +=",";
				 }
				 if(reStr.length>0)
					 reStr = reStr.substr(0,reStr.length-1);
				 reStr = beginStr+reStr+endStr;
			 }
			 return reStr;
		},
		/**
		 * AJAX
		 * @param _type   �������ͣ�GET POST	
		 * @param _msg		������Ϣ����
		 * @param _postUrl   �����ַ
		 * @param _successLocationUrl   ajax�ɹ�����ת��ַ
		 */
		AJAX:function(_type,_postUrl,_msg,_successLocationUrl){
			var xmlhttp;
			if (window.XMLHttpRequest){
				xmlhttp=new XMLHttpRequest();
			}
			else{
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}	
			xmlhttp.open(_type,_postUrl,true);
			_msg = (typeof(_msg)=="undefined"||typeof(_msg)=="null")?"":_msg;
			xmlhttp.send(_msg);		
			xmlhttp.onreadystatechange=function(){
				if (xmlhttp.readyState==4 && xmlhttp.status==200){
					var responseTextStr = xmlhttp.responseText;
					var resultInfo = "";
					if(responseTextStr!="" && responseTextStr!=null && responseTextStr!="null"){
						eval("resultInfo="+responseTextStr.replace(/\r/g,"").replace(/\n/g,""));
					}
					var _backUrl = typeof(resultInfo.currUrl)!="null"?resultInfo.currUrl:"";
					if(typeof(_backUrl)=="string" && _backUrl.length>0){
						if(true){
					//	if(resultInfo.result=="0"){
							var _extendInfo = historyObj1.jsonObjTostring(resultInfo.extendInfo);
							var _focusInfo = historyObj1.jsonObjTostring(resultInfo.focusInfo);
							var _pageInRequestInfo = historyObj1.jsonObjTostring(resultInfo.pageInRequestInfo);
							window.location.href=_backUrl+"?extendInfo="+_extendInfo+"&focusInfo="+_focusInfo+"&pageInRequestInfo="+_pageInRequestInfo;
						}else if(resultInfo.result=="1"){
							
						}else if(resultInfo.result=="2"){
							
						}else if(resultInfo.result=="-1"){
							
						}
					}else if(typeof(_successLocationUrl)=="string" && _successLocationUrl.length>0){
						window.location.href=_successLocationUrl;
					}
				}
			};
		},
		/**
		 * reportGlobal
		 * http Post
		 * http+json
		 *  @param _stbId
		 *  @param _userId
		 *  @param _appId
		 *  @param _cookies
		 *  @param _headers
		 *  @param _extendInfo
		 */
		reportGlobal:function(_stbId,_userId,_appId,_cookies,_headers,_extendInfo){
			var msg="";
			msg +="{";
				msg +="\"stbId\":\""+_stbId+"\",";
				msg +="\"userId\":\""+_userId+"\",";
				msg +="\"appId\":\""+_appId+"\",";
				msg += "\"cookies\":";
			//		msg += "{";
					/****setCookies s****/
					msg += typeof(_cookies)=="undefined"?"":_cookies;
					/****setCookies e***/
			//		msg+= "}";
					msg+= ",";
				msg += "\"headers\":";
					/****setHeaders s****/
					msg += typeof(_headers)=="undefined"?"":_headers;
					/****setHeaders e***/
			//		msg+= "}";
					msg+= ",";
				msg += "\"extendInfo\":";
					/****setExtendInfo s****/
					msg += typeof(_extendInfo)=="undefined"?"":_extendInfo;
					/****setExtendInfo e***/
			//		msg+= "}";
			msg += "}";
//			var a = new AJAX();
			this.AJAX("POST",this.globalPageInfoReportUrl,msg,null);
		},
		/**
		 * reportCurr
		 * http Post
		 * http+json
		 * @param _stbId
		 * @param _appId
		 * @param _currUrl
		 * @param _focusInfo
		 * @param _pageInRequestInfo
		 * @param _extendInfo
		 * @param _pageUrl
		 */
		reportCurr:function(_stbId,_appId,_currUrl,_focusInfo,_pageInRequestInfo,_extendInfo,_pageUrl){
			var msg="";
			msg +="{";
				msg +="\"stbId\":\""+_stbId+"\",";
				msg +="\"appId\":\""+_appId+"\",";
				msg +="\"currUrl\":\""+_currUrl+"\",";
				msg += "\"focusInfo\":";
			//		msg += "{";
					/****setFocusInfo s****/
					msg += typeof(_focusInfo)=="undefined"?"":_focusInfo;
					/****setFocusInfo e***/
			//		msg+= "}";
					msg+= ",";
				msg += "\"pageInRequestInfo\":";
					/****setPageInRequestInfo s****/
					msg += typeof(_pageInRequestInfo)=="undefined"?"":_pageInRequestInfo;
					/****setPageInRequestInfo e***/
			//		msg+= "}";
					msg+= ",";
				msg += "\"extendInfo\":";
					/****setExtendInfo s****/
					msg += typeof(_extendInfo)=="undefined"?"":_extendInfo;
					/****setExtendInfo e***/
			//		msg+= "}";
			msg += "}";
			this.AJAX("POST",this.currPageInfoReportUrl,msg,_pageUrl);
		},
		/***
		 * clear
		 * http GET
		 * http+json
		 */
		clear:function(_stbId){
			var stbid =_stbId;
			if(_stbId==undefined || _stbId==null || _stbId==""){
				stbid = this.curr_stbId();
			}
			this.AJAX("GET",this.pageInfoClearUrl+"?stbId="+stbid+"&appId="+this.curr_appId(),null,null);

		},
		/***
		 * back
		 * http GET
		 * http+json
		 */
		back:function(_subAppId){
			var appId;
			if(_subAppId==undefined || _subAppId==null || _subAppId==""){
				appId = this.curr_appId();
			}else{
				appId = this.curr_appId()+"_"+_subAppId;
			}
			this.AJAX("GET",this.pageBackUrl+"?stbId="+this.curr_stbId()+"&appId="+appId,null,null);
		},
		/***
		 * pageJump
		 * http GET
		 * http+json
		 *@param _pageUrl ��תҳ���ַ
		 *@param _focusInfo ҳ�潹����Ϣ
		 * ҳ����ת���ϱ���ǰҳ����Ϣ����ת����һ��ҳ��
		 */
		pageJump:function(_appId,_focusInfo,_pageUrl,_subAppId){
			if(_appId=="" || _appId==null || _appId=="null"){		
				_appId = this.curr_appId();
			}
			if(_pageUrl.indexOf("single_play_cloudtv") > 0){
				this.reportGlobal(this.curr_stbId(),this.curr_userId(),_appId,this.curr_cookies(),this.curr_headers(),this.curr_extendInfo());
			}
			this.reportCurr(this.curr_stbId(),_appId+"_"+_subAppId,this.page_currUrl,_focusInfo,this.curr_pageInRequestInfo(),this.curr_extendInfo(),_pageUrl);

		},
		/**
		 * switchApp  ��Ӧ�û���벥��
		 * http GET
		 * http+json
		 *@param _appId  �л�Ŀ��Ӧ��appId
		 *@param _focusInfo
		 *@param _pageUrl ��תҳ���ַ
		 *@param  _subAppId ���뵱ǰӦ�������߼���Ӧ��ID���磺����ҳ�����㲥05��ʱ��06��
		 */
		switchApp:function(_appId,_focusInfo,pageUrl,_subAppId){
			if(_subAppId!="" && _subAppId!=null && _subAppId!="null"){		
				_appId += "_"+_subAppId;
			}
			this.reportGlobal(this.curr_stbId(),this.curr_userId(),_appId,this.curr_cookies(),this.curr_headers(),this.curr_extendInfo());
			this.reportCurr(this.curr_stbId(),_appId,this.page_currUrl,_focusInfo,this.curr_pageInRequestInfo(),this.curr_extendInfo(),null);
			//����Ӧ��
			this.AJAX("GET",pageUrl,null,null);
		}
		//����jsonp
//		createJsonp:function(id,url){
//		},
  };
	//���Epg��û�д���
	if(!(typeof(window["wasuUserHistory1"])=="wasuUserHistory1" && typeof(window["wasuUserHistory1"])!=null)){
		window["wasuUserHistory1"]={};
	}
	window["wasuUserHistory1"] = historyObj1;
})(window);


