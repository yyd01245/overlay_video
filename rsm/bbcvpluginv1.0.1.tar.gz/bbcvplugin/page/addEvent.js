;(function(global){
    localStorage.setItem("bbcvListenerLength", 0);
    var listener_length = 0;

    EventTarget.prototype._addEventListener = EventTarget.prototype.addEventListener;
    EventTarget.prototype.addEventListener = function(a, b, c){
        this._addEventListener(a,b,c);
        if(a === "keydown"){
            listener_length++;
            localStorage.setItem("bbcvListenerLength", listener_length);
        };
    };
})(window);
