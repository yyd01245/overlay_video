;
(function(){
    /*setTimeout(function(){
        var evnet_script = createScript(chrome.extension.getURL("page/addEvent.js"), document);
        console.log("event");
        $(document.head).append(evnet_script);
    },0);*/
    setTimeout(function(){
        var focus_script = createScript(chrome.extension.getURL("page/focus.js"), document);
        console.log("focus");
        $(document.head).append(focus_script);
    }, 0)
    $(document).ready(function(){
        var history_script = createScript(chrome.extension.getURL("page/history.js"), document);
        console.log("history");
        $(document.head).append(history_script);
    })
})();
