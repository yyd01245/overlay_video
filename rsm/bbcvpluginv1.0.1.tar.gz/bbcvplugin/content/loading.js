var loading_iframe;
var loading_expire = 10;
var loading_showing = 0;
var loading_hide_timer;
var loading_template = "";
var loading_highest_win = null;
(function(){
    var dom_ready = false;
    var dom_ready_cb = function(){};
    var page_load = false;
    var win = getParent(window);
    loading_highest_win = win;

    $.ajax({
        success: function(tempstr){
            var template = tempstr;
            loading_template = tempstr;

            if(dom_ready && !page_load){
                append(template)
            }
            else {
                dom_ready_cb = function(){
                    append(template)
                }
            }
        },
        url: chrome.extension.getURL("template/loading.html")
    });

    $(document).ready(function(){
        dom_ready = true;
        dom_ready_cb();
    })

    $(window).on("load", function(){
        page_load = true;
        win.loading_remove()
    })

    function append(template){
        win.loading_append(template);
    }

    //获取未跨域的最高parent
    function getParent(win){
        try{
            if( typeof win.parent.document !== 'undefined' && win !== win.top ){
                return getParent(win.parent);
            }
            else {
                return win;
            }
        }
        catch(e){
            return win;
        }
    }

    /*var messageHandler = {
        "closeLoading": function(msg){
            if(getParent(window) === window){
                window.loading_remove()
            }
        }
    }

    chrome.extension.onMessage.addListener(function(msg, sender, callback){
        if( msg && msg.cmd && messageHandler[msg.cmd] ){
            messageHandler[msg.cmd](msg)
        }
    });*/
})();

function loading_append(template){
    if(loading_showing === 0){
        loading_iframe = createIframe();
        loading_iframe.style.cssText = "height:720px;width:1280px;position: absolute;left: 0;top: 0;padding: 0;margin: 0;z-index: 2147483647;border:none;";

        $(document.body).append(loading_iframe);
        loading_iframe.contentDocument.body.innerHTML = template;
    }
    clearTimeout(loading_hide_timer);
    loading_hide_timer = setTimeout(function(){
        loading_remove(true);
    }, loading_expire*1000);
    loading_showing++;
}

function loading_remove(force){
    if(force){
        $(loading_iframe).remove();
    }
    else {
        loading_showing--;
        if(loading_showing === 0){
            $(loading_iframe).remove();
        }
    }
}

function createIframe(){
    var iframe = document.createElement( "iframe" );
    iframe.allowtransparency = "true";
    iframe.scrolling = "no"

    return iframe;
}

document.addEventListener("bbcvLoadingShow", function(){
    $(document.body).empty().css({
        "backgroundImage": "none",
        "backgroundColor": "#000"
    });
    loading_highest_win.loading_append(loading_template);
}, false);