String.prototype.QS = function(name){
    var result = this.match(new RegExp("[\?\&]" + name+ "=([^\&]+)","i"));
    if(result == null || result.length < 1){
        return "";
    }
    return result[1];
};

function createScript(script, context){
    var scriptEle = context.createElement('script');
    scriptEle.src = script;
    return scriptEle;
}


localStorage.setItem("chromePlugVersion", "3.0");
localStorage.setItem("chromePlugName", "bbcv chrome extension HD");

function connectToBg( obj, callback ){
    callback = callback ? callback : function(){};
    chrome.extension.sendMessage( obj, callback );
}

var messageHandler = {
    "backInfo": function(obj, cb){
        cb({
            local: $_local,
            header: $_header
        })
    }
}

chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse) {
        messageHandler[request.cmd](request, sendResponse);
    }
);

var $_local, $_header;
//第一时间加载localStorage数据
console.log("fetch local UserInfo from Background");
connectToBg({
    "cmd": "getLocal"
}, function(local){
    $_local = JSON.parse(JSON.stringify(local));
    console.log("fetch result:", $_local);
    var keys = Object.keys($_local);
    keys.forEach(function(ele){
        localStorage.setItem(ele, local[ele]);
    })
});

connectToBg({
    "cmd": "getHeader"
}, function(header){
    $_header = JSON.parse(JSON.stringify(header));
})

//localStorage.setItem(key, qs(value) || default);
var needLocal = [
    {
        key: "sessionId",
        value: "sessionid"
    },
    {
        key: "termId",
        value: "termId"
    },
    {
        key: "aimIp",
        value: "aimIp"
    },
    {
        key: "aimPort",
        value: "aimPort"
    },
    {
        key: "homePage",
        value: function(qs){
            return decodeURIComponent(qs.QS("homePage"));
        }
    },
    {
        key: "expandInfo",
        value: function(qs){
            return localStorage.chromePlugVersion+"$"+qs.QS("vncip")+"#"+qs.QS("vnckeyport")+"#"+qs.QS("vncport")+"$"+qs.QS("expandinfo");
        }
    },
    {
        key: "vncPort",
        value: "vncport"
    },
    {
        key: "vncKeyPort",
        value: "vnckeyport"
    },
    {
        key: "vncIp",
        value: "vncip"
    },
    {
        key: "boxType",
        value: "boxType",
        default: "00"
    },
    {
        key: 'boxRootPaths',
        value: function(qs){
            return decodeURIComponent(qs.QS("boxRootPaths"));
        }
    },
    {
        key: "vstbUserId",
        value: "vstbUserId"
    },
    {
        key: "userInfo",
        value: "userInfo"
    },
    {
        key: "vstb_are_token",
        value: function(){
            return "2257B3D268C7F8B7B437FB92D8D91597";
        }
    }
];
//执行空白首页逻辑
$(document).ready(function(){
    var is_portal = $("#bbcv-index-portal").val();
    var qs = {};
    var qstr = location.search;

    if( is_portal == "portal" ){
        needLocal.forEach(function(ele){
            var value = "";
            if( typeof ele.value === "function" ){
                value = ele.value(qstr);
            }
            else {
                value = qstr.QS(ele.value);
            }
            value = value || ele.default;

            if( value ){
                qs[ele.key] = value ;
            }
        });

        var msg = qstr.QS("msg");
        if( msg ){
            msg = JSON.parse(atob(msg));
            connectToBg({
                "cmd": "setHeader",
                "header": msg
            })
        }

        connectToBg({
            "cmd": "setLocal",
            "local": qs
        }, function(local){
            var home = decodeURIComponent(qstr.QS("KYSXURL"));
            if(home){
                top.location.href = home;
            }
        });

        localStorage.setItem("sessionId", qs["sessionId"]);
        localStorage.setItem("vstbUserId", qs["vstbUserId"]);
    }
    else {
        /*var focus_script = createScript(chrome.extension.getURL("page/focus.js"), document);
        $(document.head).append(focus_script);*/
    }
});