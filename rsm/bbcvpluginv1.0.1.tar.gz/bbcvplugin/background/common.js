function talkTab( id, msg, callback ) {
    chrome.tabs.sendMessage( id, msg, callback );
}

function talkCurrentTab( msg, callback ) {
    chrome.tabs.getSelected(function(tab) {
        talkTab( tab.id, msg, callback );
    });
}

function updateTab(tabId, obj){
    chrome.tabs.update(tabId, obj);
}

//����contentScript����Ϣ
chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse) {
        messageHandler[request.cmd](request, sendResponse);
    }
);