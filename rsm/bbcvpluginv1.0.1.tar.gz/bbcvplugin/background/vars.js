var messageHandler = {};
var stbid, vstb;