(function(){
    var socketURL = "ws://21.254.43.68:2889/websocket/channelcreate";

    var heartbeat_timer;
    var heartbeat_time = 4 * 60 * 1000;
    var heartbeat_string = JSON.stringify({"cmd": "heartbeat", "serialno": serialno()});

    function heartbeat(){
        shareWS.send(heartbeat_string);
    }

    function resetHeartbeat(){
        clearTimeout(heartbeat_timer);
        heartbeat_timer = setTimeout(heartbeat, heartbeat_time);
    }

    window.wsLogin = function(){
        if( !shareWS ){
            createShareWS();
        }
    };

    var wsHandler = {
        "redirect": function(obj){
            updateTab(null, {
                url: obj.url
            });
        },
        "channelRelease": function(){
            shareWS.close();
        },
        //mdc
        'push': function(data){
            //talkCurrentTab(data);
        },
        //keyboard
        'sendkey': function(data){
            data.stbid = userid;
            // keyboardWS.send(JSON.stringify(data));
        },
        //mouse
        'move': function(data){
            data.stbid = userid;
            // keyboardWS.send(JSON.stringify(data));
        },

        'click': function(data){
            data.stbid = userid;
            // keyboardWS.send(JSON.stringify(data));
        },

        "login": function(data){
            if(data.retcode.toString() === "0"){
                resetHeartbeat();
            }
        }
    }

    function _log(text){
        console.log(new Date(), '  ', text)
    }

    function serialno(){
        return Date.now();
    }

    /*
     * webSocket instance
     */

    var shareWS

    function createShareWS(){
        shareWS = new webSocket(socketURL, function(data){
            _log(data);
            var result = JSON.parse(data);
            //if( result.retcode == 0 ){
            resetHeartbeat();
            wsHandler[result.cmd] && wsHandler[result.cmd](result);
            //}
        }, function(){
            shareWS.send(JSON.stringify({"cmd": "login", "sessionid": stbid, "vstbid": vstb, messageinfo: "", "serialno": serialno()}));
        })
    }

    function webSocket(url, message, open){
        this.socketURL = url;
        this.message = function(evt){
            message && message(evt.data)
        };
        this.open = open;
        this.ws = null;
        this.queue = [];
        this.init();
    }

    var errorCount = 0;
    var maxErrorCount = 30;
    webSocket.prototype = (function(){
        function createWebSocket(url){
            return new WebSocket( url );
        }

        function startWebSocket() {
            // 创建WebSocket
            var that = this;
            this.ws = createWebSocket(this.socketURL);

            // 收到消息时在消息框内显示
            this.ws.onmessage = this.message;

            // 断开时会走这个方�?
            this.ws.onclose = function(){
                _log('webSocket Close')
                console.log(arguments);
                startWebSocket.call(that);
            }

            this.ws.onerror = function(evt){
                errorCount++
                _log( 'webSocket Error: ' + evt.data + ' On ' + new Date() );
                if( errorCount === maxErrorCount ){
                    _log( 'webSocket stop Establish Connection: Please restart' );
                }
                else {
                    setTimeout(function(){
                        startWebSocket.call(that);
                    }, 1000);
                }
            }

            // 连接上时走这个方�?
            this.ws.onopen = function(){
                errorCount = 0;
                _log(that.socketURL + ' ws opened');
                that.open();
                that.queue.forEach(function(ele, index){
                    that.send(ele);
                })
                that.queue = [];
            }
        }

        return {
            'init': function(){
                startWebSocket.call(this);
            },

            'send': function(msg){
                if( this.ws.readyState === 1 ){
                    this.ws.send(msg);
                }
                else {
                    this.queue.push(msg);
                }
            },
            "close": function(){
                this.ws.close();
            }
        }
    })();
})();