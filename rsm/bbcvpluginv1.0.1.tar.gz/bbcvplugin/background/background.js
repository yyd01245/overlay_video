console.log("background start at", new Date());
var redirectURL = "http://pce.cloudplatform.wasu.cn/index.jsp";
var _local = {};
var _header = {};
//var manifest = chrome.extension.getManifest(); //插件信息

function talkTab( id, msg, callback ) {
    chrome.tabs.sendMessage( id, msg, callback );
}

function talkCurrentTab( msg, callback ) {
    chrome.tabs.getSelected(function(tab) {
        talkTab( tab.id, msg, callback );
    });
}

function updateTab(tabId, obj){
    chrome.tabs.update(tabId, obj);
}

//请求中需带的header头信息
var needHeader = [
    {
        key: "X-TERMINAL-MODEL",
        value: "XTERMINALMODEL"
    },
    {
        key: "X-TERMINAL-ID",
        value: "termId"
    },
    {
        key: "X-USER-ID",
        value: "XUSERID"
    },
    {
        key: "X-USERPROFILE",
        value: "XUSERPROFILE"
    },
    {
        key: "X-REGION-ID",
        value: "XREGIONID"
    },
    {
        key: "X-RESERVE",
        value: function(){
            return " "
        }
    },
    {
        key: "X-BBCV-VSTBUSERID",
        value: "vstbUserId"
    },
    {
        key: "X-REAL-USER-ID",
        value: function(){
            return " "
        }
    },
    {
        key: "X-BBCV-SESSIONID",
        value: "sessionId"
    },
    {
        key: "X-BROWSER-TYPE",
        value: function(){
            return "cloud";
        }
    }
];

chrome.webRequest.onBeforeSendHeaders.addListener(
    function(details) {
        if(details.type === "script"){
            if(details.url.indexOf("chrome-extension://") !== 0){
                details.requestHeaders.push({
                    "name": "Cache-Control",
                    "value": "no-cache"
                })
            }
        }
        else {
            needHeader.forEach(function(ele){
                var value
                if(typeof ele.value === "function"){
                    value = ele.value();
                    details.requestHeaders.push({"name": ele.key, "value": value});
                }
                else {
                    value = _local[ele.value] || _header[ele.value] || "";
                    details.requestHeaders.push({"name": ele.key, "value": value});
                }
            });
        }

        return {requestHeaders: details.requestHeaders};
    },
    {urls: ["<all_urls>"], types: ["main_frame", "sub_frame", "xmlhttprequest", "other", "script"]},
    ["blocking", "requestHeaders"]
);

var header_written = false;
var local_written = false;
var messageHandler = {
    "getLocal": function(msg, cb){
        console.log("frontEnd fetch UserInfo at", new Date());
        cb(_local);
    },

    "getHeader": function(msg, cb){
        cb(_header);
    },

    "setLocal": function(msg, cb){
        var local = msg.local;
        extend(_local, local);

        cb();
    },

    "setHeader": function(msg){
        extend(_header, msg.header);
    }
};

chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse) {
        messageHandler[request.cmd](request, sendResponse);
    }
);

function extend(obj, ext){
    var keys = Object.keys(ext);
    keys.forEach(function(ele){
        obj[ele] = ext[ele];
    })
}

//回传机制，防止background异常导致数据丢失
talkCurrentTab({
    "cmd": "backInfo"
}, function(data){
    if(data && data.header){
        extend(_header, data.header);
    }

    if(data && data.local){
        extend(_local, data.local);
    }
});

/**
 * 页面获取错误
 */

//0： 无法访问，多由DNS解析出错
var invalid_url = [
    "https://www.googleapis.com/rpc"
];
chrome.webRequest.onHeadersReceived.addListener(
    function(details){
        console.log(details);
        var status_code_reg = /\b(403|404|503){1}\b/;
        if(status_code_reg.test(details.statusLine)){
            updateTab(details.tabId, {"url": redirectURL});
        }
        return;
    },
    {urls: ["<all_urls>"], types: ["main_frame"]},
    ["blocking"]
);

chrome.webRequest.onErrorOccurred.addListener(
    function(details){
        console.log(details);
        updateTab(details.tabId, {"url": redirectURL});
    },
    {urls: ["<all_urls>"], types: ["main_frame"]}
);